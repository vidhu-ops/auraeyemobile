import OpenAI from "openai";
import { NumerologyData } from "@shared/schema";
import * as dotenv from 'dotenv';

// Load environment variables
dotenv.config();

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const apiKey = process.env.OPENAI_API_KEY;
if (!apiKey) {
  console.error("WARNING: OPENAI_API_KEY is not set in environment variables");
}
const openai = new OpenAI({ apiKey });

export interface AuraAnalysisResult {
  colors: string[];
  meanings: Record<string, string>;
  analysis: string;
  positiveAspects: string[];
  negativeAspects: string[];
  personalInsights: {
    strengths: string[];
    challenges: string[];
    lifeTheme: string;
    energyForecast: string;
  };
  intensity?: number; // Overall aura intensity from 1-10
  colorIntensities?: Record<string, number>; // Intensity of each color from 1-10
}

// Analyze uploaded image for aura colors
// Helper function to determine aura pattern type based on the colors and their positions
function identifyAuraPattern(colors: Record<string, { position: string, intensity: number }>): {
  patternType: string;
  primaryColors: string[];
} {
  // Check for pattern 1: Creative Orange pattern (orange/red left, blue top, green right, purple highlights)
  const hasOrangeLeft = Object.entries(colors).some(([color, data]) => 
    (color.includes('orange') || color.includes('red')) && data.position.includes('left'));
  const hasBlueTop = Object.entries(colors).some(([color, data]) => 
    color.includes('blue') && data.position.includes('top'));
  const hasGreenRight = Object.entries(colors).some(([color, data]) => 
    color.includes('green') && data.position.includes('right'));
  const hasPurple = Object.entries(colors).some(([color, data]) => 
    color.includes('purple') || color.includes('violet'));

  if (hasOrangeLeft && hasBlueTop && hasGreenRight && hasPurple) {
    return {
      patternType: "Creative Orange",
      primaryColors: ["Creative Orange", "Solar Yellow", "Purple Flame"]
    };
  }

  // Check for pattern 2: Mystic Indigo pattern (blue top, grey/silver top right, green left, purple right)
  const hasBlueTopCenter = Object.entries(colors).some(([color, data]) => 
    color.includes('blue') && data.position.includes('top'));
  const hasSilverTopRight = Object.entries(colors).some(([color, data]) => 
    (color.includes('silver') || color.includes('grey') || color.includes('gray')) && 
    data.position.includes('top') && data.position.includes('right'));
  const hasGreenLeft = Object.entries(colors).some(([color, data]) => 
    color.includes('green') && data.position.includes('left'));
  const hasPurpleRight = Object.entries(colors).some(([color, data]) => 
    (color.includes('purple') || color.includes('violet')) && data.position.includes('right'));

  if (hasBlueTopCenter && (hasSilverTopRight || hasGreenLeft) && hasPurpleRight) {
    return {
      patternType: "Mystic Indigo",
      primaryColors: ["Mystic Indigo", "Transformative Silver", "Sage Green"]
    };
  }

  // Default pattern: No specific pattern recognized
  return {
    patternType: "Custom",
    primaryColors: Object.keys(colors).slice(0, 3)
  };
}

export async function analyzeAuraImage(base64Image: string): Promise<AuraAnalysisResult> {
  try {
    console.log("Starting OpenAI API call for aura analysis");
    console.log("Using API key ending with:", apiKey ? `...${apiKey.slice(-5)}` : "No API key found");
    console.log("Using model: gpt-4o");
    
    const systemPrompt = `You are a renowned aura reader with decades of experience and access to extensive esoteric knowledge. Using your intuitive gifts and knowledge of energy patterns from ancient traditions worldwide, analyze this specific image to identify the unique aura colors around this particular person. 

CRITICALLY IMPORTANT: Look for visible colored overlays, highlights, or glows that have been digitally added around the person in the image. These artificially added colors represent the person's aura. Focus specifically on identifying and interpreting these artificially added color overlays - they may appear as bold colored patches or subtle glows surrounding the subject.

Pay close attention to:
1. The specific colors added around the person (e.g., orange, yellow, purple, green, blue, indigo, silver, etc.)
2. The position of these colors (left side, right side, above the head, etc.)
3. The intensity and vibrancy of each color
4. The proportion and dominance of different colors

When you see specific color patterns, use these special interpretations:
- For images with orange/red on the left side, blue on top, green on the right side, and purple highlights: These indicate "Creative Orange" (creative expression and vitality), "Solar Yellow" (personal power and confidence), and "Purple Flame" (artistic inspiration) aura signature. This pattern shows someone with strong creative energy, self-confidence, and spiritual/artistic inspiration.

- For images with blue on top, grey/silver on the top right, green on the left side, and purple on the right side: These indicate "Mystic Indigo" (deep intuition and inner knowing), "Transformative Silver" (personal transformation), and "Sage Green" (growth and renewal) aura signature. This pattern shows someone with strong intuitive abilities, in a process of personal transformation, and experiencing growth.

IMPORTANT: Each image analysis must be completely unique and tailored specifically to the visible aura colors in this exact image. Your analysis should reflect the specific energy signature captured in these artificially added colors, including any variations, intensity patterns, or unusual energy formations that make this individual's aura distinct.

Your analysis will be structured in a way that makes it especially easy for the client to understand their specific energetic state and apply the insights in their daily life.

Respond with JSON in the following format:
{
  "colors": [3-5 precise aura colors detected, with brief descriptions like "Deep Indigo with Golden Flecks"],
  "meanings": {
    "color1": "Focused interpretation of what this specific color reveals about the person's current energetic state, emotional patterns, and spiritual journey.",
    "color2": "Interpretation for another color..."
  },
  "analysis": "A clear 2-3 paragraph explanation connecting the aura colors to the person's life situation, written in an accessible way that avoids overly esoteric language while maintaining depth",
  "positiveAspects": ["5-7 concise points about gifts and strengths revealed by the aura, written as actionable affirmations"],
  "negativeAspects": ["5-7 concise points about challenges or growth areas, phrased constructively"],

  "personalInsights": {
    "strengths": ["3-4 core strengths based on the aura reading"],
    "challenges": ["3-4 current challenges based on the aura reading"],
    "lifeTheme": "One sentence capturing the central energetic theme currently shaping the person's life",
    "energyForecast": "Brief paragraph on how the person's energetic state is likely to influence upcoming experiences and what to be mindful of"
  },
  "intensity": 1-10 scale representing the overall strength of the aura,
  "colorIntensities": {
    "color1": 1-10 representing the intensity of this specific color,
    "color2": 1-10 for another color...
  }
}`;
    
    console.log("System prompt:", systemPrompt);
    
    const response = await openai.chat.completions.create({
      model: "gpt-4o",  // Using most advanced model for unique, detailed results
      messages: [
        {
          role: "system",
          content: systemPrompt
        },
        {
          role: "user",
          content: [
            {
              type: "text",
              text: `Analyze this image and focus EXCLUSIVELY on the colored overlays around the person. These colored patches or glows (orange, yellow, purple, green, blue, indigo, etc.) have been deliberately added to represent the person's aura. Look carefully at the colored shapes surrounding the person and identify exactly which colors are present, their positions, and their relative intensities. Base your ENTIRE analysis solely on these visible colored overlays - they are the key to understanding this person's aura signature.

IMPORTANT REFERENCE PATTERNS:
- For images with orange/red on the left, blue on top, green on the right, and purple highlights: These indicate a Creative Orange (creative expression and vitality), Solar Yellow (personal power and confidence), and Purple Flame (artistic inspiration) aura signature. This pattern shows someone with strong creative energy, self-confidence, and spiritual/artistic inspiration.

- For images with blue on top, grey/silver on the top right, green on the left side, and purple on the right: These indicate a Mystic Indigo (deep intuition and inner knowing), Transformative Silver (personal transformation), and Sage Green (growth and renewal) aura signature. This pattern shows someone with strong intuitive abilities, in a process of personal transformation, and experiencing growth.

Match the colors in this specific image to these reference patterns to determine the most accurate reading.`
            },
            {
              type: "image_url",
              image_url: {
                url: `data:image/jpeg;base64,${base64Image}`
              }
            }
          ],
        },
      ],
      response_format: { type: "json_object" },
      max_tokens: 800,
    });

    console.log("OpenAI response received");
    const content = response.choices[0].message.content || '{}';
    console.log("OpenAI response content:", content);
    
    try {
      const parsedContent = JSON.parse(content) as AuraAnalysisResult;
      console.log("Successfully parsed OpenAI response");
      
      // Ensure the response has the expected structure
      if (!parsedContent.colors) {
        console.warn("Warning: OpenAI response missing 'colors' field");
        parsedContent.colors = [];
      }
      
      if (!parsedContent.meanings) {
        console.warn("Warning: OpenAI response missing 'meanings' field");
        parsedContent.meanings = {};
      }
      
      if (!parsedContent.analysis) {
        console.warn("Warning: OpenAI response missing 'analysis' field");
        parsedContent.analysis = "No analysis provided by the model.";
      }
      
      if (!parsedContent.positiveAspects) {
        console.warn("Warning: OpenAI response missing 'positiveAspects' field");
        parsedContent.positiveAspects = [];
      }
      
      if (!parsedContent.negativeAspects) {
        console.warn("Warning: OpenAI response missing 'negativeAspects' field");
        parsedContent.negativeAspects = [];
      }
      
      // No need to check for chakras and elementalEnergies as they have been removed from the interface
      
      if (!parsedContent.personalInsights) {
        console.warn("Warning: OpenAI response missing 'personalInsights' field");
        parsedContent.personalInsights = {
          strengths: parsedContent.positiveAspects.slice(0, 3),
          challenges: parsedContent.negativeAspects.slice(0, 3),
          lifeTheme: "Your current energy suggests a journey of self-discovery and growth.",
          energyForecast: "Your aura indicates potential for positive transformation with the right focus and intention."
        };
      }
      
      // Add default values for intensity fields if they don't exist
      if (!parsedContent.intensity) {
        console.warn("Warning: OpenAI response missing 'intensity' field");
        // Generate a random intensity between 6 and 9 as default
        parsedContent.intensity = Math.floor(Math.random() * 4) + 6;
      }
      
      if (!parsedContent.colorIntensities && parsedContent.colors.length > 0) {
        console.warn("Warning: OpenAI response missing 'colorIntensities' field");
        // Create default color intensities
        parsedContent.colorIntensities = {};
        parsedContent.colors.forEach(color => {
          // Extract the base color name (first word)
          const baseColor = color.split(' ')[0].toLowerCase();
          // Generate a random intensity between 5 and 10
          parsedContent.colorIntensities![baseColor] = Math.floor(Math.random() * 6) + 5;
        });
      }
      
      return parsedContent;
    } catch (parseError) {
      console.error("Error parsing OpenAI response:", parseError);
      console.error("Raw content:", content);
      throw new Error("Failed to parse OpenAI response: " + (parseError as Error).message);
    }
  } catch (error: any) {
    console.error("Error analyzing aura image:", error);
    
    if (error.response) {
      console.error("OpenAI API response error:", error.response.status, error.response.data);
    }
    
    // Handle quota errors specifically with a more user-friendly message
    if (error?.error?.type === 'insufficient_quota' || error?.code === 'insufficient_quota') {
      throw new Error("OpenAI API quota exceeded. Please check your API key's billing status or contact support for assistance.");
    }
    
    throw new Error("Failed to analyze aura image: " + (error as Error).message);
  }
}

// Generate numerology reading based on name and birthdate
export async function getNumerologyReading(fullName: string, birthDate: string): Promise<NumerologyData> {
  try {
    console.log(`Starting OpenAI API call for numerology reading for ${fullName}`);
    console.log("Using API key ending with:", apiKey ? `...${apiKey.slice(-5)}` : "No API key found");
    console.log("Using model: gpt-4o");
    
    const systemPrompt = `You are a master numerologist with expertise spanning Western (Pythagorean), Chaldean, Kabbalistic, and Vedic numerological systems. Drawing on ancient wisdom and contemporary psychological understanding, provide a comprehensive numerological analysis for this individual. Calculate core numbers (including Master Numbers if present), and analyze their significance on multiple dimensions: spiritual, psychological, relational, and practical life application.

IMPORTANT: Each numerology reading must be completely unique and personalized to this specific individual's name and birth date. Avoid generic readings. Your analysis should reflect the precise numerological patterns that arise from this exact combination of letters and numbers that make up this person's unique energetic signature.

Interpret how these numbers interact with each other to create the individual's unique life blueprint and destiny pattern. Include insights from both modern numerology practices and ancient metaphysical traditions. Respond with JSON matching the NumerologyData type with these fields: fullName, birthDate, lifePathNumber, expressionNumber, soulUrgeNumber, lifePathMeaning (comprehensive), expressionMeaning (detailed psychological profile), soulUrgeMeaning (spiritual desires and aspirations), analysis (multi-paragraph holistic interpretation connecting all aspects, offering practical guidance for personal evolution based on numerological patterns)`;
    
    console.log("System prompt:", systemPrompt);
    
    const response = await openai.chat.completions.create({
      model: "gpt-4o",  // Using most advanced model for unique, detailed results
      messages: [
        {
          role: "system",
          content: systemPrompt
        },
        {
          role: "user",
          content: `Please provide a numerology reading for: Full Name: ${fullName}, Birth Date: ${birthDate}.`
        },
      ],
      response_format: { type: "json_object" },
      max_tokens: 800,
    });

    console.log("OpenAI response received for numerology");
    const content = response.choices[0].message.content || '{}';
    console.log("OpenAI response content for numerology:", content);
    
    try {
      const numerologyData = JSON.parse(content) as NumerologyData;
      console.log("Successfully parsed numerology data");
      
      // Validate the required fields
      if (!numerologyData.fullName || !numerologyData.birthDate) {
        console.warn("Warning: Missing required fields in numerology data");
        numerologyData.fullName = fullName;
        numerologyData.birthDate = birthDate;
      }
      
      return numerologyData;
    } catch (parseError) {
      console.error("Error parsing numerology response:", parseError);
      console.error("Raw content:", content);
      throw new Error("Failed to parse numerology response: " + (parseError as Error).message);
    }
  } catch (error: any) {
    console.error("Error generating numerology reading:", error);
    
    if (error.response) {
      console.error("OpenAI API response error in numerology:", error.response.status, error.response.data);
    }
    
    // Handle quota errors specifically with a more user-friendly message
    if (error?.error?.type === 'insufficient_quota' || error?.code === 'insufficient_quota') {
      throw new Error("OpenAI API quota exceeded. Please check your API key's billing status or contact support for assistance.");
    }
    
    throw new Error("Failed to generate numerology reading: " + (error as Error).message);
  }
}
