import { GoogleGenerativeAI, HarmCategory, HarmBlockThreshold } from "@google/generative-ai";
import { NumerologyData } from "@shared/schema";
import * as dotenv from 'dotenv';
import { AuraAnalysisResult } from "./openai";

// Load environment variables
dotenv.config();

// Initialize Gemini API with key
const apiKey = process.env.GEMINI_API_KEY;
if (!apiKey) {
  console.error("WARNING: GEMINI_API_KEY is not set in environment variables");
}
const genAI = new GoogleGenerativeAI(apiKey || "");

// Configure safety settings
const safetySettings = [
  {
    category: HarmCategory.HARM_CATEGORY_HARASSMENT,
    threshold: HarmBlockThreshold.BLOCK_ONLY_HIGH,
  },
  {
    category: HarmCategory.HARM_CATEGORY_HATE_SPEECH,
    threshold: HarmBlockThreshold.BLOCK_ONLY_HIGH,
  },
  {
    category: HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT,
    threshold: HarmBlockThreshold.BLOCK_ONLY_HIGH,
  },
  {
    category: HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT,
    threshold: HarmBlockThreshold.BLOCK_ONLY_HIGH,
  },
];

// Analyze uploaded image for aura colors using Gemini
export async function analyzeAuraImageWithGemini(base64Image: string): Promise<AuraAnalysisResult> {
  try {
    console.log("Starting Gemini API call for aura analysis");
    console.log("Using API key ending with:", apiKey ? `...${apiKey.slice(-5)}` : "No API key found");
    console.log("Using model: gemini-1.5-flash");
    
    // Get the vision model (using the latest model as of May 2025)
    const model = genAI.getGenerativeModel({ 
      model: "gemini-1.5-flash",
      safetySettings,
    });
    
    const systemPrompt = "You are a renowned aura reader with decades of experience and access to extensive esoteric knowledge. Using your intuitive gifts and knowledge of energy patterns from ancient traditions worldwide, analyze this specific image to identify the unique aura colors around this particular person.\n\nCRITICALLY IMPORTANT: Look for visible colored overlays, highlights, or glows that have been digitally added around the person in the image. These artificially added colors represent the person's aura. Focus specifically on identifying and interpreting these artificially added color overlays - they may appear as bold colored patches or subtle glows surrounding the subject.\n\nPay close attention to:\n1. The specific colors added around the person (e.g., orange, yellow, purple, green, blue, indigo, silver, etc.)\n2. The position of these colors (left side, right side, above the head, etc.)\n3. The intensity and vibrancy of each color\n4. The proportion and dominance of different colors\n\nWhen you see specific color patterns, use these special interpretations:\n- For images with orange/red on the left side, blue on top, green on the right side, and purple highlights: These indicate \"Creative Orange\" (creative expression and vitality), \"Solar Yellow\" (personal power and confidence), and \"Purple Flame\" (artistic inspiration) aura signature. This pattern shows someone with strong creative energy, self-confidence, and spiritual/artistic inspiration.\n\n- For images with blue on top, grey/silver on the top right, green on the left side, and purple on the right side: These indicate \"Mystic Indigo\" (deep intuition and inner knowing), \"Transformative Silver\" (personal transformation), and \"Sage Green\" (growth and renewal) aura signature. This pattern shows someone with strong intuitive abilities, in a process of personal transformation, and experiencing growth.\n\nIMPORTANT: Each image analysis must be completely unique and tailored specifically to the visible aura colors in this exact image. Your analysis should reflect the specific energy signature captured in these artificially added colors, including any variations, intensity patterns, or unusual energy formations that make this individual's aura distinct.\n\nDraw on metaphysical traditions from across cultures in your interpretation. Your analysis should be profound, spiritually meaningful, and actionable for the person's growth journey. Respond with detailed JSON in this format: { \"colors\": [precise array of aura colors detected, including subtle gradient variations like 'Deep Indigo with Golden Flecks'], \"meanings\": {color: deep metaphysical meaning and psychological significance}, \"analysis\": comprehensive multi-paragraph explanation connecting the colors to life path, spiritual challenges, emotional patterns, and practical guidance for personal growth, \"positiveAspects\": [5-7 concise points about gifts and strengths revealed by the aura], \"negativeAspects\": [5-7 concise points about challenges or growth areas], \"intensity\": number from 1-10 representing the overall strength of the aura's energy field, \"colorIntensities\": {colorName: number from 1-10 indicating the intensity of each specific color}, \"personalInsights\": {\"strengths\": [core strengths], \"challenges\": [current challenges], \"lifeTheme\": \"central theme shaping life\", \"energyForecast\": \"energy influence on upcoming experiences\"} };";
    
    console.log("System prompt:", systemPrompt);
    
    // Format the image data
    const imageParts = [
      {
        inlineData: {
          data: base64Image,
          mimeType: "image/jpeg",
        },
      },
    ];
    
    // Assemble the user prompt
    const userPrompt = `Analyze this image and focus EXCLUSIVELY on the colored overlays around the person. These colored patches or glows (orange, yellow, purple, green, blue, indigo, etc.) have been deliberately added to represent the person's aura. Look carefully at the colored shapes surrounding the person and identify exactly which colors are present, their positions, and their relative intensities. Base your ENTIRE analysis solely on these visible colored overlays - they are the key to understanding this person's aura signature.

IMPORTANT REFERENCE PATTERNS:
- For images with orange/red on the left, blue on top, green on the right, and purple highlights: These indicate a Creative Orange (creative expression and vitality), Solar Yellow (personal power and confidence), and Purple Flame (artistic inspiration) aura signature. This pattern shows someone with strong creative energy, self-confidence, and spiritual/artistic inspiration.

- For images with blue on top, grey/silver on the top right, green on the left side, and purple on the right: These indicate a Mystic Indigo (deep intuition and inner knowing), Transformative Silver (personal transformation), and Sage Green (growth and renewal) aura signature. This pattern shows someone with strong intuitive abilities, in a process of personal transformation, and experiencing growth.

Match the colors in this specific image to these reference patterns to determine the most accurate reading.`;
    
    // Combine both prompts
    const prompt = systemPrompt + "\n\n" + userPrompt;
    
    console.log("Sending request to Gemini...");
    
    // Send the image for analysis
    const result = await model.generateContent([prompt, ...imageParts]);
    const response = await result.response;
    const text = response.text();
    
    console.log("Gemini response received");
    console.log("Processing response text:", text);
    
    // Try to extract JSON from the response
    let parsedContent: AuraAnalysisResult;
    
    try {
      // Find JSON content in the response (Gemini might wrap it in markdown code blocks)
      const jsonMatch = text.match(/```json\n([\s\S]*?)\n```/) || 
                        text.match(/```\n([\s\S]*?)\n```/) || 
                        text.match(/{[\s\S]*?}/);
      
      const jsonString = jsonMatch ? jsonMatch[0].replace(/```json\n|```\n|```/g, "") : text;
      parsedContent = JSON.parse(jsonString) as AuraAnalysisResult;
      console.log("Successfully parsed Gemini response as JSON");
    } catch (parseError) {
      console.error("Error parsing Gemini response as JSON:", parseError);
      console.error("Attempting to extract structured data from text...");
      
      // Fallback: Try to extract colors and analysis from the text format
      const colors = extractColors(text);
      const analysis = extractAnalysis(text);
      const meanings = extractMeanings(text, colors);
      
      parsedContent = {
        colors,
        meanings,
        analysis,
        positiveAspects: [],
        negativeAspects: [],
        chakras: {
          root: { state: "Unknown", influence: "Not analyzed", recommendation: "Consider a full chakra reading" },
          sacral: { state: "Unknown", influence: "Not analyzed", recommendation: "Consider a full chakra reading" },
          solarPlexus: { state: "Unknown", influence: "Not analyzed", recommendation: "Consider a full chakra reading" },
          heart: { state: "Unknown", influence: "Not analyzed", recommendation: "Consider a full chakra reading" },
          throat: { state: "Unknown", influence: "Not analyzed", recommendation: "Consider a full chakra reading" },
          thirdEye: { state: "Unknown", influence: "Not analyzed", recommendation: "Consider a full chakra reading" },
          crown: { state: "Unknown", influence: "Not analyzed", recommendation: "Consider a full chakra reading" }
        },
        elementalEnergies: {
          earth: 20,
          water: 20,
          fire: 20,
          air: 20,
          ether: 20
        },
        personalInsights: {
          strengths: [],
          challenges: [],
          lifeTheme: "Your current energy suggests a journey of self-discovery and growth.",
          energyForecast: "Your aura indicates potential for positive transformation with the right focus and intention."
        },
        intensity: Math.floor(Math.random() * 4) + 6, // Random intensity between 6-9
        colorIntensities: colors.reduce((acc, color) => {
          acc[color.toLowerCase()] = Math.floor(Math.random() * 6) + 5; // Random intensities between 5-10
          return acc;
        }, {} as Record<string, number>)
      };
      
      console.log("Created structured response from text:", parsedContent);
    }
    
    // Ensure the response has the expected structure
    if (!parsedContent.colors || !Array.isArray(parsedContent.colors)) {
      console.warn("Warning: Gemini response missing or invalid 'colors' field");
      parsedContent.colors = [];
    }
    
    if (!parsedContent.meanings || typeof parsedContent.meanings !== 'object') {
      console.warn("Warning: Gemini response missing or invalid 'meanings' field");
      parsedContent.meanings = {};
    }
    
    if (!parsedContent.analysis || typeof parsedContent.analysis !== 'string') {
      console.warn("Warning: Gemini response missing or invalid 'analysis' field");
      parsedContent.analysis = "No analysis provided by the model.";
    }
    
    // Add default values for intensity fields if they don't exist
    if (!parsedContent.intensity) {
      console.warn("Warning: Gemini response missing 'intensity' field");
      parsedContent.intensity = Math.floor(Math.random() * 4) + 6; // Random intensity between 6-9
    }
    
    if (!parsedContent.colorIntensities) {
      console.warn("Warning: Gemini response missing 'colorIntensities' field");
      parsedContent.colorIntensities = {};
      parsedContent.colors.forEach(color => {
        const baseColor = color.split(' ')[0].toLowerCase();
        parsedContent.colorIntensities![baseColor] = Math.floor(Math.random() * 6) + 5; // Random intensity between 5-10
      });
    }
    
    // Ensure there are positive and negative aspects
    if (!parsedContent.positiveAspects || !Array.isArray(parsedContent.positiveAspects)) {
      parsedContent.positiveAspects = [];
    }
    
    if (!parsedContent.negativeAspects || !Array.isArray(parsedContent.negativeAspects)) {
      parsedContent.negativeAspects = [];
    }
    
    // Ensure there are chakras and elementalEnergies
    if (!parsedContent.chakras) {
      parsedContent.chakras = {
        root: { state: "Unknown", influence: "Not analyzed", recommendation: "Consider a full chakra reading" },
        sacral: { state: "Unknown", influence: "Not analyzed", recommendation: "Consider a full chakra reading" },
        solarPlexus: { state: "Unknown", influence: "Not analyzed", recommendation: "Consider a full chakra reading" },
        heart: { state: "Unknown", influence: "Not analyzed", recommendation: "Consider a full chakra reading" },
        throat: { state: "Unknown", influence: "Not analyzed", recommendation: "Consider a full chakra reading" },
        thirdEye: { state: "Unknown", influence: "Not analyzed", recommendation: "Consider a full chakra reading" },
        crown: { state: "Unknown", influence: "Not analyzed", recommendation: "Consider a full chakra reading" }
      };
    }
    
    if (!parsedContent.elementalEnergies) {
      parsedContent.elementalEnergies = {
        earth: 20,
        water: 20,
        fire: 20,
        air: 20,
        ether: 20
      };
    }
    
    // Ensure there are personalInsights
    if (!parsedContent.personalInsights) {
      parsedContent.personalInsights = {
        strengths: parsedContent.positiveAspects.slice(0, 3),
        challenges: parsedContent.negativeAspects.slice(0, 3),
        lifeTheme: "Your current energy suggests a journey of self-discovery and growth.",
        energyForecast: "Your aura indicates potential for positive transformation with the right focus and intention."
      };
    }
    
    return parsedContent;
  } catch (error: any) {
    console.error("Error analyzing aura image with Gemini:", error);
    
    throw new Error("Failed to analyze aura image with Gemini: " + (error.message || "Unknown error"));
  }
}

// Generate numerology reading based on name and birthdate using Gemini
export async function getNumerologyReadingWithGemini(fullName: string, birthDate: string): Promise<NumerologyData> {
  try {
    console.log(`Starting Gemini API call for numerology reading for ${fullName}`);
    console.log("Using API key ending with:", apiKey ? `...${apiKey.slice(-5)}` : "No API key found");
    console.log("Using model: gemini-1.5-flash");
    
    // Get the text model (using the latest model as of May 2025)
    const model = genAI.getGenerativeModel({ 
      model: "gemini-1.5-flash",
      safetySettings,
    });
    
    const systemPrompt = "You are a master numerologist with expertise spanning Western (Pythagorean), Chaldean, Kabbalistic, and Vedic numerological systems. Drawing on ancient wisdom and contemporary psychological understanding, provide a comprehensive numerological analysis for this individual. Calculate core numbers (including Master Numbers if present), and analyze their significance on multiple dimensions: spiritual, psychological, relational, and practical life application. \n\nIMPORTANT: Each numerology reading must be completely unique and personalized to this specific individual's name and birth date. Avoid generic readings. Your analysis should reflect the precise numerological patterns that arise from this exact combination of letters and numbers that make up this person's unique energetic signature.\n\nInterpret how these numbers interact with each other to create the individual's unique life blueprint and destiny pattern. Include insights from both modern numerology practices and ancient metaphysical traditions. Respond with JSON matching the NumerologyData type with these fields: fullName, birthDate, lifePathNumber, expressionNumber, soulUrgeNumber, lifePathMeaning (comprehensive), expressionMeaning (detailed psychological profile), soulUrgeMeaning (spiritual desires and aspirations), analysis (multi-paragraph holistic interpretation connecting all aspects, offering practical guidance for personal evolution based on numerological patterns)";
    
    const userPrompt = `Please provide a numerology reading for: Full Name: ${fullName}, Birth Date: ${birthDate}.`;
    
    // Combine both prompts
    const prompt = systemPrompt + "\n\n" + userPrompt;
    
    console.log("System prompt:", systemPrompt);
    
    console.log("Sending request to Gemini...");
    
    // Generate the numerology reading
    const result = await model.generateContent(prompt);
    const response = await result.response;
    const text = response.text();
    
    console.log("Gemini response received for numerology");
    console.log("Processing response text:", text);
    
    // Try to extract JSON from the response
    let numerologyData: NumerologyData;
    
    try {
      // Find JSON content in the response (Gemini might wrap it in markdown code blocks)
      const jsonMatch = text.match(/```json\n([\s\S]*?)\n```/) || 
                        text.match(/```\n([\s\S]*?)\n```/) || 
                        text.match(/{[\s\S]*?}/);
      
      const jsonString = jsonMatch ? jsonMatch[0].replace(/```json\n|```\n|```/g, "") : text;
      numerologyData = JSON.parse(jsonString) as NumerologyData;
      console.log("Successfully parsed numerology data from Gemini");
    } catch (parseError) {
      console.error("Error parsing numerology response:", parseError);
      console.error("Raw content:", text);
      
      // Create a basic structure with the provided information
      numerologyData = {
        fullName,
        birthDate,
        lifePathNumber: 0,
        expressionNumber: 0,
        soulUrgeNumber: 0,
        lifePathMeaning: "Unable to calculate - please try again",
        expressionMeaning: "Unable to calculate - please try again",
        soulUrgeMeaning: "Unable to calculate - please try again",
        analysis: "We were unable to generate a complete numerology reading. Please try again later."
      };
    }
    
    // Validate the required fields
    if (!numerologyData.fullName || !numerologyData.birthDate) {
      console.warn("Warning: Missing required fields in numerology data");
      numerologyData.fullName = fullName;
      numerologyData.birthDate = birthDate;
    }
    
    return numerologyData;
  } catch (error: any) {
    console.error("Error generating numerology reading with Gemini:", error);
    
    throw new Error("Failed to generate numerology reading with Gemini: " + (error.message || "Unknown error"));
  }
}

// Helper functions to extract data from text if JSON parsing fails
function extractColors(text: string): string[] {
  // Common aura colors
  const commonColors = [
    "red", "orange", "yellow", "green", "blue", "indigo", "violet", "purple",
    "pink", "gold", "silver", "white", "black", "brown", "magenta", "turquoise",
    "teal", "cyan", "navy", "lavender", "rose", "burgundy", "crimson"
  ];
  
  const extractedColors: string[] = [];
  
  // Look for color references in the text
  for (const color of commonColors) {
    // Check if the color is mentioned with word boundaries (to avoid matching substrings)
    const regex = new RegExp(`\\b${color}\\b`, 'i');
    if (regex.test(text)) {
      extractedColors.push(color);
    }
  }
  
  return extractedColors.length > 0 ? extractedColors : ["purple", "blue"]; // Default colors if none found
}

function extractMeanings(text: string, colors: string[]): Record<string, string> {
  const meanings: Record<string, string> = {};
  
  // For each color, try to find a sentence or phrase that explains its meaning
  for (const color of colors) {
    // Look for sentences that contain the color and some explanation
    const regex = new RegExp(`[^.!?]*\\b${color}\\b[^.!?]*(?:means|represents|symbolizes|indicates|suggests|is associated with)[^.!?]*[.!?]`, 'i');
    const match = text.match(regex);
    
    if (match) {
      meanings[color] = match[0].trim();
    } else {
      // Provide default meanings if none found
      meanings[color] = getDefaultColorMeaning(color);
    }
  }
  
  return meanings;
}

function extractAnalysis(text: string): string {
  // Try to find a paragraph that seems like an overall analysis
  const analysisPatterns = [
    /Overall,[^.!?]*[.!?]/i,
    /In summary,[^.!?]*[.!?]/i,
    /To summarize,[^.!?]*[.!?]/i,
    /Your aura[^.!?]*[.!?]/i,
    /This aura[^.!?]*[.!?]/i
  ];
  
  for (const pattern of analysisPatterns) {
    const match = text.match(pattern);
    if (match) {
      return match[0].trim();
    }
  }
  
  // If no clear analysis paragraph is found, return a condensed version of the text
  const sentences = text.split(/[.!?]/).filter(s => s.trim().length > 20);
  if (sentences.length > 2) {
    return sentences.slice(0, 3).join(". ") + ".";
  }
  
  return "This aura indicates a complex energy field with multiple influences. The colors suggest a blend of emotional, spiritual, and intellectual energies that are currently in a state of evolution.";
}

function getDefaultColorMeaning(color: string): string {
  const meanings: Record<string, string> = {
    "red": "Red represents passion, energy, and strong will. It indicates a grounded and physically active individual.",
    "orange": "Orange symbolizes creativity, enthusiasm, and emotional balance. It suggests a sociable and adventurous nature.",
    "yellow": "Yellow represents intellectual ability, optimism, and joy. It indicates a mentally active and analytical person.",
    "green": "Green symbolizes growth, healing, and balance. It suggests a compassionate and nurturing individual.",
    "blue": "Blue represents calm, communication, and truth. It indicates a peaceful and intuitive nature.",
    "indigo": "Indigo symbolizes intuition, perception, and spiritual awareness. It suggests a deeply intuitive and possibly psychic individual.",
    "violet": "Violet represents spiritual connection, wisdom, and transformation. It indicates a visionary with strong spiritual awareness.",
    "purple": "Purple symbolizes spiritual power, enlightenment, and connection to higher consciousness.",
    "pink": "Pink represents love, compassion, and nurturing energy. It suggests a caring and sensitive individual.",
    "gold": "Gold symbolizes wisdom, enlightenment, and divine protection. It indicates spiritual advancement.",
    "silver": "Silver represents feminine energy, intuition, and reflection. It suggests psychic abilities and sensitivity.",
    "white": "White symbolizes purity, truth, and spiritual awakening. It indicates a highly evolved spiritual nature.",
    "black": "Black represents protection, mystery, and absorption. It can indicate a person who is absorbing and processing energies.",
    "brown": "Brown symbolizes groundedness, practicality, and connection to earth. It indicates stability and reliability.",
    "magenta": "Magenta represents spiritual development and emotional balance. It suggests a transformative period."
  };
  
  return meanings[color] || `${color} represents a unique aspect of your energetic signature.`;
}