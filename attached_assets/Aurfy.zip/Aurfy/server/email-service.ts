import fs from 'fs';
import path from 'path';
import { promisify } from 'util';

const writeFileAsync = promisify(fs.writeFile);
const mkdirAsync = promisify(fs.mkdir);

/**
 * Email parameters interface
 */
export interface EmailParams {
  to: string;
  from: string;
  subject: string;
  text?: string;
  html?: string;
}

/**
 * Local email service that saves emails to files instead of sending them
 * This is a free alternative to SendGrid for development/demo purposes
 */
export class LocalEmailService {
  private emailsDir: string;

  constructor() {
    this.emailsDir = path.join(process.cwd(), 'emails');
    // Create emails directory if it doesn't exist
    if (!fs.existsSync(this.emailsDir)) {
      fs.mkdirSync(this.emailsDir, { recursive: true });
    }
  }

  /**
   * Save email to a file
   * @param params Email parameters
   * @returns Promise that resolves to true if email was saved successfully
   */
  async saveEmail(params: EmailParams): Promise<boolean> {
    try {
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      const sanitizedTo = params.to.replace(/[@.]/g, '_');
      const filename = `${timestamp}_${sanitizedTo}.json`;
      const filePath = path.join(this.emailsDir, filename);
      
      const emailData = {
        to: params.to,
        from: params.from,
        subject: params.subject,
        text: params.text || '',
        html: params.html || '',
        sentAt: new Date().toISOString()
      };
      
      await writeFileAsync(filePath, JSON.stringify(emailData, null, 2), 'utf8');
      console.log(`Email saved to file: ${filePath}`);
      
      // Also create an HTML preview file
      const htmlFilename = `${timestamp}_${sanitizedTo}.html`;
      const htmlFilePath = path.join(this.emailsDir, htmlFilename);
      
      const htmlPreview = `
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="UTF-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <title>Email Preview</title>
          <style>
            body { font-family: Arial, sans-serif; margin: 0; padding: 20px; color: #333; }
            .email-container { max-width: 600px; margin: 0 auto; border: 1px solid #ddd; border-radius: 5px; overflow: hidden; }
            .email-header { background: #f7f7f7; padding: 15px; border-bottom: 1px solid #ddd; }
            .email-meta { margin: 5px 0; font-size: 14px; color: #666; }
            .email-body { padding: 20px; }
            .email-content { margin-top: 20px; padding-top: 20px; border-top: 1px dashed #ddd; }
          </style>
        </head>
        <body>
          <div class="email-container">
            <div class="email-header">
              <h2>${params.subject}</h2>
              <div class="email-meta"><strong>To:</strong> ${params.to}</div>
              <div class="email-meta"><strong>From:</strong> ${params.from}</div>
              <div class="email-meta"><strong>Date:</strong> ${new Date().toLocaleString()}</div>
            </div>
            <div class="email-body">
              <div class="email-content">
                ${params.html || params.text?.replace(/\n/g, '<br>') || ''}
              </div>
            </div>
          </div>
        </body>
        </html>
      `;
      
      await writeFileAsync(htmlFilePath, htmlPreview, 'utf8');
      
      return true;
    } catch (error) {
      console.error('Error saving email:', error);
      return false;
    }
  }

  /**
   * Get list of saved emails
   * @returns Promise that resolves to array of email filenames
   */
  async getEmailsList(): Promise<string[]> {
    try {
      const files = fs.readdirSync(this.emailsDir);
      return files.filter(file => file.endsWith('.json'));
    } catch (error) {
      console.error('Error getting emails list:', error);
      return [];
    }
  }

  /**
   * Get email content by filename
   * @param filename Email filename
   * @returns Promise that resolves to email content
   */
  async getEmailContent(filename: string): Promise<any | null> {
    try {
      const filePath = path.join(this.emailsDir, filename);
      const fileContent = fs.readFileSync(filePath, 'utf8');
      return JSON.parse(fileContent);
    } catch (error) {
      console.error('Error getting email content:', error);
      return null;
    }
  }
}

// Create and export a singleton instance
export const emailService = new LocalEmailService();