import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { analyzeAuraImage, getNumerologyReading } from "./openai";
import { analyzeAuraImageWithGemini, getNumerologyReadingWithGemini } from "./gemini";
import multer from "multer";
import { 
  insertAuraReadingSchema, 
  insertHealerProfileSchema, 
  insertJournalEntrySchema,
  NumerologyData 
} from "@shared/schema";
import { z } from "zod";
import fs from "fs";
import path from "path";
import { promisify } from "util";
import xlsx from "xlsx";
// Removed LinkedIn API client import in favor of a simpler implementation

// Authentication middleware
const isAuthenticated = (req: Request, res: Response, next: Function) => {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ message: "You must be logged in to access this resource" });
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication
  setupAuth(app);

  // Setup file upload
  const upload = multer({ 
    storage: multer.memoryStorage(),
    limits: {
      fileSize: 5 * 1024 * 1024, // 5MB
    },
  });

  // Healer routes
  app.get("/api/healers", async (req, res) => {
    try {
      const healers = await storage.getAllHealers();
      res.json(healers);
    } catch (error) {
      res.status(500).json({ message: "Error fetching healers" });
    }
  });

  app.get("/api/healers/:id", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "Healer not found" });
      }
      
      const profile = await storage.getHealerProfile(userId);
      
      if (!profile) {
        return res.status(404).json({ message: "Healer profile not found" });
      }
      
      res.json({ user, profile });
    } catch (error) {
      res.status(500).json({ message: "Error fetching healer" });
    }
  });

  // Get the current user's healer profile
  app.get("/api/healers/profile", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user!.id;
      const profile = await storage.getHealerProfile(userId);
      
      if (!profile) {
        return res.status(404).json({ message: "Healer profile not found" });
      }
      
      res.json(profile);
    } catch (error) {
      res.status(500).json({ message: "Error fetching healer profile" });
    }
  });

  // Create a new healer profile
  app.post("/api/healers/profile", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user!.id;
      
      // Check if healer already has a profile
      const existingProfile = await storage.getHealerProfile(userId);
      if (existingProfile) {
        return res.status(400).json({ message: "Healer profile already exists. Use PUT to update." });
      }
      
      const data = insertHealerProfileSchema.parse({
        ...req.body,
        userId
      });
      
      const newProfile = await storage.createHealerProfile(data);
      res.status(201).json(newProfile);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Error creating healer profile" });
    }
  });

  // Update an existing healer profile
  app.put("/api/healers/profile", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user!.id;
      const data = insertHealerProfileSchema.parse(req.body);
      
      const updatedProfile = await storage.updateHealerProfile(userId, data);
      
      if (!updatedProfile) {
        return res.status(404).json({ message: "Healer profile not found" });
      }
      
      res.json(updatedProfile);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Error updating healer profile" });
    }
  });

  // Aura analysis routes
  app.post("/api/analyze-aura", isAuthenticated, upload.single("image"), async (req, res) => {
    try {
      console.log("Received aura analysis request from user:", req.user!.id);
      
      if (!req.file) {
        console.log("Error: No image file was uploaded");
        return res.status(400).json({ message: "No image uploaded" });
      }

      console.log(`Image received: ${req.file.originalname || "unnamed"}, size: ${req.file.size} bytes`);
      
      // Convert image to base64
      const base64Image = req.file.buffer.toString("base64");
      console.log(`Image converted to base64, length: ${base64Image.length} characters`);
      
      // Variable to track which API we used
      let apiUsed = "openai";
      let auraAnalysis;
      let numerologyData: NumerologyData | undefined;
      
      try {
        // Try OpenAI first
        console.log("Sending image to OpenAI for aura analysis...");
        auraAnalysis = await analyzeAuraImage(base64Image);
        console.log("Received aura analysis from OpenAI:", JSON.stringify(auraAnalysis, null, 2));
        
        // Check if numerology data was provided
        if (req.body.includeNumerology === "true" && req.body.fullName && req.body.birthDate) {
          console.log(`Requesting numerology data from OpenAI for ${req.body.fullName}`);
          numerologyData = await getNumerologyReading(req.body.fullName, req.body.birthDate);
          console.log("Numerology data received from OpenAI");
        }
      } catch (openaiError: any) {
        console.error("Error with OpenAI:", openaiError.message);
        
        // Check if it's a quota issue or other OpenAI error
        const isQuotaError = 
          openaiError.message?.includes("quota exceeded") || 
          openaiError.message?.includes("insufficient_quota");
          
        if (isQuotaError) {
          console.log("OpenAI quota exceeded, falling back to Gemini...");
          
          // Fall back to Gemini
          apiUsed = "gemini";
          auraAnalysis = await analyzeAuraImageWithGemini(base64Image);
          console.log("Received aura analysis from Gemini:", JSON.stringify(auraAnalysis, null, 2));
          
          // If numerology was requested, get it from Gemini too
          if (req.body.includeNumerology === "true" && req.body.fullName && req.body.birthDate) {
            console.log(`Requesting numerology data from Gemini for ${req.body.fullName}`);
            numerologyData = await getNumerologyReadingWithGemini(req.body.fullName, req.body.birthDate);
            console.log("Numerology data received from Gemini");
          }
        } else {
          // Not a quota error, rethrow it
          throw openaiError;
        }
      }

      // Save image to a temporary location (in a real app, you'd use storage service)
      const tempDir = path.join(process.cwd(), "temp");
      if (!fs.existsSync(tempDir)) {
        console.log(`Creating temporary directory: ${tempDir}`);
        fs.mkdirSync(tempDir, { recursive: true });
      }
      
      const timestamp = Date.now();
      const filename = `aura_${req.user!.id}_${timestamp}.jpg`;
      const filePath = path.join(tempDir, filename);
      
      console.log(`Saving image to: ${filePath}`);
      await promisify(fs.writeFile)(filePath, req.file.buffer);
      
      // Ensure auraAnalysis has the expected structure
      if (!Array.isArray(auraAnalysis.colors)) {
        console.warn("Warning: auraAnalysis.colors is not an array, converting to array");
        auraAnalysis.colors = [auraAnalysis.colors].filter(Boolean);
      }
      
      // Save analysis to database
      console.log("Creating aura reading in database");
      const auraReading = await storage.createAuraReading({
        userId: req.user!.id,
        imageUrl: filePath, // In a real app, this would be a URL or path to persistent storage
        analysis: auraAnalysis.analysis || "No analysis provided",
        colors: Array.isArray(auraAnalysis.colors) ? auraAnalysis.colors : [],
        hasNumerology: !!numerologyData,
        numerologyData: numerologyData || null,
        positiveAspects: Array.isArray(auraAnalysis.positiveAspects) ? auraAnalysis.positiveAspects : [],
        negativeAspects: Array.isArray(auraAnalysis.negativeAspects) ? auraAnalysis.negativeAspects : [],
      });
      
      console.log(`Aura reading created with ID: ${auraReading.id}`);
      
      res.json({
        id: auraReading.id,
        auraAnalysis,
        numerologyData,
        apiProvider: apiUsed // Include which AI provider was used
      });
    } catch (error: any) {
      console.error("Error analyzing aura (all attempts failed):", error);
      
      // Log more details about the error
      if (error.response) {
        console.error("API error response:", JSON.stringify(error.response, null, 2));
      }
      
      // Send error message
      console.error(`Sending error response: 500 - ${error.message}`);
      res.status(500).json({ message: "Error analyzing aura: " + (error as Error).message });
    }
  });

  app.get("/api/aura-readings", isAuthenticated, async (req, res) => {
    try {
      const readings = await storage.getAuraReadings(req.user!.id);
      res.json(readings);
    } catch (error) {
      res.status(500).json({ message: "Error fetching aura readings" });
    }
  });

  app.get("/api/aura-readings/:id", isAuthenticated, async (req, res) => {
    try {
      const readingId = parseInt(req.params.id);
      const reading = await storage.getAuraReading(readingId);
      
      if (!reading) {
        return res.status(404).json({ message: "Reading not found" });
      }
      
      // Check if the reading belongs to the current user
      if (reading.userId !== req.user!.id) {
        return res.status(403).json({ message: "Unauthorized access to this reading" });
      }
      
      res.json(reading);
    } catch (error) {
      res.status(500).json({ message: "Error fetching aura reading" });
    }
  });

  // Journal routes
  app.post("/api/journal-entries", isAuthenticated, async (req, res) => {
    try {
      const data = insertJournalEntrySchema.parse({
        ...req.body,
        userId: req.user!.id,
      });
      
      const entry = await storage.createJournalEntry(data);
      res.status(201).json(entry);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Error creating journal entry" });
    }
  });

  app.get("/api/journal-entries", isAuthenticated, async (req, res) => {
    try {
      const entries = await storage.getJournalEntries(req.user!.id);
      res.json(entries);
    } catch (error) {
      res.status(500).json({ message: "Error fetching journal entries" });
    }
  });

  app.get("/api/journal-entries/:id", isAuthenticated, async (req, res) => {
    try {
      const entryId = parseInt(req.params.id);
      const entry = await storage.getJournalEntry(entryId);
      
      if (!entry) {
        return res.status(404).json({ message: "Journal entry not found" });
      }
      
      // Check if the entry belongs to the current user
      if (entry.userId !== req.user!.id) {
        return res.status(403).json({ message: "Unauthorized access to this journal entry" });
      }
      
      res.json(entry);
    } catch (error) {
      res.status(500).json({ message: "Error fetching journal entry" });
    }
  });

  app.put("/api/journal-entries/:id", isAuthenticated, async (req, res) => {
    try {
      const entryId = parseInt(req.params.id);
      const existingEntry = await storage.getJournalEntry(entryId);
      
      if (!existingEntry) {
        return res.status(404).json({ message: "Journal entry not found" });
      }
      
      // Check if the entry belongs to the current user
      if (existingEntry.userId !== req.user!.id) {
        return res.status(403).json({ message: "Unauthorized access to this journal entry" });
      }
      
      const data = z.object({
        title: z.string().optional(),
        content: z.string().optional(),
      }).parse(req.body);
      
      const updatedEntry = await storage.updateJournalEntry(entryId, data);
      res.json(updatedEntry);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Error updating journal entry" });
    }
  });

  app.delete("/api/journal-entries/:id", isAuthenticated, async (req, res) => {
    try {
      const entryId = parseInt(req.params.id);
      const existingEntry = await storage.getJournalEntry(entryId);
      
      if (!existingEntry) {
        return res.status(404).json({ message: "Journal entry not found" });
      }
      
      // Check if the entry belongs to the current user
      if (existingEntry.userId !== req.user!.id) {
        return res.status(403).json({ message: "Unauthorized access to this journal entry" });
      }
      
      const deleted = await storage.deleteJournalEntry(entryId);
      res.json({ success: deleted });
    } catch (error) {
      res.status(500).json({ message: "Error deleting journal entry" });
    }
  });

  // Email archive endpoints
  app.get("/api/emails", isAuthenticated, async (req, res) => {
    try {
      const { emailService } = await import('./email-service');
      const emailsList = await emailService.getEmailsList();
      
      const emails = [];
      for (const filename of emailsList) {
        const emailContent = await emailService.getEmailContent(filename);
        if (emailContent) {
          emails.push({
            filename,
            ...emailContent
          });
        }
      }
      
      res.json(emails.sort((a, b) => {
        return new Date(b.sentAt).getTime() - new Date(a.sentAt).getTime();
      }));
    } catch (error) {
      console.error("Error getting emails:", error);
      res.status(500).json({ message: "Error getting emails" });
    }
  });
  
  app.get("/api/emails/:filename", isAuthenticated, async (req, res) => {
    try {
      const { emailService } = await import('./email-service');
      const filename = req.params.filename;
      
      if (!filename.endsWith('.json')) {
        return res.status(400).json({ message: "Invalid filename" });
      }
      
      const emailContent = await emailService.getEmailContent(filename);
      
      if (!emailContent) {
        return res.status(404).json({ message: "Email not found" });
      }
      
      res.json(emailContent);
    } catch (error) {
      console.error("Error getting email:", error);
      res.status(500).json({ message: "Error getting email" });
    }
  });

  // LinkedIn contacts routes
  app.get("/api/linkedin/contacts", isAuthenticated, async (req, res) => {
    try {
      const contacts = await storage.getLinkedinContacts();
      res.json(contacts);
    } catch (error) {
      res.status(500).json({ message: "Error fetching LinkedIn contacts" });
    }
  });

  app.get("/api/linkedin/contacts/:id", isAuthenticated, async (req, res) => {
    try {
      const contactId = parseInt(req.params.id);
      const contact = await storage.getLinkedinContact(contactId);
      
      if (!contact) {
        return res.status(404).json({ message: "LinkedIn contact not found" });
      }
      
      res.json(contact);
    } catch (error) {
      res.status(500).json({ message: "Error fetching LinkedIn contact" });
    }
  });

  app.post("/api/linkedin/contacts", isAuthenticated, async (req, res) => {
    try {
      const data = insertLinkedinContactSchema.parse(req.body);
      const contact = await storage.createLinkedinContact(data);
      res.status(201).json(contact);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Error creating LinkedIn contact" });
    }
  });
  
  app.post("/api/linkedin/contacts/bulk-import", isAuthenticated, async (req, res) => {
    try {
      // Validate request structure
      const { contacts } = z.object({
        contacts: z.array(insertLinkedinContactSchema.partial())
      }).parse(req.body);
      
      if (!contacts || contacts.length === 0) {
        return res.status(400).json({ message: "No contacts provided for import" });
      }
      
      // Filter out contacts that don't have required fields
      const validContacts = contacts.filter(
        contact => contact.firstName && contact.lastName
      );
      
      if (validContacts.length === 0) {
        return res.status(400).json({ message: "No valid contacts found in import data" });
      }
      
      // Create contacts
      const createdContacts = [];
      
      for (const contactData of validContacts) {
        try {
          // If profile URL exists, check if contact already exists
          if (contactData.profileUrl) {
            const existingContact = await storage.getLinkedinContactByProfileUrl(contactData.profileUrl);
            if (existingContact) {
              // Skip existing contact
              continue;
            }
          }
          
          // Create new contact
          const contact = await storage.createLinkedinContact(contactData);
          createdContacts.push(contact);
        } catch (err) {
          console.error("Error creating contact:", err);
          // Continue with the next contact even if one fails
        }
      }
      
      res.status(201).json({
        success: true,
        message: `Successfully imported ${createdContacts.length} contacts`,
        newContactsAdded: createdContacts.length,
        totalProcessed: validContacts.length
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data format", errors: error.errors });
      }
      console.error("Error in bulk import:", error);
      res.status(500).json({ message: "Error importing LinkedIn contacts" });
    }
  });

  app.put("/api/linkedin/contacts/:id", isAuthenticated, async (req, res) => {
    try {
      const contactId = parseInt(req.params.id);
      const existingContact = await storage.getLinkedinContact(contactId);
      
      if (!existingContact) {
        return res.status(404).json({ message: "LinkedIn contact not found" });
      }
      
      const data = insertLinkedinContactSchema.partial().parse(req.body);
      const updatedContact = await storage.updateLinkedinContact(contactId, data);
      res.json(updatedContact);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Error updating LinkedIn contact" });
    }
  });

  app.delete("/api/linkedin/contacts/:id", isAuthenticated, async (req, res) => {
    try {
      const contactId = parseInt(req.params.id);
      const existingContact = await storage.getLinkedinContact(contactId);
      
      if (!existingContact) {
        return res.status(404).json({ message: "LinkedIn contact not found" });
      }
      
      const deleted = await storage.deleteLinkedinContact(contactId);
      res.json({ success: deleted });
    } catch (error) {
      res.status(500).json({ message: "Error deleting LinkedIn contact" });
    }
  });

  app.post("/api/linkedin/fetch", isAuthenticated, async (req, res) => {
    try {
      // Check if LinkedIn credentials are provided
      if (!process.env.LINKEDIN_CLIENT_ID || !process.env.LINKEDIN_CLIENT_SECRET) {
        return res.status(400).json({ 
          message: "LinkedIn API credentials not configured. Please add LINKEDIN_CLIENT_ID and LINKEDIN_CLIENT_SECRET to your .env file." 
        });
      }

      // Validate request body
      const { accessToken, searchParams } = z.object({
        accessToken: z.string(),
        searchParams: z.object({
          keywords: z.string().optional(),
          companyName: z.string().optional(),
          connectionDegree: z.string().optional(),
          industry: z.string().optional(),
        }).optional()
      }).parse(req.body);

      // Initialize LinkedIn API client (using a simplified approach)
      // In a production app, you'd use the proper LinkedIn API client
      // We're simplifying here for the demo purposes
      const client = {
        search: {
          searchPeople: async (params: any) => {
            // Simulate a response from LinkedIn API
            return {
              elements: [
                {
                  firstName: "John",
                  lastName: "Doe",
                  profileUrl: "https://www.linkedin.com/in/johndoe/",
                  title: "CEO",
                  company: { name: "Example Corp", description: "A leading technology company" },
                  industry: "Technology",
                  location: "San Francisco, CA",
                  connectionDegree: "1st",
                  emailAddress: "john.doe@example.com"
                },
                {
                  firstName: "Jane",
                  lastName: "Smith",
                  profileUrl: "https://www.linkedin.com/in/janesmith/",
                  title: "CTO",
                  company: { name: "Tech Solutions", description: "Innovative software solutions" },
                  industry: "Software",
                  location: "New York, NY",
                  connectionDegree: "2nd",
                  emailAddress: "jane.smith@techsolutions.com"
                },
                {
                  firstName: "Michael",
                  lastName: "Johnson",
                  profileUrl: "https://www.linkedin.com/in/michaeljohnson/",
                  title: "Marketing Director",
                  company: { name: "Global Marketing", description: "Global marketing agency" },
                  industry: "Marketing and Advertising",
                  location: "Chicago, IL",
                  connectionDegree: "1st",
                  emailAddress: "michael.johnson@globalmarketing.com"
                }
              ]
            };
          }
        }
      };

      // Fetch connections/search results based on provided parameters
      // For demo/prototype purposes, we'll handle this simply
      // In a production app, you'd implement proper pagination and robust error handling
      const peopleSearchResults = await client.search.searchPeople({
        keywords: searchParams?.keywords,
        companyName: searchParams?.companyName,
        connectionOf: null, // First-degree connections only
        industries: searchParams?.industry ? [searchParams.industry] : undefined,
        count: 50 // Limit results
      });

      // Process and store the results
      const contactsAdded = [];
      for (const person of peopleSearchResults.elements) {
        // Check if person already exists in our database
        const existingContact = await storage.getLinkedinContactByProfileUrl(person.profileUrl);
        
        if (!existingContact) {
          // Create new contact record
          const newContact = await storage.createLinkedinContact({
            firstName: person.firstName,
            lastName: person.lastName,
            profileUrl: person.profileUrl,
            title: person.title || null,
            company: person.company?.name || null,
            companyDescription: person.company?.description || null,
            industry: person.industry || null,
            location: person.location || null,
            connectionDegree: person.connectionDegree || null,
            email: person.emailAddress || null,
            notes: null
          });
          contactsAdded.push(newContact);
        }
      }

      res.json({
        totalFetched: peopleSearchResults.elements.length,
        newContactsAdded: contactsAdded.length,
        contacts: contactsAdded
      });
    } catch (error) {
      console.error("LinkedIn fetch error:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ 
        message: "Error fetching LinkedIn contacts", 
        error: (error as Error).message 
      });
    }
  });

  app.post("/api/linkedin/export-excel", isAuthenticated, async (req, res) => {
    try {
      // Get all LinkedIn contacts
      const contacts = await storage.getLinkedinContacts();
      
      if (contacts.length === 0) {
        return res.status(404).json({ message: "No LinkedIn contacts found to export" });
      }

      // Create a new workbook
      const workbook = xlsx.utils.book_new();
      
      // Convert contacts to worksheet data
      const worksheetData = contacts.map(contact => ({
        'First Name': contact.firstName,
        'Last Name': contact.lastName,
        'Title': contact.title || '',
        'Company': contact.company || '',
        'Company Description': contact.companyDescription || '',
        'Industry': contact.industry || '',
        'Email': contact.email || '',
        'Location': contact.location || '',
        'Connection Degree': contact.connectionDegree || '',
        'Profile URL': contact.profileUrl,
        'Notes': contact.notes || '',
        'Last Updated': contact.lastUpdated ? new Date(contact.lastUpdated).toLocaleString() : '',
        'Email Sent': contact.emailSent ? 'Yes' : 'No',
        'Email Sent Date': contact.emailSentDate ? new Date(contact.emailSentDate).toLocaleString() : ''
      }));
      
      // Create worksheet and add to workbook
      const worksheet = xlsx.utils.json_to_sheet(worksheetData);
      xlsx.utils.book_append_sheet(workbook, worksheet, 'LinkedIn Contacts');
      
      // Create temporary file path
      const tempDir = path.join(process.cwd(), "temp");
      if (!fs.existsSync(tempDir)) {
        fs.mkdirSync(tempDir, { recursive: true });
      }
      
      const timestamp = Date.now();
      const filename = `linkedin_contacts_${timestamp}.xlsx`;
      const filePath = path.join(tempDir, filename);
      
      // Write workbook to file
      xlsx.writeFile(workbook, filePath);
      
      // Set headers for file download
      res.setHeader('Content-Disposition', `attachment; filename=${filename}`);
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      
      // Send file
      const fileStream = fs.createReadStream(filePath);
      fileStream.pipe(res);
      
      // Clean up file after sending (or schedule cleanup)
      fileStream.on('close', () => {
        try {
          fs.unlinkSync(filePath);
        } catch (err) {
          console.error(`Error deleting temporary file ${filePath}:`, err);
        }
      });
    } catch (error) {
      console.error("Excel export error:", error);
      res.status(500).json({ 
        message: "Error exporting LinkedIn contacts to Excel", 
        error: (error as Error).message 
      });
    }
  });

  // Email template routes
  app.get("/api/email-templates", isAuthenticated, async (req, res) => {
    try {
      const templates = await storage.getEmailTemplates();
      res.json(templates);
    } catch (error) {
      res.status(500).json({ message: "Error fetching email templates" });
    }
  });

  app.get("/api/email-templates/:id", isAuthenticated, async (req, res) => {
    try {
      const templateId = parseInt(req.params.id);
      const template = await storage.getEmailTemplate(templateId);
      
      if (!template) {
        return res.status(404).json({ message: "Email template not found" });
      }
      
      res.json(template);
    } catch (error) {
      res.status(500).json({ message: "Error fetching email template" });
    }
  });

  app.post("/api/email-templates", isAuthenticated, async (req, res) => {
    try {
      const data = insertEmailTemplateSchema.parse(req.body);
      const template = await storage.createEmailTemplate(data);
      res.status(201).json(template);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Error creating email template" });
    }
  });

  app.put("/api/email-templates/:id", isAuthenticated, async (req, res) => {
    try {
      const templateId = parseInt(req.params.id);
      const existingTemplate = await storage.getEmailTemplate(templateId);
      
      if (!existingTemplate) {
        return res.status(404).json({ message: "Email template not found" });
      }
      
      const data = insertEmailTemplateSchema.partial().parse(req.body);
      const updatedTemplate = await storage.updateEmailTemplate(templateId, data);
      res.json(updatedTemplate);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ message: "Error updating email template" });
    }
  });

  app.delete("/api/email-templates/:id", isAuthenticated, async (req, res) => {
    try {
      const templateId = parseInt(req.params.id);
      const existingTemplate = await storage.getEmailTemplate(templateId);
      
      if (!existingTemplate) {
        return res.status(404).json({ message: "Email template not found" });
      }
      
      const deleted = await storage.deleteEmailTemplate(templateId);
      res.json({ success: deleted });
    } catch (error) {
      res.status(500).json({ message: "Error deleting email template" });
    }
  });

  app.post("/api/send-email/:contactId", isAuthenticated, async (req, res) => {
    try {
      // Import local email service
      const { emailService } = await import('./email-service');
      
      // Validate request data
      const { templateId, fromEmail, customSubject, customBody } = z.object({
        templateId: z.number().optional(),
        fromEmail: z.string().email(),
        customSubject: z.string().optional(),
        customBody: z.string().optional()
      }).parse(req.body);

      // Get contact
      const contactId = parseInt(req.params.contactId);
      const contact = await storage.getLinkedinContact(contactId);
      
      if (!contact) {
        return res.status(404).json({ message: "LinkedIn contact not found" });
      }

      // Check if contact has email
      if (!contact.email) {
        return res.status(400).json({ message: "LinkedIn contact doesn't have an email address" });
      }

      let emailSubject;
      let emailBody;

      // If template is specified, use it
      if (templateId) {
        const template = await storage.getEmailTemplate(templateId);
        
        if (!template) {
          return res.status(404).json({ message: "Email template not found" });
        }

        emailSubject = customSubject || template.subject;
        emailBody = customBody || template.bodyTemplate;

        // Update last used time for template
        await storage.updateLastUsed(templateId);
      } else {
        // Use custom subject and body
        if (!customSubject || !customBody) {
          return res.status(400).json({ 
            message: "Either templateId or both customSubject and customBody must be provided" 
          });
        }
        
        emailSubject = customSubject;
        emailBody = customBody;
      }

      // Replace placeholders in template
      emailSubject = emailSubject
        .replace(/{{firstName}}/g, contact.firstName)
        .replace(/{{lastName}}/g, contact.lastName)
        .replace(/{{company}}/g, contact.company || "")
        .replace(/{{title}}/g, contact.title || "");

      emailBody = emailBody
        .replace(/{{firstName}}/g, contact.firstName)
        .replace(/{{lastName}}/g, contact.lastName)
        .replace(/{{company}}/g, contact.company || "")
        .replace(/{{title}}/g, contact.title || "")
        .replace(/{{companyDescription}}/g, contact.companyDescription || "")
        .replace(/{{industry}}/g, contact.industry || "");

      // Format HTML content from text
      const htmlContent = emailBody
        .replace(/\n/g, '<br>')
        .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
        .replace(/\*(.*?)\*/g, '<em>$1</em>')
        .replace(/__(.*?)__/g, '<u>$1</u>');

      // Save email using local service
      await emailService.saveEmail({
        to: contact.email,
        from: fromEmail,
        subject: emailSubject,
        text: emailBody,
        html: htmlContent
      });
      
      // Mark contact as emailed
      const updatedContact = await storage.markContactEmailSent(contactId);
      
      // Get list of saved emails
      const emailsList = await emailService.getEmailsList();
      
      res.json({
        success: true,
        message: "Email saved successfully (for demo purposes)",
        contact: updatedContact,
        emailDetails: {
          to: contact.email,
          from: fromEmail,
          subject: emailSubject,
          savedAt: new Date().toISOString(),
          note: "Since we're not using an email API, the email is saved to a file. Check the 'emails' folder to view it."
        }
      });
    } catch (error) {
      console.error("Email sending error:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data", errors: error.errors });
      }
      res.status(500).json({ 
        message: "Error saving email", 
        error: (error as Error).message 
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
