import { 
  users, User, InsertUser, 
  healerProfiles, HealerProfile, InsertHealerProfile, 
  auraReadings, AuraReading, InsertAuraReading, 
  journalEntries, JournalEntry, InsertJournalEntry,
  linkedinContacts, LinkedinContact, InsertLinkedinContact,
  emailTemplates, EmailTemplate, InsertEmailTemplate,
  UserType 
} from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  // User related operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Healer profile operations
  getHealerProfile(userId: number): Promise<HealerProfile | undefined>;
  createHealerProfile(profile: InsertHealerProfile): Promise<HealerProfile>;
  updateHealerProfile(userId: number, profile: Partial<InsertHealerProfile>): Promise<HealerProfile | undefined>;
  getAllHealers(): Promise<(User & { profile: HealerProfile })[]>;
  
  // Aura reading operations
  getAuraReadings(userId: number): Promise<AuraReading[]>;
  getAuraReading(id: number): Promise<AuraReading | undefined>;
  createAuraReading(reading: InsertAuraReading): Promise<AuraReading>;
  
  // Journal operations
  getJournalEntries(userId: number): Promise<JournalEntry[]>;
  getJournalEntry(id: number): Promise<JournalEntry | undefined>;
  createJournalEntry(entry: InsertJournalEntry): Promise<JournalEntry>;
  updateJournalEntry(id: number, entry: Partial<InsertJournalEntry>): Promise<JournalEntry | undefined>;
  deleteJournalEntry(id: number): Promise<boolean>;
  
  // LinkedIn contacts operations
  getLinkedinContacts(): Promise<LinkedinContact[]>;
  getLinkedinContact(id: number): Promise<LinkedinContact | undefined>;
  getLinkedinContactByProfileUrl(profileUrl: string): Promise<LinkedinContact | undefined>;
  createLinkedinContact(contact: InsertLinkedinContact): Promise<LinkedinContact>;
  updateLinkedinContact(id: number, contact: Partial<InsertLinkedinContact>): Promise<LinkedinContact | undefined>;
  deleteLinkedinContact(id: number): Promise<boolean>;
  markContactEmailSent(id: number): Promise<LinkedinContact | undefined>;
  
  // Email template operations
  getEmailTemplates(): Promise<EmailTemplate[]>;
  getEmailTemplate(id: number): Promise<EmailTemplate | undefined>;
  getEmailTemplateByName(name: string): Promise<EmailTemplate | undefined>;
  createEmailTemplate(template: InsertEmailTemplate): Promise<EmailTemplate>;
  updateEmailTemplate(id: number, template: Partial<InsertEmailTemplate>): Promise<EmailTemplate | undefined>;
  deleteEmailTemplate(id: number): Promise<boolean>;
  updateLastUsed(id: number): Promise<EmailTemplate | undefined>;
  
  sessionStore: any; // Express session store
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private healerProfiles: Map<number, HealerProfile>;
  private auraReadings: Map<number, AuraReading>;
  private journalEntries: Map<number, JournalEntry>;
  private linkedinContacts: Map<number, LinkedinContact>;
  private emailTemplates: Map<number, EmailTemplate>;
  sessionStore: any; // Fixed SessionStore type issue
  
  currentUserId: number;
  currentHealerProfileId: number;
  currentAuraReadingId: number;
  currentJournalEntryId: number;
  currentLinkedinContactId: number;
  currentEmailTemplateId: number;

  constructor() {
    this.users = new Map();
    this.healerProfiles = new Map();
    this.auraReadings = new Map();
    this.journalEntries = new Map();
    this.linkedinContacts = new Map();
    this.emailTemplates = new Map();
    
    this.currentUserId = 1;
    this.currentHealerProfileId = 1;
    this.currentAuraReadingId = 1;
    this.currentJournalEntryId = 1;
    this.currentLinkedinContactId = 1;
    this.currentEmailTemplateId = 1;
    
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000, // 24 hours
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username.toLowerCase() === username.toLowerCase(),
    );
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email.toLowerCase() === email.toLowerCase(),
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const now = new Date();
    const user: User = { ...insertUser, id, createdAt: now };
    this.users.set(id, user);
    return user;
  }

  // Healer profile operations
  async getHealerProfile(userId: number): Promise<HealerProfile | undefined> {
    return Array.from(this.healerProfiles.values()).find(
      (profile) => profile.userId === userId
    );
  }

  async createHealerProfile(profile: InsertHealerProfile): Promise<HealerProfile> {
    const id = this.currentHealerProfileId++;
    const healerProfile: HealerProfile = { ...profile, id };
    this.healerProfiles.set(id, healerProfile);
    return healerProfile;
  }

  async updateHealerProfile(userId: number, updates: Partial<InsertHealerProfile>): Promise<HealerProfile | undefined> {
    const profile = await this.getHealerProfile(userId);
    if (!profile) return undefined;
    
    const updatedProfile: HealerProfile = { ...profile, ...updates };
    this.healerProfiles.set(profile.id, updatedProfile);
    return updatedProfile;
  }

  async getAllHealers(): Promise<(User & { profile: HealerProfile })[]> {
    const healerUsers = Array.from(this.users.values()).filter(
      (user) => user.type === UserType.HEALER
    );
    
    return healerUsers.map(user => {
      const profile = Array.from(this.healerProfiles.values()).find(
        (profile) => profile.userId === user.id
      );
      
      if (!profile) {
        throw new Error(`Healer ${user.id} has no profile`);
      }
      
      return { ...user, profile };
    });
  }

  // Aura reading operations
  async getAuraReadings(userId: number): Promise<AuraReading[]> {
    return Array.from(this.auraReadings.values())
      .filter((reading) => reading.userId === userId)
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }

  async getAuraReading(id: number): Promise<AuraReading | undefined> {
    return this.auraReadings.get(id);
  }

  async createAuraReading(reading: InsertAuraReading): Promise<AuraReading> {
    const id = this.currentAuraReadingId++;
    const now = new Date();
    const auraReading: AuraReading = { ...reading, id, date: now };
    this.auraReadings.set(id, auraReading);
    return auraReading;
  }

  // Journal operations
  async getJournalEntries(userId: number): Promise<JournalEntry[]> {
    return Array.from(this.journalEntries.values())
      .filter((entry) => entry.userId === userId)
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }

  async getJournalEntry(id: number): Promise<JournalEntry | undefined> {
    return this.journalEntries.get(id);
  }

  async createJournalEntry(entry: InsertJournalEntry): Promise<JournalEntry> {
    const id = this.currentJournalEntryId++;
    const now = new Date();
    const journalEntry: JournalEntry = { ...entry, id, date: now };
    this.journalEntries.set(id, journalEntry);
    return journalEntry;
  }

  async updateJournalEntry(id: number, updates: Partial<InsertJournalEntry>): Promise<JournalEntry | undefined> {
    const entry = await this.getJournalEntry(id);
    if (!entry) return undefined;
    
    const updatedEntry: JournalEntry = { ...entry, ...updates };
    this.journalEntries.set(id, updatedEntry);
    return updatedEntry;
  }

  async deleteJournalEntry(id: number): Promise<boolean> {
    return this.journalEntries.delete(id);
  }

  // LinkedIn contacts operations
  async getLinkedinContacts(): Promise<LinkedinContact[]> {
    return Array.from(this.linkedinContacts.values())
      .sort((a, b) => new Date(b.lastUpdated).getTime() - new Date(a.lastUpdated).getTime());
  }

  async getLinkedinContact(id: number): Promise<LinkedinContact | undefined> {
    return this.linkedinContacts.get(id);
  }

  async getLinkedinContactByProfileUrl(profileUrl: string): Promise<LinkedinContact | undefined> {
    return Array.from(this.linkedinContacts.values()).find(
      (contact) => contact.profileUrl.toLowerCase() === profileUrl.toLowerCase()
    );
  }

  async createLinkedinContact(contact: InsertLinkedinContact): Promise<LinkedinContact> {
    const id = this.currentLinkedinContactId++;
    const now = new Date();
    const linkedinContact: LinkedinContact = { 
      ...contact, 
      id, 
      lastUpdated: now, 
      emailSent: false,
      emailSentDate: null
    };
    this.linkedinContacts.set(id, linkedinContact);
    return linkedinContact;
  }

  async updateLinkedinContact(id: number, updates: Partial<InsertLinkedinContact>): Promise<LinkedinContact | undefined> {
    const contact = await this.getLinkedinContact(id);
    if (!contact) return undefined;
    
    const now = new Date();
    const updatedContact: LinkedinContact = { 
      ...contact, 
      ...updates, 
      lastUpdated: now 
    };
    this.linkedinContacts.set(id, updatedContact);
    return updatedContact;
  }

  async deleteLinkedinContact(id: number): Promise<boolean> {
    return this.linkedinContacts.delete(id);
  }

  async markContactEmailSent(id: number): Promise<LinkedinContact | undefined> {
    const contact = await this.getLinkedinContact(id);
    if (!contact) return undefined;
    
    const now = new Date();
    const updatedContact: LinkedinContact = { 
      ...contact, 
      emailSent: true, 
      emailSentDate: now 
    };
    this.linkedinContacts.set(id, updatedContact);
    return updatedContact;
  }

  // Email template operations
  async getEmailTemplates(): Promise<EmailTemplate[]> {
    return Array.from(this.emailTemplates.values())
      .sort((a, b) => {
        if (!a.lastUsed && !b.lastUsed) return 0;
        if (!a.lastUsed) return 1;
        if (!b.lastUsed) return -1;
        return new Date(b.lastUsed).getTime() - new Date(a.lastUsed).getTime();
      });
  }

  async getEmailTemplate(id: number): Promise<EmailTemplate | undefined> {
    return this.emailTemplates.get(id);
  }

  async getEmailTemplateByName(name: string): Promise<EmailTemplate | undefined> {
    return Array.from(this.emailTemplates.values()).find(
      (template) => template.name.toLowerCase() === name.toLowerCase()
    );
  }

  async createEmailTemplate(template: InsertEmailTemplate): Promise<EmailTemplate> {
    const id = this.currentEmailTemplateId++;
    const now = new Date();
    const emailTemplate: EmailTemplate = { 
      ...template, 
      id, 
      createdAt: now,
      lastUsed: null
    };
    this.emailTemplates.set(id, emailTemplate);
    return emailTemplate;
  }

  async updateEmailTemplate(id: number, updates: Partial<InsertEmailTemplate>): Promise<EmailTemplate | undefined> {
    const template = await this.getEmailTemplate(id);
    if (!template) return undefined;
    
    const updatedTemplate: EmailTemplate = { ...template, ...updates };
    this.emailTemplates.set(id, updatedTemplate);
    return updatedTemplate;
  }

  async deleteEmailTemplate(id: number): Promise<boolean> {
    return this.emailTemplates.delete(id);
  }

  async updateLastUsed(id: number): Promise<EmailTemplate | undefined> {
    const template = await this.getEmailTemplate(id);
    if (!template) return undefined;
    
    const now = new Date();
    const updatedTemplate: EmailTemplate = { ...template, lastUsed: now };
    this.emailTemplates.set(id, updatedTemplate);
    return updatedTemplate;
  }
}

export const storage = new MemStorage();
