import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User types enum for distinguishing between clients and healers
export const UserType = {
  CLIENT: "client",
  HEALER: "healer",
} as const;

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  fullName: text("full_name").notNull(),
  type: text("type").notNull().default(UserType.CLIENT),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users)
  .omit({ id: true, createdAt: true });

export const healerProfiles = pgTable("healer_profiles", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  bio: text("bio"),
  specialties: text("specialties").array(),
  pricePerHour: integer("price_per_hour"),
  yearsExperience: integer("years_experience"),
  rating: integer("rating"),
  reviewCount: integer("review_count").default(0),
  imageUrl: text("image_url"),
});

export const insertHealerProfileSchema = createInsertSchema(healerProfiles)
  .omit({ id: true });

export const auraReadings = pgTable("aura_readings", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  imageUrl: text("image_url"),
  analysis: text("analysis"),
  colors: text("colors").array(),
  date: timestamp("date").defaultNow(),
  hasNumerology: boolean("has_numerology").default(false),
  numerologyData: jsonb("numerology_data"),
  positiveAspects: text("positive_aspects").array(),
  negativeAspects: text("negative_aspects").array(),
});

export const insertAuraReadingSchema = createInsertSchema(auraReadings)
  .omit({ id: true, date: true });

export const journalEntries = pgTable("journal_entries", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  title: text("title").notNull(),
  content: text("content").notNull(),
  date: timestamp("date").defaultNow(),
});

export const insertJournalEntrySchema = createInsertSchema(journalEntries)
  .omit({ id: true, date: true });

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertHealerProfile = z.infer<typeof insertHealerProfileSchema>;
export type HealerProfile = typeof healerProfiles.$inferSelect;

export type InsertAuraReading = z.infer<typeof insertAuraReadingSchema>;
export type AuraReading = typeof auraReadings.$inferSelect;

export type InsertJournalEntry = z.infer<typeof insertJournalEntrySchema>;
export type JournalEntry = typeof journalEntries.$inferSelect;

export const NumerologyData = z.object({
  fullName: z.string(),
  birthDate: z.string(),
  lifePathNumber: z.number(),
  expressionNumber: z.number(),
  soulUrgeNumber: z.number(),
  lifePathMeaning: z.string(),
  expressionMeaning: z.string(),
  soulUrgeMeaning: z.string(),
  analysis: z.string()
});

export type NumerologyData = z.infer<typeof NumerologyData>;

// LinkedIn contacts schema
export const linkedinContacts = pgTable("linkedin_contacts", {
  id: serial("id").primaryKey(),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  profileUrl: text("profile_url").notNull().unique(),
  title: text("title"), // Job title
  company: text("company"),
  companyDescription: text("company_description"),
  industry: text("industry"),
  email: text("email").unique(),
  location: text("location"),
  connectionDegree: text("connection_degree"),
  notes: text("notes"),
  lastUpdated: timestamp("last_updated").defaultNow(),
  emailSent: boolean("email_sent").default(false),
  emailSentDate: timestamp("email_sent_date"),
});

export const insertLinkedinContactSchema = createInsertSchema(linkedinContacts)
  .omit({ id: true, lastUpdated: true, emailSent: true, emailSentDate: true });

export type InsertLinkedinContact = z.infer<typeof insertLinkedinContactSchema>;
export type LinkedinContact = typeof linkedinContacts.$inferSelect;

// Email templates schema
export const emailTemplates = pgTable("email_templates", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  subject: text("subject").notNull(),
  bodyTemplate: text("body_template").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  lastUsed: timestamp("last_used"),
});

export const insertEmailTemplateSchema = createInsertSchema(emailTemplates)
  .omit({ id: true, createdAt: true, lastUsed: true });

export type InsertEmailTemplate = z.infer<typeof insertEmailTemplateSchema>;
export type EmailTemplate = typeof emailTemplates.$inferSelect;
