import creativeOrangePattern from '@assets/reference-auras/creative_orange_pattern.jpg';
import mysticIndigoPattern from '@assets/reference-auras/mystic_indigo_pattern.jpg';

export type AuraPattern = {
  id: string;
  name: string;
  description: string;
  image: string;
  colorConfiguration: {
    colors: string[];
    positions: string[];
  };
  meanings: {
    primary: string;
    secondary: string[];
  };
};

export const auraPatterns: AuraPattern[] = [
  {
    id: 'creative-orange',
    name: 'Creative Orange',
    description: 'A pattern showing strong creative energy, self-confidence, and spiritual/artistic inspiration.',
    image: creativeOrangePattern,
    colorConfiguration: {
      colors: ['orange/red', 'blue', 'green', 'purple'],
      positions: ['left side', 'top', 'right side', 'highlights'],
    },
    meanings: {
      primary: 'Creative expression and vitality',
      secondary: [
        'Personal power and confidence',
        'Artistic inspiration',
        'Emotional balance',
        'Spontaneity and joy'
      ]
    }
  },
  {
    id: 'mystic-indigo',
    name: 'Mystic Indigo',
    description: 'A pattern showing strong intuitive abilities, personal transformation, and growth.',
    image: mysticIndigoPattern,
    colorConfiguration: {
      colors: ['blue', 'grey/silver', 'green', 'purple'],
      positions: ['top', 'top right', 'left side', 'right side'],
    },
    meanings: {
      primary: 'Deep intuition and inner knowing',
      secondary: [
        'Personal transformation',
        'Growth and renewal',
        'Spiritual connection',
        'Heightened perception'
      ]
    }
  }
];

/**
 * Get an aura pattern by ID
 */
export function getAuraPatternById(id: string): AuraPattern | undefined {
  return auraPatterns.find(pattern => pattern.id === id);
}

/**
 * Returns the best matching aura pattern for a given set of colors and positions
 */
export function findMatchingAuraPattern(
  colors: Record<string, { position: string; intensity: number }>
): AuraPattern | undefined {
  // Check for Creative Orange pattern
  const hasOrangeLeft = Object.entries(colors).some(([color, data]) => 
    (color.includes('orange') || color.includes('red')) && data.position.includes('left'));
  const hasBlueTop = Object.entries(colors).some(([color, data]) => 
    color.includes('blue') && data.position.includes('top'));
  const hasGreenRight = Object.entries(colors).some(([color, data]) => 
    color.includes('green') && data.position.includes('right'));
  const hasPurple = Object.entries(colors).some(([color, data]) => 
    color.includes('purple') || color.includes('violet'));

  if (hasOrangeLeft && hasBlueTop && hasGreenRight && hasPurple) {
    return getAuraPatternById('creative-orange');
  }

  // Check for Mystic Indigo pattern
  const hasBlueTopCenter = Object.entries(colors).some(([color, data]) => 
    color.includes('blue') && data.position.includes('top'));
  const hasSilverTopRight = Object.entries(colors).some(([color, data]) => 
    (color.includes('silver') || color.includes('grey') || color.includes('gray')) && 
    data.position.includes('top') && data.position.includes('right'));
  const hasGreenLeft = Object.entries(colors).some(([color, data]) => 
    color.includes('green') && data.position.includes('left'));
  const hasPurpleRight = Object.entries(colors).some(([color, data]) => 
    (color.includes('purple') || color.includes('violet')) && data.position.includes('right'));

  if (hasBlueTopCenter && (hasSilverTopRight || hasGreenLeft) && hasPurpleRight) {
    return getAuraPatternById('mystic-indigo');
  }

  // No matching pattern found
  return undefined;
}