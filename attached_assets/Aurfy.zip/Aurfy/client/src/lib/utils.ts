import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Validate that an image contains a single person
export function validateImage(file: File): Promise<{ valid: boolean; message: string }> {
  return new Promise((resolve) => {
    // Check file type
    if (!file.type.startsWith("image/")) {
      resolve({ valid: false, message: "Please upload an image file (JPG, PNG, etc.)" });
      return;
    }

    // Check file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      resolve({ valid: false, message: "Image size should be less than 5MB" });
      return;
    }

    // Create image element to check dimensions
    const img = new Image();
    const objectUrl = URL.createObjectURL(file);

    img.onload = () => {
      URL.revokeObjectURL(objectUrl);

      // Check dimensions
      if (img.width < 200 || img.height < 200) {
        resolve({
          valid: false,
          message: "Image dimensions are too small. Please upload a larger image.",
        });
        return;
      }

      // For a real app, we would use ML to detect faces/persons
      // but for now we'll simulate validation
      // In a production app, this should be done on the server side

      resolve({
        valid: true,
        message: "Image is suitable for aura analysis.",
      });
    };

    img.onerror = () => {
      URL.revokeObjectURL(objectUrl);
      resolve({
        valid: false,
        message: "Failed to load image. Please try another file.",
      });
    };

    img.src = objectUrl;
  });
}

// Format date to human-readable string
export function formatDate(date: Date | string | null): string {
  if (!date) return "N/A";
  const d = new Date(date);
  return d.toLocaleDateString("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });
}

// Generate a random aura color for preview
export function getRandomAuraColors(): string[] {
  const colors = [
    "purple",
    "blue",
    "green",
    "orange",
    "red",
    "indigo",
    "pink",
    "teal",
  ];
  
  // Randomly select 2-3 colors
  const numColors = Math.floor(Math.random() * 2) + 2; // 2 or 3
  const selectedColors: string[] = [];
  
  while (selectedColors.length < numColors) {
    const color = colors[Math.floor(Math.random() * colors.length)];
    if (!selectedColors.includes(color)) {
      selectedColors.push(color);
    }
  }
  
  return selectedColors;
}

// Map color names to more vibrant and visually appealing Tailwind classes
export function colorToClass(color: string): { bg: string; text: string } {
  const lowerColor = color.toLowerCase();
  
  // Handle special compound colors and variants
  if (lowerColor.includes("yellow") || lowerColor.includes("gold") || lowerColor.includes("amber")) {
    return { bg: "bg-gradient-to-r from-amber-50 to-yellow-100", text: "text-amber-800" };
  }
  
  if (lowerColor.includes("violet")) {
    return { bg: "bg-gradient-to-r from-purple-100 to-violet-100", text: "text-violet-900" };
  }
  
  if (lowerColor.includes("indigo") || lowerColor.includes("deep blue")) {
    return { bg: "bg-gradient-to-r from-indigo-100 to-blue-100", text: "text-indigo-900" };
  }
  
  if (lowerColor.includes("turquoise") || lowerColor.includes("aqua")) {
    return { bg: "bg-gradient-to-r from-cyan-100 to-teal-100", text: "text-teal-900" };
  }
  
  if (lowerColor.includes("royal")) {
    return { bg: "bg-gradient-to-r from-blue-100 to-indigo-100", text: "text-blue-900" };
  }
  
  if (lowerColor.includes("emerald")) {
    return { bg: "bg-gradient-to-r from-green-100 to-emerald-100", text: "text-emerald-900" };
  }
  
  if (lowerColor.includes("rose") || lowerColor.includes("magenta")) {
    return { bg: "bg-gradient-to-r from-pink-100 to-rose-100", text: "text-rose-900" };
  }
  
  if (lowerColor.includes("coral") || lowerColor.includes("salmon")) {
    return { bg: "bg-gradient-to-r from-orange-100 to-red-100", text: "text-orange-900" };
  }
  
  if (lowerColor.includes("silver") || lowerColor.includes("platinum") || lowerColor.includes("grey") || lowerColor.includes("gray")) {
    return { bg: "bg-gradient-to-r from-slate-100 to-gray-100", text: "text-slate-800" };
  }
  
  // Enhanced base color mapping with gradients for visual depth
  const colorMap: Record<string, { bg: string; text: string }> = {
    purple: { bg: "bg-gradient-to-r from-purple-50 to-purple-100", text: "text-purple-900" },
    blue: { bg: "bg-gradient-to-r from-blue-50 to-blue-100", text: "text-blue-900" },
    green: { bg: "bg-gradient-to-r from-green-50 to-green-100", text: "text-green-900" },
    red: { bg: "bg-gradient-to-r from-red-50 to-red-100", text: "text-red-900" },
    orange: { bg: "bg-gradient-to-r from-orange-50 to-orange-100", text: "text-orange-900" },
    indigo: { bg: "bg-gradient-to-r from-indigo-50 to-indigo-100", text: "text-indigo-900" },
    pink: { bg: "bg-gradient-to-r from-pink-50 to-pink-100", text: "text-pink-900" },
    teal: { bg: "bg-gradient-to-r from-teal-50 to-teal-100", text: "text-teal-900" },
    cyan: { bg: "bg-gradient-to-r from-cyan-50 to-cyan-100", text: "text-cyan-900" },
    violet: { bg: "bg-gradient-to-r from-violet-50 to-violet-100", text: "text-violet-900" },
    amber: { bg: "bg-gradient-to-r from-amber-50 to-amber-100", text: "text-amber-900" },
    emerald: { bg: "bg-gradient-to-r from-emerald-50 to-emerald-100", text: "text-emerald-900" },
    sky: { bg: "bg-gradient-to-r from-sky-50 to-sky-100", text: "text-sky-900" },
    rose: { bg: "bg-gradient-to-r from-rose-50 to-rose-100", text: "text-rose-900" },
    lime: { bg: "bg-gradient-to-r from-lime-50 to-lime-100", text: "text-lime-900" },
    // Special aura names
    solar: { bg: "bg-gradient-to-r from-amber-50 to-yellow-100", text: "text-amber-800" },
    cosmic: { bg: "bg-gradient-to-r from-violet-50 to-indigo-100", text: "text-violet-900" },
    earth: { bg: "bg-gradient-to-r from-stone-50 to-amber-100", text: "text-stone-800" },
  };
  
  return colorMap[lowerColor] || { bg: "bg-gradient-to-r from-slate-50 to-slate-100", text: "text-slate-800" };
}

// Map color names to enhanced dot color classes for better visualization
export function colorToDotClass(color: string): string {
  const lowerColor = color.toLowerCase();
  
  // Handle special compound colors and variants
  if (lowerColor.includes("yellow") || lowerColor.includes("gold") || lowerColor.includes("amber")) {
    return "bg-gradient-to-r from-amber-400 to-yellow-400 shadow-md";
  }
  
  if (lowerColor.includes("violet")) {
    return "bg-gradient-to-r from-purple-400 to-violet-500 shadow-md";
  }
  
  if (lowerColor.includes("indigo") || lowerColor.includes("deep blue")) {
    return "bg-gradient-to-r from-indigo-500 to-blue-600 shadow-md";
  }
  
  if (lowerColor.includes("turquoise") || lowerColor.includes("aqua")) {
    return "bg-gradient-to-r from-cyan-400 to-teal-500 shadow-md";
  }
  
  if (lowerColor.includes("royal")) {
    return "bg-gradient-to-r from-blue-500 to-indigo-600 shadow-md";
  }
  
  if (lowerColor.includes("emerald")) {
    return "bg-gradient-to-r from-green-500 to-emerald-600 shadow-md";
  }
  
  if (lowerColor.includes("rose") || lowerColor.includes("magenta")) {
    return "bg-gradient-to-r from-pink-500 to-rose-600 shadow-md";
  }
  
  if (lowerColor.includes("coral") || lowerColor.includes("salmon")) {
    return "bg-gradient-to-r from-orange-400 to-red-500 shadow-md";
  }
  
  if (lowerColor.includes("silver") || lowerColor.includes("platinum") || lowerColor.includes("grey") || lowerColor.includes("gray")) {
    return "bg-gradient-to-r from-slate-300 to-gray-400 shadow-md";
  }
  
  // Enhanced base color mapping with vibrant colors
  const colorMap: Record<string, string> = {
    purple: "bg-purple-500 shadow-md",
    blue: "bg-blue-500 shadow-md",
    green: "bg-green-500 shadow-md",
    red: "bg-red-500 shadow-md",
    orange: "bg-orange-500 shadow-md",
    indigo: "bg-indigo-500 shadow-md",
    pink: "bg-pink-500 shadow-md",
    teal: "bg-teal-500 shadow-md",
    cyan: "bg-cyan-500 shadow-md",
    violet: "bg-violet-500 shadow-md",
    amber: "bg-amber-500 shadow-md",
    emerald: "bg-emerald-500 shadow-md",
    sky: "bg-sky-500 shadow-md",
    rose: "bg-rose-500 shadow-md",
    lime: "bg-lime-500 shadow-md",
    // Special aura names
    solar: "bg-gradient-to-r from-amber-400 to-yellow-500 shadow-md",
    cosmic: "bg-gradient-to-r from-violet-500 to-indigo-600 shadow-md",
    earth: "bg-gradient-to-r from-stone-400 to-amber-500 shadow-md",
  };
  
  return colorMap[lowerColor] || "bg-slate-400 shadow-md";
}
