# Reference Aura Patterns

This directory contains reference aura patterns for the system to learn from:

## Pattern 1: Creative Orange Signature
- Orange/red on the left side
- Blue on top
- Green on the right side
- Purple highlights
- Interpretation: Creative expression, personal power, and artistic inspiration

## Pattern 2: Mystic Indigo Signature
- Blue on top
- Grey/Silver on top right
- Green on left side
- Purple on right side
- Interpretation: Deep intuition, personal transformation, and growth

These reference patterns help the AI analyze new aura images more accurately by providing examples of known aura configurations.