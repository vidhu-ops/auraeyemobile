import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { User, HealerProfile } from "@shared/schema";
import { Star, StarHalf, User as UserIcon, Loader2 } from "lucide-react";
import { Link } from "wouter";

interface HealerCardProps {
  healer: (User & { profile: HealerProfile }) | null;
  featured?: boolean;
}

export function HealerCard({ healer, featured = false }: HealerCardProps) {
  // Loading state
  if (!healer) {
    return (
      <Card className="minrims-card h-full">
        <div className="w-full h-48 bg-gray-100 flex items-center justify-center animate-pulse">
          <Loader2 className="w-10 h-10 text-gray-300 animate-spin" />
        </div>
        <div className="p-5">
          <div className="h-6 bg-gray-100 rounded-lg w-3/4 mb-3 animate-pulse"></div>
          <div className="h-4 bg-gray-100 rounded-lg w-1/2 mb-3 animate-pulse"></div>
          <div className="flex gap-1 mb-4">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="w-4 h-4 bg-gray-100 rounded-full animate-pulse"></div>
            ))}
          </div>
          <div className="h-10 bg-gray-100 rounded-lg w-full animate-pulse"></div>
        </div>
      </Card>
    );
  }

  const { id, fullName, profile } = healer;
  const { specialties, rating, reviewCount, imageUrl } = profile;

  // Format price
  const formattedPrice = profile.pricePerHour ? `$${profile.pricePerHour}/hr` : "Price on request";

  // Fallback image URL
  const fallbackImageUrl = "https://images.unsplash.com/photo-1518577915332-c2a19f149a75?w=400&h=300&fit=crop";

  // Generate stars for rating
  const renderStars = () => {
    const stars = [];
    const ratingValue = rating || 0;
    const fullStars = Math.floor(ratingValue);
    const hasHalfStar = (ratingValue % 1) >= 0.5;
    
    for (let i = 0; i < fullStars; i++) {
      stars.push(<Star key={`full-${i}`} className="fill-blue-500 text-blue-500 w-4 h-4" />);
    }
    
    if (hasHalfStar) {
      stars.push(<StarHalf key="half" className="fill-blue-500 text-blue-500 w-4 h-4" />);
    }
    
    const emptyStars = 5 - stars.length;
    for (let i = 0; i < emptyStars; i++) {
      stars.push(<Star key={`empty-${i}`} className="text-gray-300 w-4 h-4" />);
    }
    
    return stars;
  };

  return (
    <Card className="minrims-card h-full overflow-hidden">
      <div className="relative">
        {imageUrl ? (
          <img 
            src={imageUrl} 
            alt={`Healer ${fullName}`} 
            className="w-full h-52 object-cover"
          />
        ) : (
          <div className="w-full h-52 bg-gray-100 flex items-center justify-center">
            <UserIcon className="w-12 h-12 text-gray-300" />
          </div>
        )}
        <div className="absolute top-3 right-3 bg-white/90 backdrop-blur-sm px-2 py-1 rounded-lg shadow-sm border border-gray-50 text-sm font-medium">
          {formattedPrice}
        </div>
      </div>
      <div className="p-5">
        <h3 className="font-heading font-bold text-lg text-gray-900 mb-1">{fullName}</h3>
        <p className="text-gray-500 text-sm mb-3">
          {specialties && specialties.length > 0 
            ? specialties.join(", ") 
            : "General Energy Healing"
          }
        </p>
        <div className="flex items-center mb-4">
          <div className="flex text-blue-500">
            {renderStars()}
          </div>
          <span className="text-xs text-gray-500 ml-1">
            ({reviewCount || 0} reviews)
          </span>
        </div>
        <Link href={`/healers/${id}`}>
          <button className="w-full minrims-btn py-2.5">
            View Profile
          </button>
        </Link>
      </div>
    </Card>
  );
}
