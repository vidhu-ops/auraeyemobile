import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { validateImage } from "@/lib/utils";
import { X, Upload, Check, ImagePlus, Loader2 } from "lucide-react";

interface ImageUploadProps {
  onImageSelected: (file: File, preview: string) => void;
  isAnalyzing?: boolean;
}

export function ImageUpload({ onImageSelected, isAnalyzing = false }: ImageUploadProps) {
  const [dragActive, setDragActive] = useState(false);
  const [validating, setValidating] = useState(false);
  const [validationResult, setValidationResult] = useState<{
    valid: boolean;
    message: string;
  } | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      await handleFile(e.dataTransfer.files[0]);
    }
  };

  const handleChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    
    if (e.target.files && e.target.files[0]) {
      await handleFile(e.target.files[0]);
    }
  };

  const handleFile = async (file: File) => {
    setValidating(true);
    setValidationResult(null);
    
    // Create preview
    const url = URL.createObjectURL(file);
    setPreviewUrl(url);
    
    // Validate image
    const result = await validateImage(file);
    setValidationResult(result);
    setValidating(false);
    
    if (result.valid) {
      setSelectedFile(file);
      onImageSelected(file, url);
    }
  };

  const handleBrowseClick = () => {
    fileInputRef.current?.click();
  };

  const resetUpload = () => {
    if (previewUrl) {
      URL.revokeObjectURL(previewUrl);
    }
    setPreviewUrl(null);
    setSelectedFile(null);
    setValidationResult(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  return (
    <div 
      className={`border-2 border-dashed rounded-xl p-8 transition-all ${
        dragActive 
          ? "border-primary bg-primary/10" 
          : validationResult?.valid 
            ? "border-green-400 bg-green-900/20" 
            : validationResult 
              ? "border-red-400 bg-red-900/20" 
              : "border-gray-600"
      }`}
      onDragEnter={handleDrag}
      onDragLeave={handleDrag}
      onDragOver={handleDrag}
      onDrop={handleDrop}
    >
      <input 
        ref={fileInputRef}
        type="file"
        className="hidden"
        accept="image/*"
        onChange={handleChange}
        disabled={isAnalyzing}
      />
      
      {!previewUrl ? (
        <div className="text-center">
          <Upload className="w-16 h-16 mx-auto text-primary-light mb-4" />
          <p className="mb-4 text-white">Drag and drop your image here, or click to browse</p>
          <Button 
            className="pink-purple-gradient"
            onClick={handleBrowseClick}
            disabled={isAnalyzing}
          >
            Browse Files
          </Button>
        </div>
      ) : (
        <div className="text-center">
          <div className="relative inline-block">
            <img 
              src={previewUrl} 
              alt="Preview" 
              className="max-h-64 rounded-lg mb-4 mx-auto"
            />
            {!isAnalyzing && (
              <button 
                onClick={resetUpload}
                className="absolute top-2 right-2 bg-[#8a2be2] rounded-full w-8 h-8 flex items-center justify-center shadow-md hover:bg-[#7a1bd2] transition-colors"
                aria-label="Remove image"
              >
                <X className="w-5 h-5 text-white" />
              </button>
            )}
          </div>
          
          {validating ? (
            <div className="text-sm mb-4 flex items-center justify-center text-white">
              <Loader2 className="animate-spin mr-2 h-4 w-4 text-primary" />
              Validating image...
            </div>
          ) : validationResult ? (
            <div className={`text-sm mb-4 flex items-center justify-center ${
              validationResult.valid ? "text-green-400" : "text-red-400"
            }`}>
              {validationResult.valid ? (
                <Check className="w-4 h-4 mr-1" />
              ) : (
                <X className="w-4 h-4 mr-1" />
              )}
              {validationResult.message}
            </div>
          ) : null}
          
          <div className="flex justify-center space-x-4">
            {!isAnalyzing && (
              <>
                <Button 
                  className="pink-purple-gradient"
                  onClick={resetUpload}
                >
                  Upload New
                </Button>
                {validationResult?.valid && (
                  <Button 
                    type="submit"
                    className="pink-purple-gradient"
                    disabled={isAnalyzing}
                  >
                    {isAnalyzing ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Analyzing...
                      </>
                    ) : (
                      "Start Analysis"
                    )}
                  </Button>
                )}
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
