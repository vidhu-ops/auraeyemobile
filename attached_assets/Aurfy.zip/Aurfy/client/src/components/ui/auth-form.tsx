import { useState } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { UserType } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";

import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2 } from "lucide-react";

const loginSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required"),
});

const registerSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  email: z.string().email("Please enter a valid email"),
  fullName: z.string().min(1, "Full name is required"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  confirmPassword: z.string(),
  userType: z.enum([UserType.CLIENT, UserType.HEALER]),
}).refine(data => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

type LoginFormValues = z.infer<typeof loginSchema>;
type RegisterFormValues = z.infer<typeof registerSchema>;

export function AuthForm() {
  const [activeTab, setActiveTab] = useState<string>("login");
  const [userType, setUserType] = useState<"client" | "healer">("client");
  const { loginMutation, registerMutation } = useAuth();

  const loginForm = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "",
      password: "",
    },
  });

  const registerForm = useForm<RegisterFormValues>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      username: "",
      email: "",
      fullName: "",
      password: "",
      confirmPassword: "",
      userType: UserType.CLIENT,
    },
  });

  const onLogin = (data: LoginFormValues) => {
    loginMutation.mutate(data);
  };

  const onRegister = (data: RegisterFormValues) => {
    registerMutation.mutate(data);
  };

  const toggleUserType = (type: "client" | "healer") => {
    setUserType(type);
    registerForm.setValue("userType", type === "client" ? UserType.CLIENT : UserType.HEALER);
  };

  return (
    <Card className="w-full max-w-md mx-auto bg-white-100 text-white border border-blue-300">
      <CardHeader className="bg-purple-700 text-white rounded-t-lg">
        <CardTitle className="text-2xl">Welcome to AuraInsight</CardTitle>
        <CardDescription className="text-white/90">
          {activeTab === "login" ? "Sign in to your account" : "Create a new account"}
        </CardDescription>
      </CardHeader>
      <Tabs defaultValue="login" value={activeTab} onValueChange={setActiveTab}>
        <div className="px-6 pt-2">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="login">Login</TabsTrigger>
            <TabsTrigger value="register">Register</TabsTrigger>
          </TabsList>
        </div>
        <CardContent className="pt-6">
          <TabsContent value="login">
            <div className="flex mb-6">
              <button
                className={`flex-1 py-2 border-b-2 text-sm font-medium transition-colors ${
                  userType === "client" 
                    ? "border-pink-400 text-pink-400" 
                    : "border-purple-600 text-purple-400"
                }`}
                onClick={() => toggleUserType("client")}
              >
                Client Login
              </button>
              <button
                className={`flex-1 py-2 border-b-2 text-sm font-medium transition-colors ${
                  userType === "healer" 
                    ? "border-pink-400 text-pink-400" 
                    : "border-purple-600 text-purple-400"
                }`}
                onClick={() => toggleUserType("healer")}
              >
                Healer Login
              </button>
            </div>

            <Form {...loginForm}>
              <form onSubmit={loginForm.handleSubmit(onLogin)} className="space-y-4">
                <FormField
                  control={loginForm.control}
                  name="username"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>User name</FormLabel>
                      <FormControl>
                        <Input placeholder="username" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={loginForm.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Password</FormLabel>
                      <FormControl>
                        <Input type="password" placeholder="••••••••" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <input type="checkbox" id="remember" className="h-4 w-4 text-purple-600 focus:ring-purple-600 border-purple-500 bg-purple-800 rounded" />
                    <label htmlFor="remember" className="text-sm text-purple-800">Remember me</label>
                  </div>
                  <a href="#" className="text-sm text-black hover:text-pink-300">Forgot password?</a>
                </div>
                <Button type="submit" className="w-full bg-[#8a2be2] text-white hover:bg-[#7a1bd2]" disabled={loginMutation.isPending}>
                  {loginMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Signing in...
                    </>
                  ) : (
                    "Sign In"
                  )}
                </Button>
              </form>
            </Form>
          </TabsContent>

          <TabsContent value="register">
            <div className="flex mb-6">
              <button
                className={`flex-1 py-2 border-b-2 text-sm font-medium transition-colors ${
                  userType === "client" 
                    ? "border-pink-400 text-pink-400" 
                    : "border-purple-600 text-purple-400"
                }`}
                onClick={() => toggleUserType("client")}
              >
                Register as Client
              </button>
              <button
                className={`flex-1 py-2 border-b-2 text-sm font-medium transition-colors ${
                  userType === "healer" 
                    ? "border-pink-400 text-pink-400" 
                    : "border-purple-600 text-purple-400"
                }`}
                onClick={() => toggleUserType("healer")}
              >
                Register as Healer
              </button>
            </div>

            <Form {...registerForm}>
              <form onSubmit={registerForm.handleSubmit(onRegister)} className="space-y-4">
                <FormField
                  control={registerForm.control}
                  name="fullName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Full Name</FormLabel>
                      <FormControl>
                        <Input placeholder="John Doe" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={registerForm.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email</FormLabel>
                      <FormControl>
                        <Input type="email" placeholder="john@example.com" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={registerForm.control}
                  name="username"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Username</FormLabel>
                      <FormControl>
                        <Input placeholder="johndoe" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={registerForm.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Password</FormLabel>
                      <FormControl>
                        <Input type="password" placeholder="••••••••" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={registerForm.control}
                  name="confirmPassword"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Confirm Password</FormLabel>
                      <FormControl>
                        <Input type="password" placeholder="••••••••" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <Button type="submit" className="w-full bg-[#8a2be2] text-white hover:bg-[#7a1bd2]" disabled={registerMutation.isPending}>
                  {registerMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Creating account...
                    </>
                  ) : (
                    "Create Account"
                  )}
                </Button>
              </form>
            </Form>
          </TabsContent>
        </CardContent>
      </Tabs>
      <CardFooter className="flex justify-center border-t border-purple-700 p-4">
        <p className="text-sm text-purple-200 text-center">
          {activeTab === "login"
            ? "Don't have an account? "
            : "Already have an account? "}
          <button
            className="text-pink-400 hover:text-pink-300 font-medium"
            onClick={() => setActiveTab(activeTab === "login" ? "register" : "login")}
          >
            {activeTab === "login" ? "Sign up" : "Sign in"}
          </button>
        </p>
      </CardFooter>
    </Card>
  );
}
