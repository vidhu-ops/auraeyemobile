import { useState } from "react";
import { Button } from "./button";
import { Input } from "./input";
import { Label } from "./label";
import { AlertCircle, FileSpreadsheet, Upload, Check } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "./alert";
import { Progress } from "./progress";
import * as XLSX from "xlsx";

interface ExcelImportProps {
  onImport: (data: any[]) => void;
  onError?: (error: string) => void;
  acceptedFormats?: string[];
  maxFileSize?: number; // in bytes
}

export function ExcelImport({
  onImport,
  onError,
  acceptedFormats = [".xlsx", ".xls", ".csv"],
  maxFileSize = 5 * 1024 * 1024, // 5MB default
}: ExcelImportProps) {
  const [file, setFile] = useState<File | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isSuccess, setIsSuccess] = useState(false);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    
    // Reset states
    setError(null);
    setIsSuccess(false);
    setUploadProgress(0);
    
    if (!selectedFile) {
      setFile(null);
      return;
    }

    // Check file extension
    const fileName = selectedFile.name;
    const fileExtension = "." + fileName.split(".").pop()?.toLowerCase();
    if (!acceptedFormats.includes(fileExtension)) {
      const errorMsg = `Invalid file format. Please use ${acceptedFormats.join(", ")}`;
      setError(errorMsg);
      onError?.(errorMsg);
      setFile(null);
      return;
    }

    // Check file size
    if (selectedFile.size > maxFileSize) {
      const maxSizeMB = maxFileSize / (1024 * 1024);
      const errorMsg = `File is too large. Maximum size is ${maxSizeMB}MB`;
      setError(errorMsg);
      onError?.(errorMsg);
      setFile(null);
      return;
    }

    setFile(selectedFile);
  };

  const handleImport = async () => {
    if (!file) return;

    setIsUploading(true);
    setUploadProgress(10);
    
    try {
      // Simulate progress
      const simulateProgress = () => {
        setUploadProgress((prev) => {
          const next = prev + Math.floor(Math.random() * 15);
          return next > 90 ? 90 : next;
        });
      };
      
      const progressInterval = setInterval(simulateProgress, 200);
      
      // Read the Excel file
      const reader = new FileReader();
      
      reader.onload = (e) => {
        try {
          clearInterval(progressInterval);
          setUploadProgress(95);
          
          const data = e.target?.result;
          const workbook = XLSX.read(data, { type: 'binary' });
          const sheetName = workbook.SheetNames[0];
          const worksheet = workbook.Sheets[sheetName];
          const jsonData = XLSX.utils.sheet_to_json(worksheet);
          
          // Validate the data structure
          if (!Array.isArray(jsonData) || jsonData.length === 0) {
            throw new Error("No data found in the Excel file or invalid format");
          }
          
          // Map Excel columns to our contact model
          const mappedData = jsonData.map((row: any) => {
            return {
              firstName: row['First Name'] || row['FirstName'] || row['firstName'] || '',
              lastName: row['Last Name'] || row['LastName'] || row['lastName'] || '',
              email: row['Email'] || row['email'] || row['Email Address'] || '',
              title: row['Title'] || row['title'] || row['Job Title'] || '',
              company: row['Company'] || row['company'] || row['Company Name'] || '',
              companyDescription: row['Company Description'] || row['companyDescription'] || '',
              industry: row['Industry'] || row['industry'] || '',
              location: row['Location'] || row['location'] || '',
              profileUrl: row['Profile URL'] || row['profileUrl'] || row['LinkedIn URL'] || '',
              connectionDegree: row['Connection'] || row['connectionDegree'] || '',
              notes: row['Notes'] || row['notes'] || ''
            };
          });
          
          setUploadProgress(100);
          setIsSuccess(true);
          onImport(mappedData);
          
          setTimeout(() => {
            setIsUploading(false);
            setFile(null);
            setUploadProgress(0);
          }, 1000);
          
        } catch (error) {
          clearInterval(progressInterval);
          const errorMsg = `Error processing file: ${(error as Error).message}`;
          setError(errorMsg);
          onError?.(errorMsg);
          setIsUploading(false);
        }
      };
      
      reader.onerror = () => {
        clearInterval(progressInterval);
        const errorMsg = "Error reading file";
        setError(errorMsg);
        onError?.(errorMsg);
        setIsUploading(false);
      };
      
      reader.readAsBinaryString(file);
      
    } catch (error) {
      const errorMsg = `Error importing file: ${(error as Error).message}`;
      setError(errorMsg);
      onError?.(errorMsg);
      setIsUploading(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="excel-file">Select Excel or CSV file</Label>
        <div className="flex gap-2">
          <Input
            id="excel-file"
            type="file"
            onChange={handleFileChange}
            accept={acceptedFormats.join(",")}
            disabled={isUploading}
            className="flex-1"
          />
          <Button
            onClick={handleImport}
            disabled={!file || isUploading}
            className="whitespace-nowrap"
          >
            {isUploading ? (
              "Importing..."
            ) : (
              <>
                <Upload className="h-4 w-4 mr-2" />
                Import
              </>
            )}
          </Button>
        </div>
        <p className="text-sm text-muted-foreground">
          Accepted formats: {acceptedFormats.join(", ")} (Max size: {maxFileSize / (1024 * 1024)}MB)
        </p>
      </div>

      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {isUploading && (
        <div className="space-y-2">
          <div className="flex justify-between text-sm text-muted-foreground">
            <span>Importing {file?.name}</span>
            <span>{uploadProgress}%</span>
          </div>
          <Progress value={uploadProgress} className="h-2" />
        </div>
      )}

      {isSuccess && !isUploading && (
        <Alert className="bg-green-50 border-green-200">
          <Check className="h-4 w-4 text-green-600" />
          <AlertTitle className="text-green-800">Success</AlertTitle>
          <AlertDescription className="text-green-700">
            File imported successfully
          </AlertDescription>
        </Alert>
      )}
    </div>
  );
}