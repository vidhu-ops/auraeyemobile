import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { UserType } from "@shared/schema";
import { Bath, Menu, LogOut, User, Linkedin, Mail } from "lucide-react";
import MobileMenu from "./mobile-menu";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { user, logoutMutation } = useAuth();
  const [location] = useLocation();

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map(part => part[0])
      .join("")
      .toUpperCase();
  };

  return (
    <header className="bg-blue-50 border-b border-indigo-100 sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4 flex justify-between items-center">
        <div className="flex items-center">
          <Link href="/">
            <div className="flex items-center cursor-pointer">
              <div className="w-12 h-12 rounded-xl bg-white border border-indigo-200 shadow-sm flex items-center justify-center mr-3">
                <Bath className="h-6 w-6 minrims-gradient-text" />
              </div>
              <h1 className="font-heading font-bold text-2xl">
                Aurfy<span className="minrims-gradient-text font-extrabold"></span>
              </h1>
            </div>
          </Link>
        </div>
        
        <nav className="hidden md:block">
          <ul className="flex items-center space-x-8">
            <li>
              <Link href="/">
                <div className={`${location === "/" ? "minrims-gradient-text font-medium" : "text-indigo-800"} hover:minrims-gradient-text transition-colors cursor-pointer text-sm uppercase tracking-wider font-medium`}>
                  Home
                </div>
              </Link>
            </li>
            <li>
              <Link href="/analysis">
                <div className={`${location === "/analysis" ? "minrims-gradient-text font-medium" : "text-indigo-800"} hover:minrims-gradient-text transition-colors cursor-pointer text-sm uppercase tracking-wider font-medium`}>
                  Analysis
                </div>
              </Link>
            </li>
            <li>
              <Link href="/healers">
                <div className={`${location === "/healers" ? "minrims-gradient-text font-medium" : "text-indigo-800"} hover:minrims-gradient-text transition-colors cursor-pointer text-sm uppercase tracking-wider font-medium`}>
                  Healers
                </div>
              </Link>
            </li>
            {user && (
              <>
                <li>
                  <Link href="/journal">
                    <div className={`${location === "/journal" ? "minrims-gradient-text font-medium" : "text-indigo-800"} hover:minrims-gradient-text transition-colors cursor-pointer text-sm uppercase tracking-wider font-medium`}>
                      Journal
                    </div>
                  </Link>
                </li>
              </>
            )}
          </ul>
        </nav>
        
        <div className="flex items-center space-x-4">
          {user ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="rounded-xl p-0 w-10 h-10 border border-gray-100 shadow-sm">
                  <Avatar>
                    <AvatarFallback className="minrims-gradient text-white">
                      {getInitials(user.fullName)}
                    </AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="rounded-xl shadow-lg border border-gray-100 p-1">
                <div className="p-3 text-sm font-medium border-b border-gray-100 mb-1">
                  <div className="text-gray-900">{user.fullName}</div>
                  <div className="text-xs text-gray-500 font-normal mt-1">
                    {user.type === UserType.HEALER ? "Healer" : "Client"}
                  </div>
                </div>
                <Link href="/profile">
                  <DropdownMenuItem className="rounded-lg cursor-pointer my-1 focus:bg-gray-50">
                    <User className="mr-2 h-4 w-4 text-gray-500" />
                    <span>Profile</span>
                  </DropdownMenuItem>
                </Link>
                <DropdownMenuSeparator className="my-1" />
                <DropdownMenuItem className="rounded-lg cursor-pointer my-1 focus:bg-gray-50" onSelect={handleLogout}>
                  <LogOut className="mr-2 h-4 w-4 text-gray-500" />
                  <span>Log out</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <>
              <Link href="/auth" className="hidden md:block">
                <button className="minrims-btn-outline">
                  Login
                </button>
              </Link>
              <Link href="/auth">
                <button className="minrims-btn">
                  Sign Up
                </button>
              </Link>
            </>
          )}
          
          <button
            className="md:hidden text-gray-800 rounded-full w-10 h-10 flex items-center justify-center border border-gray-100 shadow-sm focus:outline-none"
            onClick={() => setMobileMenuOpen(true)}
          >
            <Menu className="h-5 w-5" />
          </button>
        </div>
      </div>
      
      <MobileMenu
        isOpen={mobileMenuOpen}
        onClose={() => setMobileMenuOpen(false)}
        user={user}
        onLogout={handleLogout}
      />
    </header>
  );
}
