import { Link } from "wouter";
import { Linkedin, Mail, FileText, Users, FileSpreadsheet, Github } from "lucide-react";
import { Button } from "@/components/ui/button";

interface MarketingLayoutProps {
  children: React.ReactNode;
}

export default function MarketingLayout({ children }: MarketingLayoutProps) {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="border-b bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60">
        <div className="container flex h-16 items-center justify-between py-4">
          <div className="flex gap-6 md:gap-10">
            <Link href="/" className="flex items-center space-x-2">
              <Linkedin className="h-6 w-6 text-primary" />
              <span className="font-bold text-xl inline-block">LinkedIn Data Exporter</span>
            </Link>
            <nav className="hidden md:flex gap-6">
              <Link href="#features" className="text-sm font-medium text-muted-foreground transition-colors hover:text-primary">
                Features
              </Link>
              <Link href="#how-it-works" className="text-sm font-medium text-muted-foreground transition-colors hover:text-primary">
                How It Works
              </Link>
              <Link href="#demo" className="text-sm font-medium text-muted-foreground transition-colors hover:text-primary">
                Demo
              </Link>
            </nav>
          </div>
          <div className="flex items-center gap-2">
            <Link href="/auth">
              <Button variant="outline" size="sm" className="hidden md:flex">
                Sign In
              </Button>
            </Link>
            <Link href="/auth">
              <Button size="sm">Get Started</Button>
            </Link>
          </div>
        </div>
      </header>
      <main className="flex-1">
        {children}
      </main>
      <footer className="border-t py-8 md:py-12">
        <div className="container flex flex-col gap-4 md:flex-row md:gap-8">
          <div className="flex flex-col gap-4 md:gap-2 md:w-1/3">
            <Link href="/" className="flex items-center gap-2">
              <Linkedin className="h-5 w-5 text-primary" />
              <span className="font-semibold">LinkedIn Data Exporter</span>
            </Link>
            <p className="text-sm text-muted-foreground">
              A tool for extracting LinkedIn data, managing contacts, and sending personalized emails.
            </p>
          </div>
          <div className="grid flex-1 grid-cols-2 md:grid-cols-3 gap-8">
            <div className="space-y-3">
              <h4 className="text-sm font-medium">Features</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="/" className="text-muted-foreground hover:text-foreground transition-colors">
                    Data Extraction
                  </Link>
                </li>
                <li>
                  <Link href="/" className="text-muted-foreground hover:text-foreground transition-colors">
                    Excel Import/Export
                  </Link>
                </li>
                <li>
                  <Link href="/" className="text-muted-foreground hover:text-foreground transition-colors">
                    Email Templates
                  </Link>
                </li>
              </ul>
            </div>
            <div className="space-y-3">
              <h4 className="text-sm font-medium">Resources</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <Link href="/" className="text-muted-foreground hover:text-foreground transition-colors">
                    Documentation
                  </Link>
                </li>
                <li>
                  <Link href="/" className="text-muted-foreground hover:text-foreground transition-colors">
                    API Reference
                  </Link>
                </li>
                <li>
                  <Link href="/" className="text-muted-foreground hover:text-foreground transition-colors">
                    Tutorials
                  </Link>
                </li>
              </ul>
            </div>
            <div className="space-y-3">
              <h4 className="text-sm font-medium">Social</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <a href="https://github.com" target="_blank" rel="noreferrer" className="text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1">
                    <Github className="h-3.5 w-3.5" />
                    <span>GitHub</span>
                  </a>
                </li>
                <li>
                  <a href="https://linkedin.com" target="_blank" rel="noreferrer" className="text-muted-foreground hover:text-foreground transition-colors flex items-center gap-1">
                    <Linkedin className="h-3.5 w-3.5" />
                    <span>LinkedIn</span>
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div className="container mt-8 border-t pt-8 text-center text-sm text-muted-foreground">
          <p>© {new Date().getFullYear()} LinkedIn Data Exporter. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}