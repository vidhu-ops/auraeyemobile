import { Link } from "wouter";
import { X, Home, Image, Users, Book, User, LogOut, Linkedin, Mail } from "lucide-react";
import { User as UserType } from "@shared/schema";

interface MobileMenuProps {
  isOpen: boolean;
  onClose: () => void;
  user: UserType | null;
  onLogout: () => void;
}

export default function MobileMenu({ isOpen, onClose, user, onLogout }: MobileMenuProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 md:hidden">
      <div className="bg-white h-full w-4/5 max-w-xs py-4 overflow-y-auto shadow-lg animate-in slide-in-from-left">
        <div className="flex justify-between items-center px-4 pb-4 border-b border-purple-100">
          <h2 className="font-heading font-bold text-xl pink-purple-gradient-text">Menu</h2>
          <button onClick={onClose} className="p-2 rounded-full bg-[#8a2be2] hover:bg-[#7a1bd2]">
            <X className="h-5 w-5 text-white" />
          </button>
        </div>
        
        <nav className="px-4 py-2">
          <ul className="space-y-2">
            <li className="py-2">
              <Link href="/" onClick={onClose}>
                <div className="flex items-center text-purple-800 hover:text-purple-500 transition-colors cursor-pointer">
                  <Home className="h-5 w-5 mr-3" />
                  Home
                </div>
              </Link>
            </li>
            <li className="py-2">
              <Link href="/analysis" onClick={onClose}>
                <div className="flex items-center text-purple-800 hover:text-purple-500 transition-colors cursor-pointer">
                  <Image className="h-5 w-5 mr-3" />
                  Analysis
                </div>
              </Link>
            </li>
            <li className="py-2">
              <Link href="/healers" onClick={onClose}>
                <div className="flex items-center text-purple-800 hover:text-purple-500 transition-colors cursor-pointer">
                  <Users className="h-5 w-5 mr-3" />
                  Healers
                </div>
              </Link>
            </li>
            {user && (
              <>
                <li className="py-2">
                  <Link href="/journal" onClick={onClose}>
                    <div className="flex items-center text-purple-800 hover:text-purple-500 transition-colors cursor-pointer">
                      <Book className="h-5 w-5 mr-3" />
                      Journal
                    </div>
                  </Link>
                </li>
              </>
            )}
          </ul>
        </nav>
        
        {user ? (
          <div className="px-4 py-4 mt-4 border-t border-purple-100">
            <div className="mb-4">
              <div className="font-medium text-purple-900">{user.fullName}</div>
              <div className="text-sm text-purple-500">{user.email}</div>
            </div>
            <ul className="space-y-2">
              <li className="py-2">
                <Link href="/profile" onClick={onClose}>
                  <div className="flex items-center text-purple-800 hover:text-purple-500 transition-colors cursor-pointer">
                    <User className="h-5 w-5 mr-3" />
                    Profile
                  </div>
                </Link>
              </li>
              <li className="py-2">
                <button 
                  onClick={() => {
                    onLogout();
                    onClose();
                  }}
                  className="flex items-center justify-center w-full py-2 pink-purple-gradient text-white rounded-lg"
                >
                  <LogOut className="h-5 w-5 mr-3" />
                  Log out
                </button>
              </li>
            </ul>
          </div>
        ) : (
          <div className="px-4 py-4 mt-4 border-t border-purple-100">
            <Link href="/auth" onClick={onClose}>
              <div className="block w-full py-2 pink-purple-gradient text-white rounded-lg text-center mb-3 cursor-pointer">
                Sign Up
              </div>
            </Link>
            <Link href="/auth" onClick={onClose}>
              <div className="block w-full py-2 pink-purple-gradient text-white rounded-lg text-center cursor-pointer">
                Login
              </div>
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}
