import { Link } from "wouter";
import { Bath, Mail, Phone, MapPin, Facebook, Instagram, Twitter, Youtube } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-gray-50 border-t border-gray-100">
      <div className="container mx-auto px-4 pt-16 pb-8">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 mb-16">
          <div className="md:col-span-4">
            <Link href="/">
              <div className="flex items-center mb-6 cursor-pointer">
                <div className="w-12 h-12 rounded-xl bg-white border border-gray-100 shadow-sm flex items-center justify-center mr-3">
                  <Bath className="h-6 w-6 minrims-gradient-text" />
                </div>
                <h2 className="font-heading font-bold text-2xl">
                  Aura<span className="minrims-gradient-text font-extrabold">Insight</span>
                </h2>
              </div>
            </Link>
            <p className="text-gray-500 mb-6 pr-4 text-sm leading-relaxed">
              Our AI-powered platform reveals your energetic signature through aura analysis, 
              connecting you with healers aligned to your unique spiritual profile.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="w-10 h-10 rounded-full bg-white border border-gray-100 shadow-sm flex items-center justify-center text-gray-400 hover:text-blue-500 transition-colors">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-white border border-gray-100 shadow-sm flex items-center justify-center text-gray-400 hover:text-pink-500 transition-colors">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-white border border-gray-100 shadow-sm flex items-center justify-center text-gray-400 hover:text-blue-400 transition-colors">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-white border border-gray-100 shadow-sm flex items-center justify-center text-gray-400 hover:text-red-500 transition-colors">
                <Youtube className="h-5 w-5" />
              </a>
            </div>
          </div>
          
          <div className="md:col-span-2">
            <h3 className="font-heading font-bold text-lg mb-5 text-gray-900">Quick Links</h3>
            <ul className="space-y-3">
              <li>
                <Link href="/">
                  <div className="text-gray-500 hover:text-blue-500 transition-colors cursor-pointer text-sm">Home</div>
                </Link>
              </li>
              <li>
                <Link href="/analysis">
                  <div className="text-gray-500 hover:text-blue-500 transition-colors cursor-pointer text-sm">Aura Analysis</div>
                </Link>
              </li>
              <li>
                <Link href="/healers">
                  <div className="text-gray-500 hover:text-blue-500 transition-colors cursor-pointer text-sm">Browse Healers</div>
                </Link>
              </li>
              <li>
                <a href="#" className="text-gray-500 hover:text-blue-500 transition-colors text-sm">About Us</a>
              </li>
              <li>
                <a href="#" className="text-gray-500 hover:text-blue-500 transition-colors text-sm">Blog</a>
              </li>
            </ul>
          </div>
          
          <div className="md:col-span-2">
            <h3 className="font-heading font-bold text-lg mb-5 text-gray-900">For Healers</h3>
            <ul className="space-y-3">
              <li>
                <Link href="/auth">
                  <div className="text-gray-500 hover:text-blue-500 transition-colors cursor-pointer text-sm">Join as a Healer</div>
                </Link>
              </li>
              <li>
                <a href="#" className="text-gray-500 hover:text-blue-500 transition-colors text-sm">Healer Resources</a>
              </li>
              <li>
                <a href="#" className="text-gray-500 hover:text-blue-500 transition-colors text-sm">Success Stories</a>
              </li>
              <li>
                <a href="#" className="text-gray-500 hover:text-blue-500 transition-colors text-sm">Pricing</a>
              </li>
            </ul>
          </div>
          
          <div className="md:col-span-4">
            <h3 className="font-heading font-bold text-lg mb-5 text-gray-900">Contact Us</h3>
            <ul className="space-y-3">
              <li className="flex items-start">
                <div className="w-8 h-8 rounded-lg bg-blue-50 flex items-center justify-center mr-3 flex-shrink-0">
                  <Mail className="text-blue-500 h-4 w-4" />
                </div>
                <div>
                  <span className="text-gray-900 font-medium text-sm">Email Us</span>
                  <p className="text-gray-500 text-sm">support@aurainsight.com</p>
                </div>
              </li>
              <li className="flex items-start">
                <div className="w-8 h-8 rounded-lg bg-purple-50 flex items-center justify-center mr-3 flex-shrink-0">
                  <Phone className="text-purple-500 h-4 w-4" />
                </div>
                <div>
                  <span className="text-gray-900 font-medium text-sm">Call Us</span>
                  <p className="text-gray-500 text-sm">+1 (555) 123-4567</p>
                </div>
              </li>
              <li className="flex items-start">
                <div className="w-8 h-8 rounded-lg bg-indigo-50 flex items-center justify-center mr-3 flex-shrink-0">
                  <MapPin className="text-indigo-500 h-4 w-4" />
                </div>
                <div>
                  <span className="text-gray-900 font-medium text-sm">Visit Us</span>
                  <p className="text-gray-500 text-sm">123 Healing Way, Serenity Valley, CA 90210</p>
                </div>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-200 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-500 text-sm mb-4 md:mb-0">© {new Date().getFullYear()} AuraInsight. All rights reserved.</p>
          <div className="flex space-x-6">
            <a href="#" className="text-gray-500 hover:text-blue-500 transition-colors text-sm">Privacy Policy</a>
            <a href="#" className="text-gray-500 hover:text-blue-500 transition-colors text-sm">Terms of Service</a>
            <a href="#" className="text-gray-500 hover:text-blue-500 transition-colors text-sm">Cookie Policy</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
