import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { Link } from "wouter";

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ExcelImport } from "@/components/ui/excel-import";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { 
  UserPlus, Download, Search, Filter, User, Trash2, Mail, 
  FileSpreadsheet, Upload, Database, RefreshCw 
} from "lucide-react";

// Form schema for adding a contact manually
const contactSchema = z.object({
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  email: z.string().email().optional().nullable(),
  title: z.string().optional().nullable(),
  company: z.string().optional().nullable(),
  companyDescription: z.string().optional().nullable(),
  industry: z.string().optional().nullable(),
  location: z.string().optional().nullable(),
  profileUrl: z.string().url("Must be a valid URL").optional().nullable(),
  connectionDegree: z.string().optional().nullable(),
  notes: z.string().optional().nullable(),
});

type ContactFormValues = z.infer<typeof contactSchema>;

export default function LinkedInContactsPage() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [openAddDialog, setOpenAddDialog] = useState(false);
  const [openImportDialog, setOpenImportDialog] = useState(false);
  const [selectedContacts, setSelectedContacts] = useState<number[]>([]);
  const [isSelectMode, setIsSelectMode] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  // Query to fetch LinkedIn contacts
  const { data: contacts, isLoading, refetch } = useQuery({
    queryKey: ["/api/linkedin/contacts"],
    queryFn: () => apiRequest<any[]>("/api/linkedin/contacts"),
    enabled: !!user,
  });

  // Form for adding a new contact
  const form = useForm<ContactFormValues>({
    resolver: zodResolver(contactSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      email: "",
      title: "",
      company: "",
      companyDescription: "",
      industry: "",
      location: "",
      profileUrl: "",
      connectionDegree: "",
      notes: "",
    },
  });

  // Mutation to add a new contact
  const addContactMutation = useMutation({
    mutationFn: async (data: ContactFormValues) => {
      return apiRequest("/api/linkedin/contacts", {
        method: "POST",
        body: JSON.stringify(data),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/linkedin/contacts"] });
      toast({
        title: "Contact Added",
        description: "LinkedIn contact has been added successfully",
      });
      setOpenAddDialog(false);
      form.reset();
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to add contact: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Mutation to import contacts from Excel
  const importContactsMutation = useMutation({
    mutationFn: async (contacts: any[]) => {
      const validContacts = contacts.filter(
        contact => contact.firstName && contact.lastName
      );
      
      if (validContacts.length === 0) {
        throw new Error("No valid contacts found in the import data");
      }
      
      // Create multiple contacts in sequence
      const response = await apiRequest("/api/linkedin/contacts/bulk-import", {
        method: "POST",
        body: JSON.stringify({ contacts: validContacts }),
      });
      
      return response;
    },
    onSuccess: (data: any) => {
      queryClient.invalidateQueries({ queryKey: ["/api/linkedin/contacts"] });
      toast({
        title: "Contacts Imported",
        description: `Successfully imported ${data.newContactsAdded} contacts`,
        variant: "success",
      });
      setOpenImportDialog(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Import Error",
        description: `Failed to import contacts: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Mutation to delete selected contacts
  const deleteContactsMutation = useMutation({
    mutationFn: async (contactIds: number[]) => {
      // Delete contacts one by one
      const promises = contactIds.map(id => 
        apiRequest(`/api/linkedin/contacts/${id}`, {
          method: "DELETE",
        })
      );
      
      return Promise.all(promises);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/linkedin/contacts"] });
      toast({
        title: "Contacts Deleted",
        description: `Successfully deleted ${selectedContacts.length} contacts`,
        variant: "success",
      });
      setSelectedContacts([]);
      setIsSelectMode(false);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to delete contacts: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Handle form submission for adding a contact
  const onSubmit = (data: ContactFormValues) => {
    addContactMutation.mutate(data);
  };

  // Handle importing contacts from Excel
  const handleImportContacts = (data: any[]) => {
    if (data.length === 0) {
      toast({
        title: "Import Error",
        description: "No data found in the import file",
        variant: "destructive",
      });
      return;
    }
    
    importContactsMutation.mutate(data);
  };

  // Handle import error
  const handleImportError = (error: string) => {
    toast({
      title: "Import Error",
      description: error,
      variant: "destructive",
    });
  };

  // Toggle contact selection
  const toggleSelectContact = (contactId: number) => {
    if (selectedContacts.includes(contactId)) {
      setSelectedContacts(selectedContacts.filter(id => id !== contactId));
    } else {
      setSelectedContacts([...selectedContacts, contactId]);
    }
  };

  // Toggle select all contacts
  const toggleSelectAll = () => {
    if (selectedContacts.length === (contacts?.length || 0)) {
      setSelectedContacts([]);
    } else {
      setSelectedContacts(contacts?.map(contact => contact.id) || []);
    }
  };

  // Delete selected contacts
  const deleteSelectedContacts = () => {
    if (selectedContacts.length === 0) return;
    
    deleteContactsMutation.mutate(selectedContacts);
  };

  // Filter contacts based on search query
  const filteredContacts = contacts?.filter(contact => {
    const searchString = searchQuery.toLowerCase();
    return (
      contact.firstName.toLowerCase().includes(searchString) ||
      contact.lastName.toLowerCase().includes(searchString) ||
      (contact.company && contact.company.toLowerCase().includes(searchString)) ||
      (contact.title && contact.title.toLowerCase().includes(searchString)) ||
      (contact.email && contact.email.toLowerCase().includes(searchString))
    );
  });

  return (
    <div className="container py-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">LinkedIn Contacts</h1>
          <p className="text-muted-foreground">
            Manage your LinkedIn contacts and export data
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setOpenImportDialog(true)}>
            <Upload className="mr-2 h-4 w-4" />
            Import
          </Button>
          <Button onClick={() => setOpenAddDialog(true)}>
            <UserPlus className="mr-2 h-4 w-4" />
            Add Contact
          </Button>
          <Link href="/api/linkedin/export-excel">
            <Button variant="outline">
              <Download className="mr-2 h-4 w-4" />
              Export Excel
            </Button>
          </Link>
        </div>
      </div>

      <div className="flex items-center justify-between mb-4">
        <div className="relative w-full md:w-80">
          <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search contacts..."
            className="pl-8"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setIsSelectMode(!isSelectMode)}
          >
            {isSelectMode ? "Cancel" : "Select"}
          </Button>
          {isSelectMode && (
            <>
              <Button
                variant="outline"
                size="sm"
                onClick={toggleSelectAll}
              >
                {selectedContacts.length === (contacts?.length || 0) 
                  ? "Deselect All" 
                  : "Select All"}
              </Button>
              <Button
                variant="destructive"
                size="sm"
                onClick={deleteSelectedContacts}
                disabled={selectedContacts.length === 0}
              >
                <Trash2 className="mr-2 h-4 w-4" />
                Delete ({selectedContacts.length})
              </Button>
            </>
          )}
        </div>
      </div>

      {isLoading ? (
        <div className="py-8 text-center">
          <p className="text-muted-foreground">Loading contacts...</p>
        </div>
      ) : filteredContacts?.length === 0 ? (
        <Card className="bg-muted/50">
          <CardContent className="py-10 flex flex-col items-center justify-center">
            <User className="h-12 w-12 text-muted-foreground mb-4" />
            <h3 className="text-xl font-medium mb-2">No contacts found</h3>
            <p className="text-muted-foreground text-center max-w-md mb-6">
              {searchQuery 
                ? "No contacts match your search query. Try a different search term." 
                : "Start by adding LinkedIn contacts manually or importing from an Excel file."}
            </p>
            <div className="flex gap-4">
              <Button onClick={() => setOpenAddDialog(true)}>
                <UserPlus className="mr-2 h-4 w-4" />
                Add Contact
              </Button>
              <Button variant="outline" onClick={() => setOpenImportDialog(true)}>
                <Upload className="mr-2 h-4 w-4" />
                Import Contacts
              </Button>
            </div>
          </CardContent>
        </Card>
      ) : (
        <div className="border rounded-md">
          <Table>
            <TableHeader>
              <TableRow>
                {isSelectMode && (
                  <TableHead className="w-12">
                    <input
                      type="checkbox"
                      checked={selectedContacts.length === filteredContacts?.length}
                      onChange={toggleSelectAll}
                      className="h-4 w-4"
                    />
                  </TableHead>
                )}
                <TableHead>Name</TableHead>
                <TableHead>Company</TableHead>
                <TableHead>Title</TableHead>
                <TableHead>Email</TableHead>
                <TableHead className="text-center">Emailed</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredContacts?.map((contact) => (
                <TableRow key={contact.id}>
                  {isSelectMode && (
                    <TableCell>
                      <input
                        type="checkbox"
                        checked={selectedContacts.includes(contact.id)}
                        onChange={() => toggleSelectContact(contact.id)}
                        className="h-4 w-4"
                      />
                    </TableCell>
                  )}
                  <TableCell className="font-medium">
                    {contact.firstName} {contact.lastName}
                  </TableCell>
                  <TableCell>{contact.company || "-"}</TableCell>
                  <TableCell>{contact.title || "-"}</TableCell>
                  <TableCell>{contact.email || "-"}</TableCell>
                  <TableCell className="text-center">
                    {contact.emailSent ? (
                      <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-green-100 text-green-800">
                        Yes
                      </span>
                    ) : (
                      <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-gray-100 text-gray-800">
                        No
                      </span>
                    )}
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      <Link href={`/linkedin/contacts/${contact.id}`}>
                        <Button variant="ghost" size="sm">
                          View
                        </Button>
                      </Link>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}

      {/* Add Contact Dialog */}
      <Dialog open={openAddDialog} onOpenChange={setOpenAddDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Add LinkedIn Contact</DialogTitle>
            <DialogDescription>
              Add a new LinkedIn contact to your database
            </DialogDescription>
          </DialogHeader>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="firstName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>First Name *</FormLabel>
                      <FormControl>
                        <Input placeholder="John" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="lastName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Last Name *</FormLabel>
                      <FormControl>
                        <Input placeholder="Doe" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email</FormLabel>
                    <FormControl>
                      <Input placeholder="john.doe@example.com" {...field} value={field.value || ""} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Job Title</FormLabel>
                      <FormControl>
                        <Input placeholder="Marketing Manager" {...field} value={field.value || ""} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="company"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Company</FormLabel>
                      <FormControl>
                        <Input placeholder="Acme Inc." {...field} value={field.value || ""} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="companyDescription"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Company Description</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Brief description of the company"
                        className="min-h-20"
                        {...field}
                        value={field.value || ""}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="industry"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Industry</FormLabel>
                      <FormControl>
                        <Input placeholder="Technology" {...field} value={field.value || ""} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="location"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Location</FormLabel>
                      <FormControl>
                        <Input placeholder="San Francisco, CA" {...field} value={field.value || ""} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="profileUrl"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>LinkedIn Profile URL</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="https://www.linkedin.com/in/johndoe/"
                        {...field}
                        value={field.value || ""}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="connectionDegree"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Connection Degree</FormLabel>
                    <FormControl>
                      <Input placeholder="1st" {...field} value={field.value || ""} />
                    </FormControl>
                    <FormDescription>
                      Your relationship with this contact (1st, 2nd, 3rd, etc.)
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Notes</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Additional notes about this contact"
                        className="min-h-20"
                        {...field}
                        value={field.value || ""}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setOpenAddDialog(false)}
                >
                  Cancel
                </Button>
                <Button type="submit" disabled={addContactMutation.isPending}>
                  {addContactMutation.isPending ? "Adding..." : "Add Contact"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Import Contacts Dialog */}
      <Dialog open={openImportDialog} onOpenChange={setOpenImportDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Import LinkedIn Contacts</DialogTitle>
            <DialogDescription>
              Import your LinkedIn contacts from an Excel or CSV file.
            </DialogDescription>
          </DialogHeader>

          <Tabs defaultValue="upload" className="mt-4">
            <TabsList className="grid grid-cols-2 mb-4">
              <TabsTrigger value="upload">
                <Upload className="h-4 w-4 mr-2" />
                Upload File
              </TabsTrigger>
              <TabsTrigger value="template">
                <FileSpreadsheet className="h-4 w-4 mr-2" />
                Download Template
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="upload">
              <div className="space-y-4">
                <p className="text-sm text-muted-foreground">
                  Upload an Excel or CSV file with contact information. The file should
                  include columns for first name, last name, email, company, title, etc.
                </p>
                
                <ExcelImport 
                  onImport={handleImportContacts}
                  onError={handleImportError}
                />
                
                <div className="p-4 bg-muted rounded-md">
                  <h4 className="font-medium mb-2">Required Columns:</h4>
                  <ul className="list-disc pl-5 space-y-1 text-sm">
                    <li>First Name</li>
                    <li>Last Name</li>
                  </ul>
                  <h4 className="font-medium mt-4 mb-2">Optional Columns:</h4>
                  <ul className="list-disc pl-5 space-y-1 text-sm">
                    <li>Email</li>
                    <li>Title (job title)</li>
                    <li>Company</li>
                    <li>Company Description</li>
                    <li>Industry</li>
                    <li>Location</li>
                    <li>Profile URL (LinkedIn profile URL)</li>
                    <li>Connection Degree</li>
                    <li>Notes</li>
                  </ul>
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="template">
              <div className="space-y-4">
                <p className="text-sm text-muted-foreground">
                  Download a template Excel file that you can fill with your contact data.
                  Once filled, you can import it using the Upload File tab.
                </p>
                
                <div className="rounded-md border p-6 flex flex-col items-center justify-center">
                  <FileSpreadsheet className="h-12 w-12 text-primary/80 mb-4" />
                  <h3 className="text-lg font-medium mb-2">LinkedIn Contacts Template</h3>
                  <p className="text-sm text-muted-foreground text-center mb-6">
                    This template contains all the necessary columns for importing your LinkedIn contacts.
                  </p>
                  <Button>
                    <Download className="mr-2 h-4 w-4" />
                    Download Template
                  </Button>
                </div>
              </div>
            </TabsContent>
          </Tabs>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setOpenImportDialog(false)}
            >
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}