import { useState, useRef, FormEvent } from "react";
import { useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest } from "@/lib/queryClient";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import { ImageUpload } from "@/components/ui/image-upload";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { formatDate, colorToClass, colorToDotClass } from "@/lib/utils";
import { Loader2, Clock } from "lucide-react";

interface AuraAnalysisResult {
  id: number;
  auraAnalysis: {
    colors: string[];
    meanings: Record<string, string>;
    analysis: string;
    positiveAspects: string[];
    negativeAspects: string[];

    personalInsights: {
      strengths: string[];
      challenges: string[];
      lifeTheme: string;
      energyForecast: string;
    };
    intensity?: number; // Overall aura intensity from 1-10
    colorIntensities?: Record<string, number>; // Intensity of each color from 1-10
  };
  numerologyData?: {
    fullName: string;
    birthDate: string;
    lifePathNumber: number;
    expressionNumber: number;
    soulUrgeNumber: number;
    lifePathMeaning: string;
    expressionMeaning: string;
    soulUrgeMeaning: string;
    analysis: string;
  };
}

export default function AnalysisPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [includeNumerology, setIncludeNumerology] = useState(false);
  const [fullName, setFullName] = useState("");
  const [birthDate, setBirthDate] = useState("");
  const [analysisResult, setAnalysisResult] = useState<AuraAnalysisResult | null>(null);
  const [showNumerology, setShowNumerology] = useState(true);
  const [activeTab, setActiveTab] = useState<'overview' | 'insights' | 'forecast'>('overview');
  const formRef = useRef<HTMLFormElement>(null);

  const analysisMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      const res = await apiRequest("POST", "/api/analyze-aura", formData, true);
      return await res.json();
    },
    onSuccess: (data: AuraAnalysisResult) => {
      setAnalysisResult(data);
      toast({
        title: "Analysis complete",
        description: "Your aura analysis is ready to view!",
      });
      
      // Scroll to results
      setTimeout(() => {
        document.getElementById("analysisResults")?.scrollIntoView({
          behavior: "smooth",
        });
      }, 100);
    },
    onError: (error: Error) => {
      toast({
        title: "Analysis failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleImageSelected = (file: File, preview: string) => {
    setSelectedImage(file);
    setPreviewUrl(preview);
  };

  const handleSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    
    if (!selectedImage) {
      toast({
        title: "No image selected",
        description: "Please upload an image to analyze",
        variant: "destructive",
      });
      return;
    }

    const formData = new FormData();
    formData.append("image", selectedImage);
    formData.append("includeNumerology", includeNumerology.toString());
    
    if (includeNumerology) {
      if (!fullName || !birthDate) {
        toast({
          title: "Missing information",
          description: "Please provide both your full birth name and birth date for numerology reading",
          variant: "destructive",
        });
        return;
      }
      
      formData.append("fullName", fullName);
      formData.append("birthDate", birthDate);
    }

    analysisMutation.mutate(formData);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow bg-white">
        <div className="container mx-auto px-4 py-8">
          {/* Upload Form */}
          <div className="max-w-3xl mx-auto">
            <h2 className="font-heading text-3xl font-bold text-center mb-8">
              <span className="minrims-gradient-text">Aura Analysis</span>
            </h2>
            
            <div className="minrims-card p-6 mb-8">
              <div className="text-center mb-6">
                <h3 className="font-heading text-xl mb-4 minrims-gradient-text font-bold">Aura Analysis Upload</h3>
                <p className="text-gray-700 mb-6">
                  Upload a well-lit photo of yourself with space around your head for the most accurate aura reading.
                </p>
                
                <form ref={formRef} onSubmit={handleSubmit}>
                  <ImageUpload 
                    onImageSelected={handleImageSelected}
                    isAnalyzing={analysisMutation.isPending}
                  />
                  
                  {/* Optional Numerology Section */}
                  <div className="border-t border-gray-100 pt-6 mt-6">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="font-heading text-xl text-gray-900 font-medium">Optional Numerology Reading</h3>
                      <div className="flex items-center space-x-2">
                        <Switch 
                          id="includeNumerology" 
                          checked={includeNumerology}
                          onCheckedChange={setIncludeNumerology}
                          disabled={analysisMutation.isPending}
                          className="data-[state=checked]:bg-blue-500"
                        />
                        <Label htmlFor="includeNumerology" className="text-gray-700">Include</Label>
                      </div>
                    </div>
                    
                    {includeNumerology && (
                      <div className="space-y-4 mt-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="fullName" className="text-gray-700 font-medium">Full Birth Name</Label>
                            <Input 
                              id="fullName" 
                              value={fullName}
                              onChange={(e) => setFullName(e.target.value)}
                              disabled={analysisMutation.isPending}
                              className="bg-white text-gray-900 border-gray-200 focus:border-blue-500 focus:ring-blue-500"
                            />
                          </div>
                          <div>
                            <Label htmlFor="birthDate" className="text-gray-700 font-medium">Birth Date</Label>
                            <Input 
                              id="birthDate" 
                              type="date" 
                              value={birthDate}
                              onChange={(e) => setBirthDate(e.target.value)}
                              disabled={analysisMutation.isPending}
                              className="bg-white text-gray-900 border-gray-200 focus:border-blue-500 focus:ring-blue-500"
                            />
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                  
                  {selectedImage && !analysisMutation.isPending && !analysisResult && (
                    <div className="mt-6">
                      <button 
                        type="submit" 
                        className="w-full minrims-btn py-3"
                        disabled={analysisMutation.isPending}
                      >
                        {analysisMutation.isPending ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            Analyzing...
                          </>
                        ) : (
                          "Start Analysis"
                        )}
                      </button>
                    </div>
                  )}
                </form>
              </div>
            </div>
          </div>

          {/* Analysis Results Section */}
          {analysisResult && (
            <div id="analysisResults" className="max-w-[2100px] mx-auto">
              {/* Analysis Header */}
              <div className="bg-[#1a3f75] p-6 sm:p-8 md:p-10 text-white rounded-xl shadow-md mb-8">
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
                  <div>
                    <h3 className="font-heading text-2xl md:text-3xl font-bold mb-2">Your Energy Analysis</h3>
                    <p className="opacity-90 text-blue-100">Completed on {formatDate(new Date())}</p>
                  </div>
                  {analysisResult.auraAnalysis.intensity !== undefined && (
                    <div className="mt-4 md:mt-0 bg-white/10 backdrop-blur-sm p-3 rounded-lg border border-white/20 flex flex-col items-center">
                      <div className="text-sm text-blue-100 mb-1">Overall Energy</div>
                      <div className="text-2xl font-bold text-white">{analysisResult.auraAnalysis.intensity}/10</div>
                    </div>
                  )}
                </div>
              </div>
              
              {/* Content Layout */}
              <div className="p-4 sm:p-6 md:p-8 max-w-[2100px] mx-auto">
                <div className="flex flex-col lg:flex-row gap-8 mb-10">
                  {/* Left Column - Image and Colors */}
                  <div className="lg:w-1/3">
                    {/* Image Card */}
                    <div className="card-light mb-8">
                      <div className="relative rounded-xl overflow-hidden shadow-md">
                        <img 
                          src={previewUrl!} 
                          alt="Your energy analysis" 
                          className="w-full h-auto z-10 relative" 
                        />
                        <div 
                          className="absolute inset-0 z-20 mix-blend-soft-light opacity-30" 
                          style={{ 
                            background: `
                              radial-gradient(circle at 30% 30%, rgba(167, 139, 250, 0.5), transparent 70%),
                              radial-gradient(circle at 70% 40%, rgba(56, 189, 248, 0.5), transparent 70%),
                              radial-gradient(circle at 40% 80%, rgba(251, 146, 60, 0.5), transparent 70%)
                            `
                          }}
                        ></div>
                      </div>
                      <div className="text-xs text-gray-500 mt-3 text-center">
                        Analysis Date: {formatDate(new Date())}
                      </div>
                    </div>
                    
                    {/* Primary Energy Card */}
                    <div className="card-light mb-8">
                      <h3 className="analysis-title border-b border-gray-100 pb-3 mb-4">Primary Energy Type</h3>
                      {analysisResult.auraAnalysis.colors.length > 0 && (
                        <div className="mb-4">
                          <div className="flex items-center gap-3 mb-3">
                            <div 
                              className={`w-6 h-6 rounded-full ${colorToDotClass(analysisResult.auraAnalysis.colors[0])}`}
                              aria-hidden="true"
                            ></div>
                            <span className="font-medium text-[#1a3f75]">{analysisResult.auraAnalysis.colors[0]}</span>
                          </div>
                          <p className="analysis-content mt-3">
                            {analysisResult.auraAnalysis.meanings[analysisResult.auraAnalysis.colors[0]] || 
                             "This color represents your dominant energy signature and primary spiritual influence."}
                          </p>
                        </div>
                      )}
                    </div>
                    
                    {/* Secondary Energy Card */}
                    <div className="card-blue">
                      <h3 className="text-xl font-semibold mb-4 border-b border-blue-700 pb-3">Secondary Energy Types</h3>
                      {analysisResult.auraAnalysis.colors.length > 1 ? (
                        <div className="space-y-4">
                          {analysisResult.auraAnalysis.colors.slice(1).map((color, index) => (
                            <div key={index} className="mb-4">
                              <div className="flex items-center gap-3 mb-2">
                                <div 
                                  className="w-5 h-5 rounded-full bg-white shadow-sm"
                                  style={{
                                    background: color.toLowerCase().includes('blue') ? '#3b82f6' : 
                                              color.toLowerCase().includes('purple') ? '#8b5cf6' : 
                                              color.toLowerCase().includes('green') ? '#10b981' : 
                                              color.toLowerCase().includes('yellow') ? '#f59e0b' : 
                                              color.toLowerCase().includes('red') ? '#ef4444' : 
                                              color.toLowerCase().includes('pink') ? '#ec4899' : '#3b82f6'
                                  }}
                                ></div>
                                <span className="font-medium text-white">{color}</span>
                              </div>
                              <p className="text-blue-100 text-sm leading-relaxed">
                                {analysisResult.auraAnalysis.meanings[color] || 
                                "This color adds depth and nuance to your energy field, representing secondary influences."}
                              </p>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <p className="text-blue-100">No secondary energy colors detected in this analysis.</p>
                      )}
                    </div>
                  </div>
                  
                  {/* Right Column - Main Analysis */}
                  <div className="lg:w-2/3">
                    {/* Energy Assessment Card */}
                    {analysisResult.auraAnalysis.intensity && (
                      <div className="card-light mb-8">
                        <h3 className="analysis-title border-b border-gray-100 pb-3 mb-4">Energy Assessment</h3>
                        <div>
                          <h4 className="text-[#1a3f75] font-semibold text-lg mb-3">Energy Intensity</h4>
                          <div className="p-5 rounded-lg bg-blue-50 border border-blue-100 relative">
                            {/* Simple intensity meter */}
                            <div className="flex items-center mb-3">
                              <div className="w-16 h-16 rounded-full bg-white border-4 border-blue-200 flex items-center justify-center shadow-sm mr-4">
                                <span className="text-2xl font-bold text-[#1a3f75]">{analysisResult.auraAnalysis.intensity}</span>
                              </div>
                              <div>
                                <h5 className="text-[#1a3f75] font-semibold">
                                  {analysisResult.auraAnalysis.intensity >= 8 ? "Exceptionally Strong" : 
                                   analysisResult.auraAnalysis.intensity >= 6 ? "Very Vibrant" : 
                                   analysisResult.auraAnalysis.intensity >= 4 ? "Balanced" : "Subtle"}
                                </h5>
                                <div className="text-sm text-gray-600">Energy Rating (out of 10)</div>
                              </div>
                            </div>
                            
                            {/* Intensity progress bar */}
                            <div className="w-full bg-blue-200 rounded-full h-2.5 mb-4">
                              <div 
                                className="bg-blue-600 h-2.5 rounded-full"
                                style={{ width: `${(analysisResult.auraAnalysis.intensity / 10) * 100}%` }}
                              ></div>
                            </div>
                            
                            <p className="text-gray-700 text-sm">
                              This represents the overall vibrancy and strength of your energy field. 
                              {analysisResult.auraAnalysis.intensity >= 8 
                                ? " Your exceptionally strong energy creates a powerful presence that influences those around you."
                                : analysisResult.auraAnalysis.intensity >= 6 
                                ? " Your vibrant energy creates a notable presence that positively affects your environment."
                                : analysisResult.auraAnalysis.intensity >= 4 
                                ? " Your balanced energy creates a harmonious presence that adapts well to different environments."
                                : " Your subtle energy creates a gentle, nuanced presence that is sensitive to others."}
                            </p>
                          </div>
                        </div>
                      </div>
                    )}
                    
                    {/* Energy Overview Section */}
                    <div className="card-light mb-8">
                      <h3 className="analysis-title border-b border-gray-100 pb-3 mb-4">Energy Overview</h3>
                      <div className="bg-gradient-to-r from-blue-50/80 to-indigo-50/80 backdrop-blur-sm p-5 rounded-xl border border-blue-100/50 shadow-sm relative z-10">
                        <p className="leading-relaxed text-gray-800 text-base">
                          {analysisResult.auraAnalysis.analysis.replace(/```json[\s\S]*?```/g, '').replace(/```[\s\S]*?```/g, '')}
                        </p>
                      </div>
                    </div>
                    
                    {/* Personal Insights Section */}
                    {analysisResult.auraAnalysis.personalInsights && (
                      <div className="card-light mb-8">
                        <h3 className="analysis-title border-b border-gray-100 pb-3 mb-4">Personal Insights</h3>
                        
                        {/* Strengths and Challenges */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                          <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg p-4 border border-blue-100">
                            <h4 className="text-blue-700 font-semibold mb-3 flex items-center">
                              <span className="inline-block w-4 h-4 bg-blue-500 rounded-full mr-2"></span>
                              Strengths
                            </h4>
                            <ul className="space-y-2 pl-6">
                              {analysisResult.auraAnalysis.personalInsights.strengths.map((strength, index) => (
                                <li key={index} className="text-gray-700">{strength}</li>
                              ))}
                            </ul>
                          </div>
                          
                          <div className="bg-gradient-to-r from-indigo-50 to-purple-50 rounded-lg p-4 border border-indigo-100">
                            <h4 className="text-indigo-700 font-semibold mb-3 flex items-center">
                              <span className="inline-block w-4 h-4 bg-indigo-500 rounded-full mr-2"></span>
                              Growth Areas
                            </h4>
                            <ul className="space-y-2 pl-6">
                              {analysisResult.auraAnalysis.personalInsights.challenges.map((challenge, index) => (
                                <li key={index} className="text-gray-700">{challenge}</li>
                              ))}
                            </ul>
                          </div>
                        </div>
                        
                        {/* Life Theme and Energy Forecast */}
                        <div className="space-y-6">
                          <div className="p-4 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg border border-blue-100 shadow-sm">
                            <h4 className="text-blue-700 font-semibold mb-3 flex items-center">
                              <span className="inline-block w-4 h-4 bg-blue-500 rounded-full mr-2"></span>
                              Your Current Life Theme
                            </h4>
                            <p className="italic text-gray-800 pl-6">{analysisResult.auraAnalysis.personalInsights.lifeTheme}</p>
                          </div>
                          
                          <div className="p-4 bg-gradient-to-r from-indigo-50 to-blue-50 rounded-lg border border-indigo-100 shadow-sm">
                            <h4 className="text-indigo-700 font-semibold mb-3 flex items-center">
                              <span className="inline-block w-4 h-4 bg-indigo-500 rounded-full mr-2"></span>
                              Energy Forecast
                            </h4>
                            <p className="text-gray-800 pl-6">{analysisResult.auraAnalysis.personalInsights.energyForecast}</p>
                          </div>
                        </div>
                      </div>
                    )}
                    
                    {/* Aspects Section */}
                    <div className="card-light mb-8">
                      <h3 className="analysis-title border-b border-gray-100 pb-3 mb-4">Energy Aspects</h3>
                      
                      {/* Tab Navigation */}
                      <div className="flex justify-center mb-8">
                        <div className="inline-flex bg-gray-100 rounded-full p-1 shadow-sm">
                          <button 
                            className={`px-6 py-3 rounded-full font-medium text-sm transition-all ${activeTab === 'overview' ? 'bg-white text-blue-600 shadow-md' : 'text-gray-500 hover:text-gray-700'}`}
                            onClick={() => setActiveTab('overview')}
                          >
                            Positive Aspects
                          </button>
                          <button 
                            className={`px-6 py-3 rounded-full font-medium text-sm transition-all ${activeTab === 'insights' ? 'bg-white text-blue-600 shadow-md' : 'text-gray-500 hover:text-gray-700'}`}
                            onClick={() => setActiveTab('insights')}
                          >
                            Growth Areas
                          </button>
                          <button 
                            className={`px-6 py-3 rounded-full font-medium text-sm transition-all ${activeTab === 'forecast' ? 'bg-white text-blue-600 shadow-md' : 'text-gray-500 hover:text-gray-700'}`}
                            onClick={() => setActiveTab('forecast')}
                          >
                            Energy Forecast
                          </button>
                        </div>
                      </div>
                      
                      {/* Tab Content */}
                      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
                        {activeTab === 'overview' && (
                          <div>
                            <div className="flex items-center justify-center mb-6">
                              <div className="w-16 h-16 bg-gradient-to-r from-blue-100 to-indigo-100 rounded-full grid place-items-center shadow-sm">
                                <Clock className="h-8 w-8 text-blue-600" />
                              </div>
                            </div>
                            <h3 className="text-center text-blue-800 text-xl font-bold mb-6">Positive Aspects</h3>
                            <ul className="space-y-4">
                              {analysisResult.auraAnalysis.positiveAspects.map((aspect, index) => (
                                <li key={index} className="flex items-start">
                                  <span className="inline-block w-6 h-6 bg-green-100 rounded-full flex items-center justify-center text-green-600 mr-3 mt-0.5 flex-shrink-0">✓</span>
                                  <span className="text-gray-700">{aspect}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                        
                        {activeTab === 'insights' && (
                          <div>
                            <div className="flex items-center justify-center mb-6">
                              <div className="w-16 h-16 bg-gradient-to-r from-indigo-100 to-purple-100 rounded-full grid place-items-center shadow-sm">
                                <Clock className="h-8 w-8 text-indigo-600" />
                              </div>
                            </div>
                            <h3 className="text-center text-indigo-800 text-xl font-bold mb-6">Growth Areas</h3>
                            <ul className="space-y-4">
                              {analysisResult.auraAnalysis.negativeAspects.map((aspect, index) => (
                                <li key={index} className="flex items-start">
                                  <span className="inline-block w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center text-blue-600 mr-3 mt-0.5 flex-shrink-0">→</span>
                                  <span className="text-gray-700">{aspect}</span>
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                        
                        {activeTab === 'forecast' && (
                          <div>
                            <div className="flex items-center justify-center mb-6">
                              <div className="w-16 h-16 bg-gradient-to-r from-purple-100 to-blue-100 rounded-full grid place-items-center shadow-sm">
                                <Clock className="h-8 w-8 text-purple-600" />
                              </div>
                            </div>
                            <h3 className="text-center text-purple-800 text-xl font-bold mb-6">Energy Forecast</h3>
                            <p className="text-gray-700 text-center mb-6">Your energy outlook for the coming period</p>
                            <div className="p-4 bg-gradient-to-r from-indigo-50 to-blue-50 rounded-lg border border-indigo-100 shadow-sm">
                              <p className="text-gray-800 leading-relaxed">
                                {analysisResult.auraAnalysis.personalInsights?.energyForecast || 
                                "Your energy is evolving in positive ways. Focus on maintaining balance while embracing new opportunities for growth."}
                              </p>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </main>
      
      <Footer />
    </div>
  );
}