import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

import {
  Calendar,
  Download,
  ExternalLink,
  Eye,
  Mail,
  Search,
  Trash2,
  User,
} from "lucide-react";
import { format } from "date-fns";

// Demo emails data
const DEMO_EMAILS = [
  {
    id: "email-1",
    to: "john.smith@techsolutions.com",
    from: "you@yourcompany.com",
    subject: "Connecting with John from Tech Solutions Inc.",
    text: "Hi John,\n\nI noticed your work at Tech Solutions Inc. and was particularly impressed with your focus on enterprise software development and cloud solutions. I'm reaching out because I believe our services could add significant value to your team's efforts.\n\nWould you be open to a brief conversation to explore how we might be able to support your initiatives at Tech Solutions Inc.?\n\nLooking forward to your response,\nYour Name",
    html: `<div style="font-family: sans-serif; max-width: 600px; margin: 0 auto;">
      <p>Hi John,</p>
      <p>I noticed your work at <strong>Tech Solutions Inc.</strong> and was particularly impressed with your focus on enterprise software development and cloud solutions. I'm reaching out because I believe our services could add significant value to your team's efforts.</p>
      <p>Would you be open to a brief conversation to explore how we might be able to support your initiatives at Tech Solutions Inc.?</p>
      <p>Looking forward to your response,<br>Your Name</p>
    </div>`,
    recipient: {
      name: "John Smith",
      company: "Tech Solutions Inc.",
      title: "Chief Technology Officer"
    },
    sentAt: new Date(2023, 11, 18, 14, 35),
    status: "delivered",
    openedAt: new Date(2023, 11, 18, 16, 12),
  },
  {
    id: "email-2",
    to: "michael@datainsights.io",
    from: "you@yourcompany.com",
    subject: "Following up on our conversation, Michael",
    text: "Hi Michael,\n\nI wanted to follow up on our previous conversation about Data Insights's approach to data analytics. I'm curious to learn more about the challenges you're facing and how we might be able to help.\n\nWould you have 15 minutes for a quick call next week?\n\nBest regards,\nYour Name",
    html: `<div style="font-family: sans-serif; max-width: 600px; margin: 0 auto;">
      <p>Hi Michael,</p>
      <p>I wanted to follow up on our previous conversation about <strong>Data Insights</strong>'s approach to data analytics. I'm curious to learn more about the challenges you're facing and how we might be able to help.</p>
      <p>Would you have 15 minutes for a quick call next week?</p>
      <p>Best regards,<br>Your Name</p>
    </div>`,
    recipient: {
      name: "Michael Lee",
      company: "Data Insights",
      title: "Data Analyst"
    },
    sentAt: new Date(2023, 11, 15, 10, 12),
    status: "delivered",
    openedAt: new Date(2023, 11, 15, 14, 22),
  },
  {
    id: "email-3",
    to: "jennifer.m@healthcare-innovations.org",
    from: "you@yourcompany.com",
    subject: "Proposal for Healthcare Innovations: Enhancing Your Healthcare Solutions",
    text: "Dear Jennifer,\n\nBased on our recent discussions regarding Healthcare Innovations's needs in the healthcare space, I've prepared a proposal that addresses the specific challenges you mentioned.\n\nThe proposal outlines:\n1. A tailored approach to your healthcare innovation requirements\n2. Implementation timeline and milestones\n3. Expected outcomes and ROI\n\nWould you like to schedule a time to review this together?\n\nRegards,\nYour Name",
    html: `<div style="font-family: sans-serif; max-width: 600px; margin: 0 auto;">
      <p>Dear Jennifer,</p>
      <p>Based on our recent discussions regarding <strong>Healthcare Innovations</strong>'s needs in the healthcare space, I've prepared a proposal that addresses the specific challenges you mentioned.</p>
      <p>The proposal outlines:</p>
      <ol>
        <li>A tailored approach to your healthcare innovation requirements</li>
        <li>Implementation timeline and milestones</li>
        <li>Expected outcomes and ROI</li>
      </ol>
      <p>Would you like to schedule a time to review this together?</p>
      <p>Regards,<br>Your Name</p>
    </div>`,
    recipient: {
      name: "Jennifer Martinez",
      company: "Healthcare Innovations",
      title: "Head of Innovation"
    },
    sentAt: new Date(2023, 11, 10, 9, 45),
    status: "delivered",
    openedAt: null,
  },
  {
    id: "email-4",
    to: "sarah.j@globalmarketing.co",
    from: "you@yourcompany.com",
    subject: "Thank you for your time, Sarah",
    text: "Hi Sarah,\n\nThank you for taking the time to meet with me today. I really appreciated learning more about Global Marketing Partners's approach to marketing and advertising and the unique challenges you're facing.\n\nAs discussed, I'll send over the additional information about our services that might help with your full-service marketing agency initiatives by the end of the week.\n\nFeel free to reach out if you have any questions in the meantime.\n\nBest,\nYour Name",
    html: `<div style="font-family: sans-serif; max-width: 600px; margin: 0 auto;">
      <p>Hi Sarah,</p>
      <p>Thank you for taking the time to meet with me today. I really appreciated learning more about <strong>Global Marketing Partners</strong>'s approach to marketing and advertising and the unique challenges you're facing.</p>
      <p>As discussed, I'll send over the additional information about our services that might help with your full-service marketing agency initiatives by the end of the week.</p>
      <p>Feel free to reach out if you have any questions in the meantime.</p>
      <p>Best,<br>Your Name</p>
    </div>`,
    recipient: {
      name: "Sarah Johnson",
      company: "Global Marketing Partners",
      title: "Marketing Director"
    },
    sentAt: new Date(2023, 11, 5, 16, 30),
    status: "delivered",
    openedAt: new Date(2023, 11, 6, 9, 15),
  },
  {
    id: "email-5",
    to: "dwilson@fintech-capital.com",
    from: "you@yourcompany.com",
    subject: "Request for a meeting - David (FinTech Capital)",
    text: "Hello David,\n\nI hope this email finds you well. I'd like to request a meeting to discuss how our solutions could potentially address the challenges in venture capital firm focusing on financial technology startups that we've previously discussed.\n\nWould any of these times work for you next week?\n- Tuesday at 10:00 AM\n- Wednesday at 2:00 PM\n- Thursday at 11:00 AM\n\nLooking forward to connecting,\nYour Name",
    html: `<div style="font-family: sans-serif; max-width: 600px; margin: 0 auto;">
      <p>Hello David,</p>
      <p>I hope this email finds you well. I'd like to request a meeting to discuss how our solutions could potentially address the challenges in venture capital firm focusing on financial technology startups that we've previously discussed.</p>
      <p>Would any of these times work for you next week?</p>
      <ul>
        <li>Tuesday at 10:00 AM</li>
        <li>Wednesday at 2:00 PM</li>
        <li>Thursday at 11:00 AM</li>
      </ul>
      <p>Looking forward to connecting,<br>Your Name</p>
    </div>`,
    recipient: {
      name: "David Wilson",
      company: "FinTech Capital",
      title: "Investment Analyst"
    },
    sentAt: new Date(2023, 10, 28, 11, 20),
    status: "delivered",
    openedAt: new Date(2023, 10, 28, 15, 45),
  }
];

export default function DemoSentEmailsPage() {
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  const [viewEmailId, setViewEmailId] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<"html" | "text">("html");
  
  // Filter emails based on search term
  const filteredEmails = DEMO_EMAILS.filter(email => {
    const searchable = `${email.recipient.name} ${email.recipient.company} ${email.subject}`.toLowerCase();
    return searchable.includes(searchTerm.toLowerCase());
  });

  // Get selected email data
  const selectedEmail = viewEmailId ? DEMO_EMAILS.find(email => email.id === viewEmailId) : null;

  // Format date
  const formatDate = (date: Date) => {
    return format(date, "MMM d, yyyy 'at' h:mm a");
  };

  // Handle export button click
  const handleExport = () => {
    toast({
      title: "Demo Mode",
      description: "Export functionality is disabled in demo mode.",
    });
  };

  // Handle delete button click
  const handleDelete = () => {
    toast({
      title: "Demo Mode",
      description: "Email deletion is disabled in demo mode.",
    });
    setViewEmailId(null);
  };

  return (
    <div className="container mx-auto py-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Sent Emails</h1>
          <p className="text-muted-foreground">
            View and manage your sent emails
          </p>
        </div>
        <Button variant="outline" onClick={handleExport}>
          <Download className="mr-2 h-4 w-4" />
          Export to CSV
        </Button>
      </div>

      <div className="flex items-center mb-4">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search sent emails..."
            className="pl-8"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      <div className="bg-white rounded-md border shadow-sm overflow-hidden">
        <div className="p-4 border-b bg-muted/50">
          <div className="font-medium">Recent Emails</div>
        </div>
        <div className="divide-y">
          {filteredEmails.length === 0 ? (
            <div className="p-8 text-center">
              <Mail className="mx-auto h-10 w-10 text-muted-foreground mb-3" />
              <h3 className="text-lg font-medium mb-2">No emails found</h3>
              <p className="text-muted-foreground">
                Try a different search term or check back later for new emails.
              </p>
            </div>
          ) : (
            filteredEmails.map(email => (
              <div
                key={email.id}
                className="p-4 hover:bg-muted/50 cursor-pointer"
                onClick={() => setViewEmailId(email.id)}
              >
                <div className="flex justify-between items-start mb-1">
                  <div className="font-medium">{email.subject}</div>
                  <div className="text-xs text-muted-foreground flex items-center">
                    <Calendar className="h-3 w-3 mr-1" />
                    {formatDate(email.sentAt)}
                  </div>
                </div>
                <div className="flex justify-between">
                  <div className="flex items-center text-sm text-muted-foreground">
                    <User className="h-3.5 w-3.5 mr-1" />
                    <span>
                      {email.recipient.name} ({email.recipient.title}) at {email.recipient.company}
                    </span>
                  </div>
                  <div className="text-xs flex items-center">
                    {email.openedAt ? (
                      <span className="text-green-600 flex items-center">
                        <Eye className="h-3 w-3 mr-1" />
                        Opened {format(email.openedAt, "MMM d")}
                      </span>
                    ) : (
                      <span className="text-muted-foreground">Not opened yet</span>
                    )}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Email Viewer Dialog */}
      {selectedEmail && (
        <Dialog open={viewEmailId !== null} onOpenChange={(open) => !open && setViewEmailId(null)}>
          <DialogContent className="max-w-4xl">
            <DialogHeader>
              <DialogTitle className="text-xl">{selectedEmail.subject}</DialogTitle>
              <DialogDescription className="flex justify-between items-center">
                <div className="flex items-center">
                  <User className="h-4 w-4 mr-1" />
                  <span>
                    To: {selectedEmail.recipient.name} ({selectedEmail.recipient.title}) at {selectedEmail.recipient.company}
                  </span>
                </div>
                <div className="text-xs">
                  {formatDate(selectedEmail.sentAt)}
                </div>
              </DialogDescription>
            </DialogHeader>
            
            <Tabs defaultValue="html" value={viewMode} onValueChange={(v) => setViewMode(v as "html" | "text")}>
              <TabsList className="grid w-[200px] grid-cols-2">
                <TabsTrigger value="html">HTML View</TabsTrigger>
                <TabsTrigger value="text">Text View</TabsTrigger>
              </TabsList>
              <TabsContent value="html" className="border rounded-md p-4 min-h-[300px] max-h-[500px] overflow-auto">
                <div dangerouslySetInnerHTML={{ __html: selectedEmail.html }} />
              </TabsContent>
              <TabsContent value="text" className="border rounded-md p-4 min-h-[300px] max-h-[500px] overflow-auto whitespace-pre-line font-mono text-sm">
                {selectedEmail.text}
              </TabsContent>
            </Tabs>

            <div className="flex items-center justify-between py-2">
              <div className="text-sm">
                {selectedEmail.openedAt ? (
                  <span className="text-green-600 flex items-center">
                    <Eye className="h-4 w-4 mr-1" />
                    Opened on {formatDate(selectedEmail.openedAt)}
                  </span>
                ) : (
                  <span className="text-muted-foreground flex items-center">
                    <Eye className="h-4 w-4 mr-1" />
                    Not opened yet
                  </span>
                )}
              </div>
              <div className="text-sm text-muted-foreground">
                Status: {selectedEmail.status}
              </div>
            </div>
            
            <DialogFooter className="sm:justify-between">
              <Button variant="outline" className="text-destructive" onClick={handleDelete}>
                <Trash2 className="mr-2 h-4 w-4" />
                Delete
              </Button>
              <div className="flex gap-2">
                <Button variant="outline" onClick={() => setViewEmailId(null)}>
                  Close
                </Button>
                <Button>
                  <Mail className="mr-2 h-4 w-4" />
                  Send Again
                </Button>
              </div>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}