import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";

import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";

import {
  Clock,
  Edit,
  FilePenLine,
  Mail,
  Plus,
  Search,
  Star,
  Trash2,
  AlertCircle,
  Mail as MailIcon,
} from "lucide-react";

// Demo email templates data
const DEMO_TEMPLATES = [
  {
    id: 1,
    name: "Initial Outreach",
    subject: "Connecting with {firstName} from {company}",
    body: `Hi {firstName},

I noticed your work at {company} and was particularly impressed with your focus on {companyDescription}. I'm reaching out because I believe our services could add significant value to your team's efforts.

Would you be open to a brief conversation to explore how we might be able to support your initiatives at {company}?

Looking forward to your response,
[Your Name]`,
    lastUsed: new Date("2023-12-15"),
    usageCount: 24,
    starred: true,
  },
  {
    id: 2,
    name: "Follow-up Message",
    subject: "Following up on our conversation, {firstName}",
    body: `Hi {firstName},

I wanted to follow up on our previous conversation about {company}'s approach to {industry}. I'm curious to learn more about the challenges you're facing and how we might be able to help.

Would you have 15 minutes for a quick call next week?

Best regards,
[Your Name]`,
    lastUsed: new Date("2023-12-10"),
    usageCount: 18,
    starred: false,
  },
  {
    id: 3,
    name: "Proposal Introduction",
    subject: "Proposal for {company}: Enhancing Your {industry} Solutions",
    body: `Dear {firstName},

Based on our recent discussions regarding {company}'s needs in the {industry} space, I've prepared a proposal that addresses the specific challenges you mentioned.

The proposal outlines:
1. A tailored approach to your {companyDescription} requirements
2. Implementation timeline and milestones
3. Expected outcomes and ROI

Would you like to schedule a time to review this together?

Regards,
[Your Name]`,
    lastUsed: new Date("2023-12-05"),
    usageCount: 12,
    starred: true,
  },
  {
    id: 4,
    name: "Meeting Request",
    subject: "Request for a meeting - {firstName} ({company})",
    body: `Hello {firstName},

I hope this email finds you well. I'd like to request a meeting to discuss how our solutions could potentially address the challenges in {companyDescription} that we've previously discussed.

Would any of these times work for you next week?
- Tuesday at 10:00 AM
- Wednesday at 2:00 PM
- Thursday at 11:00 AM

Looking forward to connecting,
[Your Name]`,
    lastUsed: new Date("2023-11-28"),
    usageCount: 8,
    starred: false,
  },
  {
    id: 5,
    name: "Thank You After Meeting",
    subject: "Thank you for your time, {firstName}",
    body: `Hi {firstName},

Thank you for taking the time to meet with me today. I really appreciated learning more about {company}'s approach to {industry} and the unique challenges you're facing.

As discussed, I'll send over the additional information about our services that might help with your {companyDescription} initiatives by the end of the week.

Feel free to reach out if you have any questions in the meantime.

Best,
[Your Name]`,
    lastUsed: new Date("2023-11-15"),
    usageCount: 15,
    starred: false,
  }
];

export default function DemoEmailTemplatesPage() {
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [selectedTemplate, setSelectedTemplate] = useState<number | null>(null);
  
  // Filter templates based on search term
  const filteredTemplates = DEMO_TEMPLATES.filter(template => {
    const searchable = `${template.name} ${template.subject} ${template.body}`.toLowerCase();
    return searchable.includes(searchTerm.toLowerCase());
  });

  // Get selected template data
  const selectedTemplateData = selectedTemplate !== null 
    ? DEMO_TEMPLATES.find(t => t.id === selectedTemplate) 
    : null;

  // Handle star/unstar
  const handleToggleStar = (id: number) => {
    toast({
      title: "Demo Mode",
      description: "Template starring is disabled in demo mode.",
    });
  };

  // Handle template creation
  const handleCreateTemplate = () => {
    toast({
      title: "Demo Mode",
      description: "Template creation is disabled in demo mode.",
    });
    setIsCreateDialogOpen(false);
  };

  // Handle template edit
  const handleEditTemplate = () => {
    toast({
      title: "Demo Mode",
      description: "Template editing is disabled in demo mode.",
    });
    setIsEditDialogOpen(false);
  };

  // Handle template deletion
  const handleDeleteTemplate = () => {
    toast({
      title: "Demo Mode",
      description: "Template deletion is disabled in demo mode.",
    });
    setIsDeleteDialogOpen(false);
  };

  // Format date as "X days ago"
  const formatLastUsed = (date: Date) => {
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - date.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays === 1 ? "1 day ago" : `${diffDays} days ago`;
  };

  return (
    <div className="container mx-auto py-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Email Templates</h1>
          <p className="text-muted-foreground">
            Create and manage email templates for outreach
          </p>
        </div>
        <Button onClick={() => setIsCreateDialogOpen(true)}>
          <Plus className="mr-2 h-4 w-4" />
          New Template
        </Button>
      </div>

      <div className="flex items-center mb-4">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search templates..."
            className="pl-8"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
        {filteredTemplates.length === 0 ? (
          <div className="col-span-3 bg-muted rounded-lg p-8 text-center">
            <AlertCircle className="mx-auto h-10 w-10 text-muted-foreground mb-3" />
            <h3 className="text-lg font-medium mb-2">No templates found</h3>
            <p className="text-muted-foreground mb-4">
              Try a different search term or create a new template.
            </p>
            <Button onClick={() => setIsCreateDialogOpen(true)}>
              <Plus className="mr-2 h-4 w-4" />
              Create Template
            </Button>
          </div>
        ) : (
          filteredTemplates.map(template => (
            <Card key={template.id} className="relative">
              {template.starred && (
                <div className="absolute top-2 right-2">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 text-amber-600"
                    onClick={() => handleToggleStar(template.id)}
                  >
                    <Star className="h-4 w-4 fill-current" />
                  </Button>
                </div>
              )}
              <CardHeader>
                <CardTitle className="pr-8">{template.name}</CardTitle>
                <CardDescription className="flex items-center">
                  <Clock className="mr-1 h-3.5 w-3.5" />
                  Last used: {formatLastUsed(template.lastUsed)}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="mb-2">
                  <span className="font-medium">Subject:</span>
                  <div className="text-sm text-muted-foreground truncate">
                    {template.subject}
                  </div>
                </div>
                <div>
                  <span className="font-medium">Body:</span>
                  <div className="text-sm text-muted-foreground line-clamp-3 whitespace-pre-line">
                    {template.body}
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Badge variant="outline" className="flex items-center">
                  <MailIcon className="mr-1 h-3 w-3" />
                  Used {template.usageCount} times
                </Badge>
                <div className="flex space-x-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setSelectedTemplate(template.id);
                      setIsEditDialogOpen(true);
                    }}
                  >
                    <Edit className="mr-1 h-3.5 w-3.5" />
                    Edit
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    className="text-destructive"
                    onClick={() => {
                      setSelectedTemplate(template.id);
                      setIsDeleteDialogOpen(true);
                    }}
                  >
                    <Trash2 className="mr-1 h-3.5 w-3.5" />
                    Delete
                  </Button>
                </div>
              </CardFooter>
            </Card>
          ))
        )}
      </div>

      {/* Template placeholder guide */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="text-lg">Template Placeholders Guide</CardTitle>
          <CardDescription>
            Use these placeholders in your templates to personalize emails for each contact
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Placeholder</TableHead>
                <TableHead>Description</TableHead>
                <TableHead>Example</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              <TableRow>
                <TableCell className="font-mono">{"{firstName}"}</TableCell>
                <TableCell>Contact's first name</TableCell>
                <TableCell>John</TableCell>
              </TableRow>
              <TableRow>
                <TableCell className="font-mono">{"{lastName}"}</TableCell>
                <TableCell>Contact's last name</TableCell>
                <TableCell>Smith</TableCell>
              </TableRow>
              <TableRow>
                <TableCell className="font-mono">{"{company}"}</TableCell>
                <TableCell>Company name</TableCell>
                <TableCell>Acme Inc.</TableCell>
              </TableRow>
              <TableRow>
                <TableCell className="font-mono">{"{companyDescription}"}</TableCell>
                <TableCell>Brief description of the company</TableCell>
                <TableCell>cloud-based software solutions</TableCell>
              </TableRow>
              <TableRow>
                <TableCell className="font-mono">{"{industry}"}</TableCell>
                <TableCell>Industry category</TableCell>
                <TableCell>Information Technology</TableCell>
              </TableRow>
              <TableRow>
                <TableCell className="font-mono">{"{title}"}</TableCell>
                <TableCell>Contact's job title</TableCell>
                <TableCell>Chief Technology Officer</TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Create Template Dialog */}
      <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Create Email Template</DialogTitle>
            <DialogDescription>
              Create a new template for your email outreach campaigns.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div>
              <Label htmlFor="name">Template Name</Label>
              <Input id="name" placeholder="e.g., Initial Outreach" />
            </div>
            <div>
              <Label htmlFor="subject">Email Subject</Label>
              <Input id="subject" placeholder="e.g., Connecting with {firstName} from {company}" />
            </div>
            <div>
              <Label htmlFor="body">Email Body</Label>
              <Textarea
                id="body"
                placeholder="Write your email template here..."
                className="min-h-[200px]"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleCreateTemplate}>
              Create Template
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Template Dialog */}
      {selectedTemplateData && (
        <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogContent className="max-w-3xl">
            <DialogHeader>
              <DialogTitle>Edit Email Template</DialogTitle>
              <DialogDescription>
                Make changes to your email template.
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div>
                <Label htmlFor="edit-name">Template Name</Label>
                <Input
                  id="edit-name"
                  value={selectedTemplateData.name}
                />
              </div>
              <div>
                <Label htmlFor="edit-subject">Email Subject</Label>
                <Input
                  id="edit-subject"
                  value={selectedTemplateData.subject}
                />
              </div>
              <div>
                <Label htmlFor="edit-body">Email Body</Label>
                <Textarea
                  id="edit-body"
                  value={selectedTemplateData.body}
                  className="min-h-[200px]"
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={handleEditTemplate}>
                Save Changes
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* Delete Template Dialog */}
      {selectedTemplateData && (
        <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Delete Template</DialogTitle>
              <DialogDescription>
                Are you sure you want to delete this template? This action cannot be undone.
              </DialogDescription>
            </DialogHeader>
            <div className="py-4">
              <p className="font-medium">{selectedTemplateData.name}</p>
              <p className="text-sm text-muted-foreground mt-1">
                This template has been used {selectedTemplateData.usageCount} times.
              </p>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
                Cancel
              </Button>
              <Button variant="destructive" onClick={handleDeleteTemplate}>
                Delete Template
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}

// Label component for this page
const Label = ({ htmlFor, children, className = "" }: { htmlFor?: string, children: React.ReactNode, className?: string }) => (
  <label
    htmlFor={htmlFor}
    className={`text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 mb-2 block ${className}`}
  >
    {children}
  </label>
);