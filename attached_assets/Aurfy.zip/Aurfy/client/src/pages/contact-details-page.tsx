import { useState, useEffect } from "react";
import { useRoute, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Loader2, Send, ArrowLeft, Pencil, Trash2, ExternalLink } from "lucide-react";

// Define types
type LinkedInContact = {
  id: number;
  firstName: string;
  lastName: string;
  title: string | null;
  company: string | null;
  companyDescription: string | null;
  industry: string | null;
  location: string | null;
  connectionDegree: string | null;
  email: string | null;
  profileUrl: string;
  notes: string | null;
  lastUpdated: string;
  emailSent: boolean;
  emailSentDate: string | null;
};

type EmailTemplate = {
  id: number;
  name: string;
  subject: string;
  bodyTemplate: string;
  createdAt: string;
  lastUsed: string | null;
};

// Contact form schema
const contactUpdateSchema = z.object({
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  title: z.string().nullable().optional(),
  company: z.string().nullable().optional(),
  companyDescription: z.string().nullable().optional(),
  industry: z.string().nullable().optional(),
  location: z.string().nullable().optional(),
  connectionDegree: z.string().nullable().optional(),
  email: z.string().email("Invalid email format").nullable().optional(),
  notes: z.string().nullable().optional(),
});

// Email form schema
const emailFormSchema = z.object({
  templateId: z.number().optional(),
  fromEmail: z.string().email("Valid email address is required"),
  customSubject: z.string().optional(),
  customBody: z.string().optional(),
});

export default function ContactDetailsPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [, params] = useRoute("/linkedin/contacts/:id");
  const contactId = params?.id ? parseInt(params.id) : null;
  
  const [isEditMode, setIsEditMode] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [isEmailDialogOpen, setIsEmailDialogOpen] = useState(false);
  
  // Get the action from the URL query if any
  const urlSearchParams = new URLSearchParams(window.location.search);
  const action = urlSearchParams.get('action');
  
  // If action=email in the URL, open the email dialog
  useEffect(() => {
    if (action === 'email') {
      setIsEmailDialogOpen(true);
      
      // Clear the query parameter from the URL
      const url = new URL(window.location.href);
      url.searchParams.delete('action');
      window.history.replaceState({}, '', url);
    }
  }, [action]);

  // Fetch contact details
  const { data: contact, isLoading: isLoadingContact } = useQuery({
    queryKey: ["/api/linkedin/contacts", contactId],
    enabled: !!contactId && !!user,
  });

  // Fetch email templates
  const { data: emailTemplates = [] } = useQuery({
    queryKey: ["/api/email-templates"],
    enabled: !!user,
  });

  // Contact edit form
  const contactForm = useForm<z.infer<typeof contactUpdateSchema>>({
    resolver: zodResolver(contactUpdateSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      title: "",
      company: "",
      companyDescription: "",
      industry: "",
      location: "",
      connectionDegree: "",
      email: "",
      notes: "",
    },
  });

  // Email form
  const emailForm = useForm<z.infer<typeof emailFormSchema>>({
    resolver: zodResolver(emailFormSchema),
    defaultValues: {
      templateId: undefined,
      fromEmail: user?.email || "",
      customSubject: "",
      customBody: "",
    },
  });

  // Update form values when contact data is loaded
  useEffect(() => {
    if (contact) {
      contactForm.reset({
        firstName: contact.firstName,
        lastName: contact.lastName,
        title: contact.title || "",
        company: contact.company || "",
        companyDescription: contact.companyDescription || "",
        industry: contact.industry || "",
        location: contact.location || "",
        connectionDegree: contact.connectionDegree || "",
        email: contact.email || "",
        notes: contact.notes || "",
      });
    }
  }, [contact, contactForm]);

  // Update contact mutation
  const updateContactMutation = useMutation({
    mutationFn: async (data: z.infer<typeof contactUpdateSchema>) => {
      if (!contactId) throw new Error("Contact ID is required");
      
      const response = await apiRequest(`/api/linkedin/contacts/${contactId}`, {
        method: "PUT",
        body: JSON.stringify(data),
      });
      return response;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/linkedin/contacts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/linkedin/contacts", contactId] });
      toast({
        title: "Success",
        description: "Contact updated successfully.",
      });
      setIsEditMode(false);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update contact: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Delete contact mutation
  const deleteContactMutation = useMutation({
    mutationFn: async () => {
      if (!contactId) throw new Error("Contact ID is required");
      
      const response = await apiRequest(`/api/linkedin/contacts/${contactId}`, {
        method: "DELETE",
      });
      return response;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/linkedin/contacts"] });
      toast({
        title: "Success",
        description: "Contact deleted successfully.",
      });
      setLocation("/linkedin/contacts");
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to delete contact: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Send email mutation
  const sendEmailMutation = useMutation({
    mutationFn: async (data: z.infer<typeof emailFormSchema>) => {
      if (!contactId) throw new Error("Contact ID is required");
      
      const response = await apiRequest(`/api/send-email/${contactId}`, {
        method: "POST",
        body: JSON.stringify(data),
      });
      return response;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/linkedin/contacts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/linkedin/contacts", contactId] });
      toast({
        title: "Success",
        description: "Email sent successfully.",
      });
      setIsEmailDialogOpen(false);
      emailForm.reset({
        templateId: undefined,
        fromEmail: user?.email || "",
        customSubject: "",
        customBody: "",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to send email: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Check if the selected template has changed
  const watchTemplateId = emailForm.watch('templateId');
  
  // When template selection changes, update subject and body
  useEffect(() => {
    if (watchTemplateId) {
      const selectedTemplate = emailTemplates.find((template: EmailTemplate) => template.id === watchTemplateId);
      if (selectedTemplate) {
        emailForm.setValue('customSubject', selectedTemplate.subject);
        emailForm.setValue('customBody', selectedTemplate.bodyTemplate);
      }
    }
  }, [watchTemplateId, emailTemplates, emailForm]);

  if (isLoadingContact) {
    return (
      <div className="container mx-auto py-12 text-center">
        <Loader2 className="h-8 w-8 animate-spin mx-auto" />
        <p className="mt-4 text-lg text-muted-foreground">Loading contact details...</p>
      </div>
    );
  }

  if (!contact) {
    return (
      <div className="container mx-auto py-12 text-center">
        <h2 className="text-2xl font-bold">Contact Not Found</h2>
        <p className="mt-4 text-muted-foreground">The requested contact could not be found.</p>
        <Button className="mt-6" onClick={() => setLocation("/linkedin/contacts")}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Contacts
        </Button>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-6">
      <div className="mb-6">
        <Button
          variant="outline"
          onClick={() => setLocation("/linkedin/contacts")}
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Contacts
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Main Info Column */}
        <div className="md:col-span-2">
          <Card className="mb-6">
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle className="text-2xl">
                  {contact.firstName} {contact.lastName}
                </CardTitle>
                <CardDescription>
                  {contact.title} {contact.company ? `at ${contact.company}` : ""}
                </CardDescription>
              </div>
              <div className="flex space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setIsEditMode(!isEditMode)}
                >
                  <Pencil className="h-4 w-4 mr-2" />
                  {isEditMode ? "Cancel" : "Edit"}
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => window.open(contact.profileUrl, '_blank')}
                >
                  <ExternalLink className="h-4 w-4 mr-2" />
                  LinkedIn
                </Button>
              </div>
            </CardHeader>
            
            <CardContent>
              {isEditMode ? (
                <Form {...contactForm}>
                  <form onSubmit={contactForm.handleSubmit((data) => updateContactMutation.mutate(data))} className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={contactForm.control}
                        name="firstName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>First Name</FormLabel>
                            <FormControl>
                              <Input {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={contactForm.control}
                        name="lastName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Last Name</FormLabel>
                            <FormControl>
                              <Input {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={contactForm.control}
                        name="title"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Title</FormLabel>
                            <FormControl>
                              <Input {...field} value={field.value || ""} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={contactForm.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Email</FormLabel>
                            <FormControl>
                              <Input {...field} value={field.value || ""} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <FormField
                      control={contactForm.control}
                      name="company"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Company</FormLabel>
                          <FormControl>
                            <Input {...field} value={field.value || ""} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={contactForm.control}
                      name="companyDescription"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Company Description</FormLabel>
                          <FormControl>
                            <Textarea
                              {...field}
                              value={field.value || ""}
                              rows={3}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={contactForm.control}
                        name="industry"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Industry</FormLabel>
                            <FormControl>
                              <Input {...field} value={field.value || ""} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={contactForm.control}
                        name="location"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Location</FormLabel>
                            <FormControl>
                              <Input {...field} value={field.value || ""} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <FormField
                      control={contactForm.control}
                      name="notes"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Notes</FormLabel>
                          <FormControl>
                            <Textarea
                              {...field}
                              value={field.value || ""}
                              rows={3}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="flex justify-between pt-4">
                      <Button
                        type="button"
                        variant="destructive"
                        onClick={() => setIsDeleteDialogOpen(true)}
                      >
                        <Trash2 className="h-4 w-4 mr-2" />
                        Delete Contact
                      </Button>
                      <div className="space-x-2">
                        <Button
                          type="button"
                          variant="outline"
                          onClick={() => setIsEditMode(false)}
                        >
                          Cancel
                        </Button>
                        <Button
                          type="submit"
                          disabled={updateContactMutation.isPending}
                        >
                          {updateContactMutation.isPending && (
                            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                          )}
                          Save Changes
                        </Button>
                      </div>
                    </div>
                  </form>
                </Form>
              ) : (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-6">
                    {contact.email && (
                      <div>
                        <Label className="text-muted-foreground">Email</Label>
                        <p className="font-medium">{contact.email}</p>
                      </div>
                    )}
                    {contact.industry && (
                      <div>
                        <Label className="text-muted-foreground">Industry</Label>
                        <p className="font-medium">{contact.industry}</p>
                      </div>
                    )}
                  </div>
                  
                  {contact.company && (
                    <div>
                      <Label className="text-muted-foreground">Company</Label>
                      <p className="font-medium">{contact.company}</p>
                    </div>
                  )}
                  
                  {contact.companyDescription && (
                    <div>
                      <Label className="text-muted-foreground">Company Description</Label>
                      <p>{contact.companyDescription}</p>
                    </div>
                  )}
                  
                  <div className="grid grid-cols-2 gap-6">
                    {contact.location && (
                      <div>
                        <Label className="text-muted-foreground">Location</Label>
                        <p>{contact.location}</p>
                      </div>
                    )}
                    {contact.connectionDegree && (
                      <div>
                        <Label className="text-muted-foreground">Connection</Label>
                        <p>{contact.connectionDegree} connection</p>
                      </div>
                    )}
                  </div>
                  
                  {contact.notes && (
                    <div>
                      <Label className="text-muted-foreground">Notes</Label>
                      <p className="whitespace-pre-line">{contact.notes}</p>
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Status Column */}
        <div>
          <Card>
            <CardHeader>
              <CardTitle>Contact Status</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label className="text-muted-foreground">Status</Label>
                <div className="mt-1">
                  {contact.emailSent ? (
                    <Badge variant="success">Email Sent</Badge>
                  ) : (
                    <Badge variant="outline">Not Contacted</Badge>
                  )}
                </div>
              </div>
              
              {contact.emailSent && contact.emailSentDate && (
                <div>
                  <Label className="text-muted-foreground">Email Sent On</Label>
                  <p>{new Date(contact.emailSentDate).toLocaleDateString()} at {new Date(contact.emailSentDate).toLocaleTimeString()}</p>
                </div>
              )}
              
              <div>
                <Label className="text-muted-foreground">Last Updated</Label>
                <p>{new Date(contact.lastUpdated).toLocaleDateString()}</p>
              </div>
              
              <Separator className="my-4" />
              
              <div className="pt-2">
                <Button
                  className="w-full"
                  disabled={!contact.email}
                  onClick={() => setIsEmailDialogOpen(true)}
                >
                  <Send className="mr-2 h-4 w-4" />
                  {contact.emailSent ? "Send Another Email" : "Send Email"}
                </Button>
                {!contact.email && (
                  <p className="mt-2 text-xs text-muted-foreground text-center">
                    No email address available for this contact.
                  </p>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Delete Confirmation Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Deletion</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete this contact? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsDeleteDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button
              variant="destructive"
              onClick={() => deleteContactMutation.mutate()}
              disabled={deleteContactMutation.isPending}
            >
              {deleteContactMutation.isPending && (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              )}
              Delete Contact
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Send Email Dialog */}
      <Dialog open={isEmailDialogOpen} onOpenChange={setIsEmailDialogOpen}>
        <DialogContent className="sm:max-w-[700px]">
          <DialogHeader>
            <DialogTitle>Send Email to {contact.firstName} {contact.lastName}</DialogTitle>
            <DialogDescription>
              Compose an email to send to {contact.email}
            </DialogDescription>
          </DialogHeader>
          <Form {...emailForm}>
            <form onSubmit={emailForm.handleSubmit((data) => sendEmailMutation.mutate(data))} className="space-y-4">
              <FormField
                control={emailForm.control}
                name="fromEmail"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>From Email</FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={emailForm.control}
                name="templateId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email Template</FormLabel>
                    <Select
                      onValueChange={(value) => field.onChange(parseInt(value))}
                      defaultValue={field.value?.toString()}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select a template (optional)" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {emailTemplates.map((template: EmailTemplate) => (
                          <SelectItem key={template.id} value={template.id.toString()}>
                            {template.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormDescription>
                      Choose a template or write a custom email below.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={emailForm.control}
                name="customSubject"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Subject</FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>
                    <FormDescription>
                      You can use placeholders like {{firstName}}, {{company}}, etc.
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={emailForm.control}
                name="customBody"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email Body</FormLabel>
                    <FormControl>
                      <Textarea
                        {...field}
                        rows={10}
                        className="font-mono text-sm"
                      />
                    </FormControl>
                    <FormDescription>
                      Available placeholders: {{firstName}}, {{lastName}}, {{company}}, {{title}}, {{companyDescription}}, {{industry}}
                    </FormDescription>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <DialogFooter>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsEmailDialogOpen(false)}
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={sendEmailMutation.isPending}
                >
                  {sendEmailMutation.isPending && (
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  )}
                  Send Email
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}