import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { queryClient, apiRequest } from "@/lib/queryClient";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input"; 
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { AuraReading } from "@shared/schema";
import { formatDate, colorToClass, colorToDotClass } from "@/lib/utils";
import { Loader2, User, FileText, Calendar, Clock, Eye, Trash2, Sparkles, DollarSign, Award, Edit, Save, X, Plus } from "lucide-react";
import { Link } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";

// Healer Profile Editor Component
function HealerProfileEditor({ profile, updateProfileMutation }: { 
  profile: any, 
  updateProfileMutation: any 
}) {
  const { toast } = useToast();
  const [isEditing, setIsEditing] = useState(false);
  const [newSpecialty, setNewSpecialty] = useState("");
  
  // Fetch aura readings
  const { 
    data: auraReadings, 
    isLoading: isLoadingReadings 
  } = useQuery<AuraReading[]>({
    queryKey: ["/api/aura-readings"],
    enabled: true,
  });
  
  // Create form schema with validation
  const formSchema = z.object({
    bio: z.string().min(20, "Bio must be at least 20 characters"),
    specialties: z.array(z.string()).min(1, "Add at least one specialty"),
    yearsExperience: z.coerce.number().min(0, "Must be a positive number"),
    pricePerHour: z.coerce.number().min(0, "Must be a positive number"),
    imageUrl: z.string().optional(),
  });

  // Initialize form with current profile values
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      bio: profile.bio || "",
      specialties: profile.specialties || [],
      yearsExperience: profile.yearsExperience || 0,
      pricePerHour: profile.pricePerHour || 0,
      imageUrl: profile.imageUrl || "",
    },
  });

  // Handle form submission
  const onSubmit = (data: z.infer<typeof formSchema>) => {
    updateProfileMutation.mutate(data);
    setIsEditing(false);
  };

  // Add specialty
  const addSpecialty = () => {
    if (newSpecialty.trim()) {
      const currentSpecialties = form.getValues().specialties || [];
      form.setValue("specialties", [...currentSpecialties, newSpecialty.trim()]);
      setNewSpecialty("");
    }
  };

  // Remove specialty
  const removeSpecialty = (index: number) => {
    const currentSpecialties = form.getValues().specialties;
    form.setValue(
      "specialties",
      currentSpecialties.filter((_, i) => i !== index)
    );
  };

  // Handle specialty input keypress
  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      e.preventDefault();
      addSpecialty();
    }
  };

  if (isEditing) {
    return (
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle>Edit Your Healer Profile</CardTitle>
            <Button variant="outline" size="sm" onClick={() => setIsEditing(false)}>
              <X className="h-4 w-4 mr-2" /> Cancel
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              {/* Bio */}
              <FormField
                control={form.control}
                name="bio"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>About You</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Tell clients about your background, approach to healing, and what makes your services unique..."
                        className="min-h-32 resize-none"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Specialties */}
              <FormField
                control={form.control}
                name="specialties"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Your Specialties</FormLabel>
                    <div className="space-y-3">
                      <div className="flex gap-2">
                        <FormControl>
                          <Input
                            placeholder="Add a specialty (e.g., 'Chakra Balancing', 'Reiki')"
                            value={newSpecialty}
                            onChange={e => setNewSpecialty(e.target.value)}
                            onKeyPress={handleKeyPress}
                          />
                        </FormControl>
                        <Button type="button" onClick={addSpecialty} className="flex-shrink-0">
                          <Plus className="h-4 w-4 mr-2" /> Add
                        </Button>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {field.value.map((specialty, index) => (
                          <div
                            key={index}
                            className="bg-neutral-lightest px-3 py-1 rounded-full flex items-center gap-1"
                          >
                            <span className="text-sm">{specialty}</span>
                            <button
                              type="button"
                              onClick={() => removeSpecialty(index)}
                              className="text-muted-foreground hover:text-destructive rounded-full w-5 h-5 flex items-center justify-center"
                            >
                              <X className="h-3 w-3" />
                            </button>
                          </div>
                        ))}
                        {field.value.length === 0 && (
                          <div className="text-sm text-muted-foreground">
                            No specialties added yet
                          </div>
                        )}
                      </div>
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Years Experience */}
                <FormField
                  control={form.control}
                  name="yearsExperience"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Years of Experience</FormLabel>
                      <FormControl>
                        <Input type="number" min="0" step="1" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Price Per Hour */}
                <FormField
                  control={form.control}
                  name="pricePerHour"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Hourly Rate ($)</FormLabel>
                      <FormControl>
                        <Input type="number" min="0" step="5" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              {/* Image URL */}
              <FormField
                control={form.control}
                name="imageUrl"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Profile Image URL (Optional)</FormLabel>
                    <FormControl>
                      <Input placeholder="https://example.com/your-image.jpg" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="flex justify-end pt-4">
                <Button
                  type="submit"
                  disabled={updateProfileMutation.isPending}
                  className="pink-purple-gradient text-white"
                >
                  {updateProfileMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Saving...
                    </>
                  ) : (
                    <>
                      <Save className="mr-2 h-4 w-4" /> Save Changes
                    </>
                  )}
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    );
  }

  // View mode (not editing)
  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-heading text-accent-dark">Your Healer Profile</h2>
        <Button onClick={() => setIsEditing(true)}>
          <Edit className="h-4 w-4 mr-2" /> Edit Profile
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Bio Card */}
        <Card className="lg:col-span-2 bg-blue-50 border border-blue-200 shadow-md">
          <CardHeader>
            <CardTitle className="flex items-center text-xl text-indigo-900">
              <User className="h-5 w-5 mr-2 text-indigo-600" /> About You
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-indigo-800 whitespace-pre-wrap">{profile.bio}</p>
          </CardContent>
        </Card>

        {/* Stats Card */}
        <Card className="bg-purple-50 border border-purple-200 shadow-md">
          <CardHeader>
            <CardTitle className="text-xl text-purple-900">Offering Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <div className="flex items-center mb-2">
                <Award className="h-5 w-5 mr-2 text-primary" />
                <h3 className="font-medium">Experience</h3>
              </div>
              <p className="text-accent ml-7">{profile.yearsExperience} years</p>
            </div>
            
            <div>
              <div className="flex items-center mb-2">
                <DollarSign className="h-5 w-5 mr-2 text-primary" />
                <h3 className="font-medium">Hourly Rate</h3>
              </div>
              <p className="text-accent ml-7">${profile.pricePerHour}/hour</p>
            </div>
            
            <div>
              <div className="flex items-center mb-2">
                <Sparkles className="h-5 w-5 mr-2 text-primary" />
                <h3 className="font-medium">Specialties</h3>
              </div>
              <div className="flex flex-wrap gap-2 ml-7">
                {profile.specialties && profile.specialties.length > 0 ? (
                  profile.specialties.map((specialty: string, index: number) => (
                    <span 
                      key={index}
                      className="bg-neutral-lightest px-2 py-1 rounded-full text-xs"
                    >
                      {specialty}
                    </span>
                  ))
                ) : (
                  <p className="text-muted-foreground">No specialties listed</p>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Client Readings (Only visible to healer) */}
      <Card className="bg-gradient-to-r from-indigo-50 to-purple-50 border border-indigo-200 shadow-md">
        <CardHeader>
          <CardTitle className="flex items-center text-xl text-indigo-900">
            <FileText className="h-5 w-5 mr-2 text-indigo-600" /> Client Readings
          </CardTitle>
          <CardDescription className="text-indigo-700">
            Track the aura readings you've provided to clients (only visible to you)
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoadingReadings ? (
            <div className="flex justify-center items-center h-40">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
              <span className="ml-2 text-accent">Loading readings...</span>
            </div>
          ) : !auraReadings || auraReadings.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-muted-foreground mb-4">
                You haven't performed any readings yet.
              </p>
              <Link href="/analysis">
                <Button>Start New Reading</Button>
              </Link>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-3 px-4">Date</th>
                    <th className="text-left py-3 px-4">Colors</th>
                    <th className="text-left py-3 px-4">Type</th>
                    <th className="text-left py-3 px-4">Client</th>
                    <th className="text-left py-3 px-4">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {auraReadings.map((reading) => (
                    <tr key={reading.id} className="border-b hover:bg-neutral-lightest">
                      <td className="py-3 px-4">
                        {formatDate(reading.date)}
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex flex-wrap gap-1">
                          {reading.colors && reading.colors.map((color, index) => {
                            const dotClass = colorToDotClass(color);
                            return (
                              <span key={index} className={`inline-block w-3 h-3 rounded-full ${dotClass}`} title={color}></span>
                            );
                          })}
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        {reading.hasNumerology ? "Aura + Numerology" : "Aura Only"}
                      </td>
                      <td className="py-3 px-4">
                        {reading.userId === profile.userId ? "Self" : "Client"}
                      </td>
                      <td className="py-3 px-4">
                        <Button size="sm" variant="outline">
                          <Eye className="h-3 w-3 mr-1" /> View
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

export default function ClientProfilePage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("profile");

  // Fetch user's aura readings
  const { 
    data: auraReadings, 
    isLoading: isLoadingReadings 
  } = useQuery<AuraReading[]>({
    queryKey: ["/api/aura-readings"],
    enabled: !!user,
  });

  // Fetch user's journal entries
  const { 
    data: journalEntries, 
    isLoading: isLoadingJournal 
  } = useQuery<any[]>({
    queryKey: ["/api/journal-entries"],
    enabled: !!user && activeTab === "journal",
  });

  // Delete journal entry mutation
  const deleteEntryMutation = useMutation({
    mutationFn: async (entryId: number) => {
      await apiRequest("DELETE", `/api/journal-entries/${entryId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/journal-entries"] });
      toast({
        title: "Journal entry deleted",
        description: "Your journal entry has been successfully deleted.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to delete journal entry: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Generate user initials for avatar
  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((part) => part[0])
      .join("")
      .toUpperCase();
  };

  if (!user) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-grow flex items-center justify-center">
          <Card className="w-full max-w-md">
            <CardHeader>
              <CardTitle>Authentication Required</CardTitle>
              <CardDescription>Please log in to view your profile</CardDescription>
            </CardHeader>
            <CardContent className="flex justify-center">
              <Link href="/auth">
                <Button>Go to Login</Button>
              </Link>
            </CardContent>
          </Card>
        </main>
        <Footer />
      </div>
    );
  }

  // Fetch healer profile if user is a healer
  const { 
    data: healerProfile, 
    isLoading: isLoadingProfile
  } = useQuery({
    queryKey: ["/api/healers/profile"],
    enabled: !!user && user.type === "HEALER",
  });

  // Mutation to create/update healer profile
  const updateProfileMutation = useMutation({
    mutationFn: async (profileData: any) => {
      return await apiRequest("PUT", "/api/healers/profile", profileData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/healers/profile"] });
      toast({
        title: "Profile updated",
        description: "Your healer profile has been successfully updated.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to update profile: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow">
        <div className="container mx-auto px-4 py-8">
          <div className="max-w-6xl mx-auto">
            {/* Healer Profile Creation Prompt */}
            {user.type === "HEALER" && !healerProfile && !isLoadingProfile && (
              <Card className="mb-8 border-2 border-pink-300 bg-pink-50">
                <CardContent className="p-6">
                  <h2 className="font-heading text-2xl text-purple-800 mb-2">Complete Your Healer Profile</h2>
                  <p className="text-gray-700 mb-4">
                    Welcome to AuraInsight! To be listed in our healer directory and connect with clients,
                    please complete your healer profile with your specialties, experience, and approach.
                  </p>
                  <Link href="/healer/create-profile">
                    <Button className="pink-purple-gradient text-white hover:opacity-90">
                      Create Your Healer Profile
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            )}
            
            {/* Profile Header */}
            <div className="bg-gradient-to-r from-primary to-secondary rounded-xl mb-8 p-8 text-white">
              <div className="flex flex-col md:flex-row items-center gap-6">
                <Avatar className="w-24 h-24 border-4 border-white/30">
                  <AvatarFallback className="text-3xl bg-accent text-white">
                    {getInitials(user.fullName)}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <h1 className="font-heading text-3xl font-bold">{user.fullName}</h1>
                  <p className="opacity-90">{user.email}</p>
                  <p className="text-sm opacity-75">Member since {user.createdAt ? formatDate(user.createdAt) : "recently"}</p>
                </div>
              </div>
            </div>
            
            {/* Tabs */}
            <Tabs defaultValue="profile" value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="mb-6">
                <TabsTrigger value="profile" className="flex items-center gap-2">
                  <User className="h-4 w-4" /> Profile
                </TabsTrigger>
                <TabsTrigger value="readings" className="flex items-center gap-2">
                  <FileText className="h-4 w-4" /> Aura Readings
                </TabsTrigger>
                <TabsTrigger value="journal" className="flex items-center gap-2">
                  <Calendar className="h-4 w-4" /> Journal Entries
                </TabsTrigger>
                {user.type === "HEALER" && (
                  <TabsTrigger value="healerProfile" className="flex items-center gap-2">
                    <Sparkles className="h-4 w-4" /> Healer Profile
                  </TabsTrigger>
                )}
              </TabsList>
              
              {/* Profile Tab */}
              <TabsContent value="profile">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <Card className="bg-blue-50 border border-blue-200 shadow-md">
                    <CardHeader>
                      <CardTitle className="text-indigo-900">Personal Information</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div>
                          <div className="text-sm text-indigo-600">Full Name</div>
                          <div className="font-medium text-indigo-800">{user.fullName}</div>
                        </div>
                        <div>
                          <div className="text-sm text-indigo-600">Username</div>
                          <div className="font-medium text-indigo-800">{user.username}</div>
                        </div>
                        <div>
                          <div className="text-sm text-indigo-600">Email</div>
                          <div className="font-medium text-indigo-800">{user.email}</div>
                        </div>
                        <div>
                          <div className="text-sm text-indigo-600">Account Type</div>
                          <div className="font-medium text-indigo-800 capitalize">{user.type}</div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card className="bg-purple-50 border border-purple-200 shadow-md">
                    <CardHeader>
                      <CardTitle className="text-purple-900">Account Summary</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div className="p-4 bg-neutral-lightest rounded-lg flex items-center">
                          <FileText className="text-primary h-10 w-10 mr-4" />
                          <div>
                            <div className="text-sm text-muted-foreground">Aura Readings</div>
                            <div className="text-2xl font-medium">
                              {isLoadingReadings ? (
                                <Loader2 className="h-5 w-5 animate-spin inline-block" />
                              ) : (
                                auraReadings?.length || 0
                              )}
                            </div>
                          </div>
                        </div>
                        
                        <div className="p-4 bg-neutral-lightest rounded-lg flex items-center">
                          <Calendar className="text-primary h-10 w-10 mr-4" />
                          <div>
                            <div className="text-sm text-muted-foreground">Journal Entries</div>
                            <div className="text-2xl font-medium">
                              {isLoadingJournal ? (
                                <Loader2 className="h-5 w-5 animate-spin inline-block" />
                              ) : (
                                journalEntries?.length || 0
                              )}
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex gap-4 mt-6">
                          <Button className="flex-1">Edit Profile</Button>
                          <Button variant="outline" className="flex-1">Change Password</Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
              
              {/* Readings Tab */}
              <TabsContent value="readings">
                {isLoadingReadings ? (
                  <div className="flex justify-center items-center h-40">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                    <span className="ml-2 text-accent">Loading your aura readings...</span>
                  </div>
                ) : !auraReadings || auraReadings.length === 0 ? (
                  <Card>
                    <CardContent className="py-10 text-center">
                      <FileText className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                      <h3 className="font-heading text-xl mb-2">No Aura Readings Yet</h3>
                      <p className="text-muted-foreground mb-6">
                        Get insights into your energy field by starting your first aura analysis.
                      </p>
                      <Link href="/analysis">
                        <Button>Start Aura Analysis</Button>
                      </Link>
                    </CardContent>
                  </Card>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {auraReadings.map((reading) => (
                      <Card key={reading.id} className="overflow-hidden">
                        <div className="bg-gradient-to-r from-primary-light to-secondary p-4 text-white">
                          <div className="flex justify-between items-center">
                            <h3 className="font-heading text-lg">Aura Reading</h3>
                            <div className="text-sm opacity-80">{formatDate(reading.date)}</div>
                          </div>
                        </div>
                        <CardContent className="p-4">
                          <div className="flex flex-wrap gap-1 mb-3">
                            {reading.colors.map((color, index) => {
                              const colorClasses = colorToClass(color);
                              const dotClass = colorToDotClass(color);
                              
                              return (
                                <span 
                                  key={index}
                                  className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${colorClasses.bg} ${colorClasses.text}`}
                                >
                                  <span className={`w-2 h-2 rounded-full ${dotClass} mr-1`}></span>
                                  {color}
                                </span>
                              );
                            })}
                          </div>
                          
                          <p className="text-sm text-accent mb-4 line-clamp-3">
                            {reading.analysis.substring(0, 150)}...
                          </p>
                          
                          <div className="flex items-center justify-between">
                            <div className="text-xs text-muted-foreground">
                              {reading.hasNumerology ? "Includes numerology" : "Aura only"}
                            </div>
                            <Button size="sm" variant="outline" className="text-xs">
                              <Eye className="h-3 w-3 mr-1" /> View Full Reading
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
                
                <div className="flex justify-center mt-8">
                  <Link href="/analysis">
                    <Button>
                      <FileText className="mr-2 h-4 w-4" /> Get New Aura Reading
                    </Button>
                  </Link>
                </div>
              </TabsContent>
              
              {/* Journal Tab */}
              <TabsContent value="journal">
                {isLoadingJournal ? (
                  <div className="flex justify-center items-center h-40">
                    <Loader2 className="h-8 w-8 animate-spin text-primary" />
                    <span className="ml-2 text-accent">Loading your journal entries...</span>
                  </div>
                ) : !journalEntries || journalEntries.length === 0 ? (
                  <Card>
                    <CardContent className="py-10 text-center">
                      <Calendar className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                      <h3 className="font-heading text-xl mb-2">Your Journal is Empty</h3>
                      <p className="text-muted-foreground mb-6">
                        Start tracking your spiritual journey with journal entries.
                      </p>
                      <Link href="/journal">
                        <Button>Write First Entry</Button>
                      </Link>
                    </CardContent>
                  </Card>
                ) : (
                  <div className="space-y-6">
                    {journalEntries.map((entry) => (
                      <Card key={entry.id}>
                        <CardContent className="pt-6">
                          <div className="flex justify-between items-start mb-4">
                            <div>
                              <h3 className="font-heading text-xl text-accent-dark">{entry.title}</h3>
                              <div className="flex items-center text-sm text-muted-foreground">
                                <Clock className="h-3 w-3 mr-1" />
                                {formatDate(entry.date)}
                              </div>
                            </div>
                            <div className="flex gap-2">
                              <Link href={`/journal/${entry.id}`}>
                                <Button size="sm" variant="outline">
                                  <Eye className="h-4 w-4 mr-1" /> View
                                </Button>
                              </Link>
                              <Button 
                                size="sm" 
                                variant="outline"
                                className="text-destructive hover:text-destructive-foreground hover:bg-destructive"
                                onClick={() => deleteEntryMutation.mutate(entry.id)}
                                disabled={deleteEntryMutation.isPending}
                              >
                                {deleteEntryMutation.isPending && deleteEntryMutation.variables === entry.id ? (
                                  <Loader2 className="h-4 w-4 animate-spin" />
                                ) : (
                                  <Trash2 className="h-4 w-4" />
                                )}
                              </Button>
                            </div>
                          </div>
                          <p className="text-accent line-clamp-3">{entry.content}</p>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
                
                <div className="flex justify-center mt-8">
                  <Link href="/journal">
                    <Button>
                      <Calendar className="mr-2 h-4 w-4" /> Go to Journal
                    </Button>
                  </Link>
                </div>
              </TabsContent>
              
              {/* Healer Profile Tab */}
              {user.type === "HEALER" && (
                <TabsContent value="healerProfile">
                  {isLoadingProfile ? (
                    <div className="flex justify-center items-center h-40">
                      <Loader2 className="h-8 w-8 animate-spin text-primary" />
                      <span className="ml-2 text-accent">Loading your healer profile...</span>
                    </div>
                  ) : !healerProfile ? (
                    <Card>
                      <CardContent className="py-10 text-center">
                        <Sparkles className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                        <h3 className="font-heading text-xl mb-2">No Healer Profile Yet</h3>
                        <p className="text-muted-foreground mb-6">
                          Create a profile to showcase your healing services to potential clients.
                        </p>
                        <Link href="/healer/create-profile">
                          <Button className="pink-purple-gradient text-white">Create Healer Profile</Button>
                        </Link>
                      </CardContent>
                    </Card>
                  ) : (
                    <HealerProfileEditor 
                      profile={healerProfile} 
                      updateProfileMutation={updateProfileMutation} 
                    />
                  )}
                </TabsContent>
              )}
            </Tabs>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
