import { useState } from "react";
import { useLocation } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { queryClient, apiRequest } from "@/lib/queryClient";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { HealerProfile, insertHealerProfileSchema } from "@shared/schema";
import { z } from "zod";
import { Loader2, Plus, X } from "lucide-react";

// Create a form schema with validation
const formSchema = z.object({
  bio: z.string().min(20, "Bio must be at least 20 characters"),
  specialties: z.array(z.string()).min(1, "Add at least one specialty"),
  yearsExperience: z.coerce.number().min(0, "Must be a positive number"),
  pricePerHour: z.coerce.number().min(0, "Must be a positive number"),
  imageUrl: z.string().optional(),
});

type FormValues = z.infer<typeof formSchema>;

export default function CreateHealerProfilePage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [newSpecialty, setNewSpecialty] = useState("");

  // Initialize form
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      bio: "",
      specialties: [],
      yearsExperience: 0,
      pricePerHour: 0,
      imageUrl: "",
    },
  });

  // Define mutation
  const createProfileMutation = useMutation({
    mutationFn: async (data: FormValues) => {
      return await apiRequest("POST", "/api/healers/profile", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/healers/profile"] });
      toast({
        title: "Profile created",
        description: "Your healer profile has been successfully created!",
      });
      setLocation("/profile");
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to create profile: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Handle form submission
  const onSubmit = (data: FormValues) => {
    createProfileMutation.mutate(data);
  };

  // Add specialty
  const addSpecialty = () => {
    if (newSpecialty.trim()) {
      const currentSpecialties = form.getValues().specialties || [];
      form.setValue("specialties", [...currentSpecialties, newSpecialty.trim()]);
      setNewSpecialty("");
    }
  };

  // Remove specialty
  const removeSpecialty = (index: number) => {
    const currentSpecialties = form.getValues().specialties;
    form.setValue(
      "specialties",
      currentSpecialties.filter((_, i) => i !== index)
    );
  };

  // Handle specialty input keypress
  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      e.preventDefault();
      addSpecialty();
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-grow flex items-center justify-center">
          <Card className="w-full max-w-md">
            <CardHeader>
              <CardTitle>Authentication Required</CardTitle>
              <CardDescription>Please log in to create a healer profile</CardDescription>
            </CardHeader>
            <CardContent className="flex justify-center">
              <Button onClick={() => setLocation("/auth")} className="pink-purple-gradient">Go to Login</Button>
            </CardContent>
          </Card>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow">
        <div className="container mx-auto px-4 py-8">
          <div className="max-w-3xl mx-auto">
            <Card>
              <CardHeader>
                <CardTitle className="text-2xl font-heading">Create Your Healer Profile</CardTitle>
                <CardDescription>
                  Complete your profile to be listed in our healer directory and connect with clients
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                    {/* Bio */}
                    <FormField
                      control={form.control}
                      name="bio"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>About You</FormLabel>
                          <FormControl>
                            <Textarea
                              placeholder="Tell clients about your background, approach to healing, and what makes your services unique..."
                              className="min-h-32 resize-none"
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* Specialties */}
                    <FormField
                      control={form.control}
                      name="specialties"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Your Specialties</FormLabel>
                          <div className="space-y-3">
                            <div className="flex gap-2">
                              <FormControl>
                                <Input
                                  placeholder="Add a specialty (e.g., 'Chakra Balancing', 'Reiki')"
                                  value={newSpecialty}
                                  onChange={e => setNewSpecialty(e.target.value)}
                                  onKeyPress={handleKeyPress}
                                />
                              </FormControl>
                              <Button type="button" onClick={addSpecialty} className="flex-shrink-0 pink-purple-gradient">
                                <Plus className="h-4 w-4 mr-2" /> Add
                              </Button>
                            </div>
                            <div className="flex flex-wrap gap-2">
                              {field.value.map((specialty, index) => (
                                <div
                                  key={index}
                                  className="bg-purple-100 px-3 py-1 rounded-full flex items-center gap-1"
                                >
                                  <span className="text-sm text-purple-800">{specialty}</span>
                                  <button
                                    type="button"
                                    onClick={() => removeSpecialty(index)}
                                    className="bg-[#8a2be2] text-white rounded-full w-5 h-5 flex items-center justify-center"
                                  >
                                    <X className="h-3 w-3" />
                                  </button>
                                </div>
                              ))}
                              {field.value.length === 0 && (
                                <div className="text-sm text-muted-foreground">
                                  No specialties added yet
                                </div>
                              )}
                            </div>
                          </div>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {/* Years Experience */}
                      <FormField
                        control={form.control}
                        name="yearsExperience"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Years of Experience</FormLabel>
                            <FormControl>
                              <Input type="number" min="0" step="1" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      {/* Price Per Hour */}
                      <FormField
                        control={form.control}
                        name="pricePerHour"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Hourly Rate ($)</FormLabel>
                            <FormControl>
                              <Input type="number" min="0" step="5" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    {/* Image URL */}
                    <FormField
                      control={form.control}
                      name="imageUrl"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Profile Image URL (Optional)</FormLabel>
                          <FormControl>
                            <Input placeholder="https://example.com/your-image.jpg" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="flex justify-end pt-4">
                      <Button
                        type="submit"
                        disabled={createProfileMutation.isPending}
                        className="pink-purple-gradient"
                      >
                        {createProfileMutation.isPending ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Creating...
                          </>
                        ) : (
                          "Create Profile"
                        )}
                      </Button>
                    </div>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}