import { useEffect } from "react";
import { useAuth } from "@/hooks/use-auth";
import { AuthForm } from "@/components/ui/auth-form";
import { useLocation } from "wouter";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import { Bath } from "lucide-react";

export default function AuthPage() {
  const { user, isLoading } = useAuth();
  const [, navigate] = useLocation();

  useEffect(() => {
    if (user && !isLoading) {
      navigate("/");
    }
  }, [user, isLoading, navigate]);

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow container mx-auto px-4 py-12 bg-white">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center max-w-6xl mx-auto">
          <div>
            <AuthForm />
          </div>
          
          <div className="hidden md:block">
            <div className="gradient-border p-8 bg-purple-900 text-white">
              <div className="flex items-center mb-6">
                <div className="w-12 h-12 rounded-full bg-primary flex items-center justify-center mr-4">
                  <Bath className="text-white h-6 w-6" />
                </div>
                <h2 className="font-heading text-3xl text-primary">Welcome to AuraInsight</h2>
              </div>
              
              <p className="text-black mb-4">
                Your journey to spiritual discovery and energy healing begins here.
              </p>
              
              <ul className="space-y-4 mb-6">
                <li className="flex items-start">
                  <div className="bg-primary-light text-black w-6 h-6 rounded-full flex items-center justify-center mr-3 mt-1 shrink-0">1</div>
                  <div>
                    <h3 className="font-heading font-medium text-black">Discover Your Aura</h3>
                    <p className="text-gray-300">Upload a photo and receive a detailed analysis of your energy field and aura colors.</p>
                  </div>
                </li>
                <li className="flex items-start">
                  <div className="text-black w-6 h-6 rounded-full flex items-center justify-center mr-3 mt-1 shrink-0">2</div>
                  <div>
                    <h3 className="font-heading font-medium text-black">Connect With Healers</h3>
                    <p className="text-gray-300">Find energy healers who specialize in balancing your unique energy profile.</p>
                  </div>
                </li>
                <li className="flex items-start">
                  <div className="bg-primary-dark text-black w-6 h-6 rounded-full flex items-center justify-center mr-3 mt-1 shrink-0">3</div>
                  <div>
                    <h3 className="font-heading font-medium text-black">Track Your Journey</h3>
                    <p className="text-gray-300">Keep a spiritual journal and monitor your energy shifts over time.</p>
                  </div>
                </li>
              </ul>
              
              <div className="p-4 bg-purple-800 rounded-lg border border-purple-600">
                <p className="text-purple-200 italic text-sm">
                  "AuraInsight helped me understand my energy patterns and connect with a healer who completely transformed my spiritual practice."
                </p>
                <div className="mt-2 text-sm text-white font-medium">— Sarah J., AuraInsight Client</div>
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
