import { useState, useEffect } from "react";
import { Link } from "wouter";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { formatDate, colorToClass, colorToDotClass } from "@/lib/utils";
import { FileText, Calendar, Printer, Share, Save } from "lucide-react";

// Mock analysis result to showcase the improved design
const mockAnalysisResult = {
  id: 1,
  auraAnalysis: {
    colors: [
      "Indigo Blue",
      "Violet Purple",
      "Emerald Green",
      "Golden Yellow"
    ],
    meanings: {
      "Indigo Blue": "Represents intuition, perception, and deep inner wisdom. Your strong indigo presence indicates a highly developed intuitive ability and capacity for deep insight.",
      "Violet Purple": "Associated with spiritual awareness, transformation, and higher consciousness. This color in your aura suggests you're in a period of spiritual growth and expansion.",
      "Emerald Green": "Symbolizes healing, balance, and heart-centered energy. This vibrant green shows your natural ability to heal yourself and others.",
      "Golden Yellow": "Reflects intellectual activity, optimism, and mental clarity. This golden hue indicates a bright, analytical mind and positive outlook."
    },
    analysis: "Your aura showcases a remarkable blend of spiritual insight and practical wisdom. The dominant Indigo Blue and Violet Purple colors reveal your strong intuitive abilities and connection to higher consciousness, while the balance of Emerald Green demonstrates your healing capacity and heart-centered approach to life. The presence of Golden Yellow indicates intellectual clarity that helps you effectively implement your spiritual insights into everyday situations.\n\nThis unique combination suggests you're in a period where intuitive insights can be readily translated into practical healing work and intellectual pursuits. Your energy field shows a harmonious balance between spiritual receptivity and grounded action, making this an excellent time for both spiritual practices and creative intellectual projects.",
    positiveAspects: [
      "Strong intuitive abilities and psychic sensitivity",
      "Natural healing capacity with heart-centered awareness",
      "Intellectual clarity and analytical strength",
      "Balanced connection between spiritual and physical realms",
      "Ability to transform intuitive insights into practical wisdom"
    ],
    negativeAspects: [
      "Tendency to absorb others' energies without proper boundaries",
      "May prioritize intellectual understanding over emotional processing",
      "Risk of spiritual overwhelm without grounding practices",
      "Occasional difficulty staying present due to intuitive distractions",
      "Need for better integration of spiritual insights with daily routine"
    ],
    personalInsights: {
      strengths: [
        "Natural healing abilities particularly effective with emotional issues",
        "Exceptional intuitive guidance that helps navigate complex situations",
        "Ability to communicate spiritual concepts in accessible ways",
        "Strong capacity for empathic understanding of others"
      ],
      challenges: [
        "Setting and maintaining energetic boundaries with others",
        "Grounding spiritual insights into practical daily routines",
        "Balancing analytical thinking with emotional intelligence",
        "Avoiding spiritual bypassing of practical challenges"
      ],
      lifeTheme: "Integration of spiritual wisdom with practical healing work in service to collective evolution",
      energyForecast: "The next three months show a significant expansion in your intuitive abilities, suggesting an increase in spiritual insights and awareness. This will be supported by your strong emotional intelligence, though you'll need to pay extra attention to grounding practices. Focus on translating these insights into your healing work for maximum alignment and effectiveness."
    },
    intensity: 7.8,
    colorIntensities: {
      indigo: 8.5,
      violet: 7.9,
      emerald: 6.4,
      golden: 5.8
    }
  },
  numerologyData: {
    fullName: "Jane Alexandra Smith",
    birthDate: "1985-06-15",
    lifePathNumber: 8,
    expressionNumber: 5,
    soulUrgeNumber: 7,
    lifePathMeaning: "Life Path 8 suggests you have natural leadership abilities and a drive toward material and financial success. You have the potential to achieve significant accomplishments through discipline, organization, and practical management skills.",
    expressionMeaning: "Expression Number 5 reveals your adaptable, freedom-loving nature. You express yourself best when you have variety, travel, and new experiences. You communicate with enthusiasm and have a natural ability to inspire others through your versatility.",
    soulUrgeMeaning: "Soul Urge 7 indicates a deep inner desire for wisdom, spiritual understanding, and discovery of life's mysteries. Your soul seeks knowledge, introspection, and understanding of the deeper meaning behind everything.",
    analysis: "The combination of Life Path 8, Expression 5, and Soul Urge 7 creates an interesting dynamic in your personality. Your Life Path 8 drives you toward material success and achievement in the physical world, while your Soul Urge 7 creates a strong pull toward spiritual understanding and inner wisdom. Your Expression 5 provides the adaptability and communication skills to bridge these two seemingly opposite tendencies. This suggests your life journey involves finding ways to bring spiritual wisdom into practical, real-world applications – possibly through teaching, writing, or creating systems that help others integrate spiritual principles into daily life. The challenge is balancing your need for freedom and variety (5) with the discipline required for success (8) and the solitude needed for spiritual development (7)."
  }
};

export default function DemoAnalysisPage() {
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [showNumerology, setShowNumerology] = useState(true);
  const [analysisResult, setAnalysisResult] = useState(mockAnalysisResult);

  // Load a sample aura image for demonstration
  useEffect(() => {
    // You could use a different image path if you have one in the assets folder
    setPreviewUrl("https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop");
  }, []);

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow bg-white">
        <div className="container mx-auto px-4 py-8">
          <div className="max-w-3xl mx-auto">
            <h2 className="font-heading text-3xl font-bold text-center mb-8">
              <span className="minrims-gradient-text">Demo Aura Analysis</span>
            </h2>
            
            <div className="minrims-card w-full mx-auto">
              <div className="minrims-gradient p-4 sm:p-6 md:p-8 text-white">
                <h3 className="font-heading text-2xl md:text-3xl font-bold mb-2">Your Aura Analysis</h3>
                <p className="opacity-90">Completed on {formatDate(new Date())}</p>
              </div>
              
              {/* Main content area with 2100px max width */}
              <div className="p-4 sm:p-6 md:p-10 w-full mx-auto max-w-[2100px]">
                
                {/* Image centered at top */}
                <div className="mb-8">
                  <div className="flex justify-center">
                    <div className="relative max-w-md">
                      {/* Enhanced image container with decorative elements */}
                      <div className="relative">
                        {/* Multi-layered decorative background */}
                        <div className="absolute -inset-3 bg-gradient-to-br from-indigo-100 via-blue-50 to-purple-100 rounded-2xl blur-sm opacity-80"></div>
                        <div className="absolute -inset-1 bg-white rounded-xl"></div>
                        
                        {/* Pseudo-aura glow effects */}
                        <div 
                          className="absolute -top-4 -left-4 w-32 h-32 bg-gradient-to-br from-yellow-400/30 to-amber-500/20 rounded-full blur-xl"
                          aria-hidden="true"
                        ></div>
                        <div 
                          className="absolute -bottom-4 -right-4 w-32 h-32 bg-gradient-to-br from-purple-400/30 to-indigo-500/20 rounded-full blur-xl"
                          aria-hidden="true"
                        ></div>
                        
                        {/* Image with aura effect overlay */}
                        <div className="relative rounded-xl overflow-hidden shadow-lg border border-white">
                          {previewUrl && (
                            <img 
                              src={previewUrl} 
                              alt="Your aura visualization" 
                              className="w-full h-auto z-10 relative" 
                            />
                          )}
                          
                          {/* Aura glow effect */}
                          <div 
                            className="absolute inset-0 z-20 mix-blend-soft-light opacity-40" 
                            style={{ 
                              background: `
                                radial-gradient(circle at 30% 30%, rgba(167, 139, 250, 0.5), transparent 70%),
                                radial-gradient(circle at 70% 40%, rgba(56, 189, 248, 0.5), transparent 70%),
                                radial-gradient(circle at 40% 80%, rgba(251, 146, 60, 0.5), transparent 70%)
                              `
                            }}
                          ></div>
                          
                          {/* Edge glow */}
                          <div 
                            className="absolute inset-0 rounded-xl z-10" 
                            style={{ 
                              background: "radial-gradient(circle, transparent 60%, rgba(96, 165, 250, 0.2))"
                            }}
                          ></div>
                        </div>
                      </div>
                      
                      {/* Decorative badge */}
                      <div className="absolute -bottom-4 -right-4 z-30 bg-white rounded-xl p-3 shadow-lg border border-gray-100 backdrop-blur-sm">
                        <div className="w-10 h-10 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-lg flex items-center justify-center">
                          <span className="text-white text-xs font-bold">AURA</span>
                        </div>
                      </div>
                      
                      {/* Date badge */}
                      <div className="absolute -top-2 -left-2 z-30 bg-white/90 backdrop-blur-sm rounded-lg py-1 px-3 shadow-md border border-gray-100 text-xs font-medium text-gray-700">
                        {formatDate(new Date())}
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* Your Aura Signature - starts right after the image */}
                <div className="w-full max-w-[2100px] mx-auto">
                  <h4 className="font-heading text-3xl md:text-4xl mb-12 minrims-gradient-text font-bold text-center">Your Aura Signature</h4>
                  
                  {/* Aura colors grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-14 w-full">
                    {analysisResult.auraAnalysis.colors.map((color, index) => {
                      const colorClasses = colorToClass(color);
                      const dotClass = colorToDotClass(color);
                      const meaning = analysisResult.auraAnalysis.meanings[color as keyof typeof analysisResult.auraAnalysis.meanings] || "";
                      
                      // Extract base color for intensity
                      const baseColor = color.split(' ')[0].toLowerCase();
                      const colorIntensity = analysisResult.auraAnalysis.colorIntensities?.[baseColor as keyof typeof analysisResult.auraAnalysis.colorIntensities] || 5;
                      
                      // Enhanced intensity labels
                      let intensityLabel = "";
                      let intensityEmoji = "";
                      if (colorIntensity >= 9) {
                        intensityLabel = "Dominant";
                        intensityEmoji = "✦✦✦";
                      } else if (colorIntensity >= 7) {
                        intensityLabel = "Strong";
                        intensityEmoji = "✦✦";
                      } else if (colorIntensity >= 5) {
                        intensityLabel = "Present";
                        intensityEmoji = "✦";
                      } else if (colorIntensity >= 3) {
                        intensityLabel = "Subtle";
                        intensityEmoji = "⋆";
                      } else {
                        intensityLabel = "Trace";
                        intensityEmoji = "∙";
                      }
                      
                      return (
                        <div 
                          key={index}
                          className={`${colorClasses.bg} p-6 rounded-xl border border-gray-100 shadow-md hover:shadow-lg transition-all duration-300 relative overflow-hidden h-full`}
                        >
                          {/* Visual color indicator as a subtle side accent */}
                          <div 
                            className={`absolute left-0 top-0 bottom-0 w-1.5 ${dotClass.replace('shadow-md', '')}`} 
                            aria-hidden="true"
                          ></div>
                          
                          <div className="flex items-center gap-3 mb-3">
                            <div className="flex items-center justify-center w-10 h-10 rounded-full bg-white/60 backdrop-blur-sm p-1 ring-2 ring-white/80 shadow">
                              <span 
                                className={`w-7 h-7 rounded-full ${dotClass} flex-shrink-0`}
                                aria-hidden="true"
                              ></span>
                            </div>
                            <div className="flex-grow">
                              <h5 className={`font-medium ${colorClasses.text} text-lg tracking-wide`}>
                                {color}
                              </h5>
                              <div className="flex items-center mt-0.5">
                                <div 
                                  className="h-1.5 rounded-full bg-white/50 w-24 overflow-hidden"
                                  aria-hidden="true"
                                >
                                  <div 
                                    className={`h-full ${dotClass.replace('shadow-md', '')}`}
                                    style={{ width: `${colorIntensity * 10}%` }}
                                  ></div>
                                </div>
                                <span className="ml-2 text-xs font-medium text-gray-600">
                                  {intensityEmoji}
                                </span>
                              </div>
                            </div>
                            <span className="text-xs bg-white/80 backdrop-blur-sm px-2.5 py-1 rounded-full border border-gray-100 font-medium text-gray-800 whitespace-nowrap">
                              {intensityLabel}
                            </span>
                          </div>
                          
                          <p className={`${colorClasses.text.replace('900', '800')} ml-12 leading-relaxed`} style={{ fontSize: '16px', lineHeight: '1.8', letterSpacing: '0.01em', padding: '10px 0' }}>
                            {meaning}
                          </p>
                        </div>
                      );
                    })}
                  </div>
                  
                  {/* Energy Overview section */}
                  <div className="prose prose-md max-w-none p-8 sm:p-10 md:p-12 bg-white rounded-xl border border-gray-200 shadow-md mt-12 relative overflow-hidden">
                    {/* Decorative energetic accent */}
                    <div 
                      className="absolute -right-8 -top-8 w-32 h-32 rounded-full opacity-15 bg-gradient-to-br from-indigo-600 to-purple-500 blur-3xl"
                      aria-hidden="true"
                    ></div>
                    <div 
                      className="absolute -left-8 -bottom-8 w-40 h-40 rounded-full opacity-10 bg-gradient-to-tr from-blue-500 to-teal-400 blur-3xl"
                      aria-hidden="true"
                    ></div>
                    
                    <h4 className="font-heading text-3xl md:text-4xl mb-12 minrims-gradient-text text-center sm:text-left font-bold relative z-10">
                      Your Energy Overview
                    </h4>
                    
                    <div className="bg-gradient-to-r from-blue-50/80 to-indigo-50/80 backdrop-blur-sm p-8 sm:p-12 rounded-xl border border-blue-100/50 shadow-sm mb-16 relative z-10">
                      <p className="leading-relaxed text-gray-800 tracking-wide space-y-8" style={{ fontSize: '16px', lineHeight: '1.9', letterSpacing: '0.015em' }}>
                        {analysisResult.auraAnalysis.analysis.split('\n\n').map((paragraph, index) => (
                          <span key={index} className="block mb-10">{paragraph}</span>
                        ))}
                      </p>
                    </div>
                    
                    {/* Life Theme and Energy Forecast */}
                    {analysisResult.auraAnalysis.personalInsights && (
                      <div className="mt-20 space-y-14">
                        <div className="p-8 sm:p-10 md:p-12 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl border border-blue-100 shadow-md transform transition-transform hover:shadow-lg">
                          <h5 className="font-heading text-2xl text-blue-700 mb-8 flex items-center">
                            <span className="inline-block w-9 h-9 bg-blue-500 rounded-full mr-5 flex-shrink-0"></span>
                            Your Current Life Theme
                          </h5>
                          <p className="italic text-gray-800 text-lg sm:text-xl md:text-2xl font-medium pl-14 leading-relaxed" style={{ fontSize: '18px', lineHeight: '1.9', letterSpacing: '0.02em', padding: '10px 0' }}>
                            {analysisResult.auraAnalysis.personalInsights.lifeTheme}
                          </p>
                        </div>
                        
                        <div className="p-8 sm:p-10 md:p-12 bg-gradient-to-r from-indigo-50 to-blue-50 rounded-xl border border-indigo-100 shadow-md transform transition-transform hover:shadow-lg">
                          <h5 className="font-heading text-2xl text-indigo-700 mb-8 flex items-center">
                            <span className="inline-block w-9 h-9 bg-indigo-500 rounded-full mr-5 flex-shrink-0"></span>
                            Energy Forecast
                          </h5>
                          <p className="text-gray-800 text-lg sm:text-xl md:text-2xl pl-14 leading-relaxed" style={{ fontSize: '18px', lineHeight: '1.9', letterSpacing: '0.02em', padding: '10px 0' }}>
                            {analysisResult.auraAnalysis.personalInsights.energyForecast}
                          </p>
                        </div>
                      </div>
                    )}
                    
                    {/* Positive & Negative Aspects */}
                    {(analysisResult.auraAnalysis.positiveAspects?.length > 0 || analysisResult.auraAnalysis.negativeAspects?.length > 0) && (
                      <div className="mt-20">
                        <h4 className="font-heading text-3xl md:text-4xl mb-12 minrims-gradient-text text-center sm:text-left font-bold">Key Insights From Your Reading</h4>
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 max-w-[2100px] mx-auto">
                          {/* Positive Aspects */}
                          {analysisResult.auraAnalysis.positiveAspects?.length > 0 && (
                            <div className="bg-gradient-to-r from-blue-50 to-indigo-50 p-10 rounded-xl shadow-md border border-blue-100 transform transition-transform hover:shadow-lg max-w-[300px] sm:max-w-none mx-auto sm:mx-0 w-full">
                              <h5 className="font-heading text-2xl text-blue-700 mb-8 flex items-center font-bold">
                                <span className="inline-block w-10 h-10 bg-blue-500 rounded-full mr-5 flex-shrink-0 grid place-items-center">
                                  <span className="text-white text-sm">✓</span>
                                </span>
                                Your Strengths
                              </h5>
                              <ul className="space-y-8 pl-6">
                                {analysisResult.auraAnalysis.positiveAspects.map((aspect, index) => (
                                  <li key={index} className="flex items-start">
                                    <span className="inline-block w-5 h-5 bg-blue-100 border border-blue-300 rounded-full mr-4 mt-1.5 flex-shrink-0"></span>
                                    <span className="text-gray-800 leading-relaxed" style={{ fontSize: '16px', lineHeight: '1.7', letterSpacing: '0.015em', padding: '2px 0' }}>{aspect}</span>
                                  </li>
                                ))}
                              </ul>
                            </div>
                          )}
                          
                          {/* Areas for Growth */}
                          {analysisResult.auraAnalysis.negativeAspects?.length > 0 && (
                            <div className="bg-gradient-to-r from-indigo-50 to-blue-50 p-10 rounded-xl shadow-md border border-indigo-100 transform transition-transform hover:shadow-lg max-w-[300px] sm:max-w-none mx-auto sm:mx-0 w-full">
                              <h5 className="font-heading text-2xl text-indigo-700 mb-8 flex items-center font-bold">
                                <span className="inline-block w-10 h-10 bg-indigo-500 rounded-full mr-5 flex-shrink-0 grid place-items-center">
                                  <span className="text-white text-sm">↑</span>
                                </span>
                                Areas for Growth
                              </h5>
                              <ul className="space-y-8 pl-6">
                                {analysisResult.auraAnalysis.negativeAspects.map((aspect, index) => (
                                  <li key={index} className="flex items-start">
                                    <span className="inline-block w-5 h-5 bg-indigo-100 border border-indigo-300 rounded-full mr-4 mt-1.5 flex-shrink-0"></span>
                                    <span className="text-gray-800 leading-relaxed" style={{ fontSize: '16px', lineHeight: '1.7', letterSpacing: '0.015em', padding: '2px 0' }}>{aspect}</span>
                                  </li>
                                ))}
                              </ul>
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
                
                {/* Report Actions */}
                <div className="flex flex-wrap gap-5 justify-center mt-12 mb-8">
                  <Button variant="outline" className="flex items-center gap-2 text-base px-6 py-6">
                    <Printer className="h-5 w-5" />
                    Print Analysis
                  </Button>
                  <Button variant="outline" className="flex items-center gap-2 text-base px-6 py-6">
                    <Share className="h-5 w-5" />
                    Share Results
                  </Button>
                  <Button variant="default" className="flex items-center gap-2 text-base px-6 py-6 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700">
                    <Save className="h-5 w-5" />
                    Save to Profile
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}