import { useState } from "react";
import { Link } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { useQuery } from "@tanstack/react-query";

import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";

import {
  Users,
  UserPlus,
  Mail,
  Download,
  Upload,
  Search,
  Filter,
  RefreshCw,
  MoreVertical,
  ExternalLink,
  Check,
  AlertCircle,
  ArrowUpDown,
  FileSpreadsheet,
} from "lucide-react";

// Demo data for LinkedIn contacts
const DEMO_CONTACTS = [
  { 
    id: 1, 
    firstName: "John", 
    lastName: "Smith", 
    email: "john.smith@techsolutions.com",
    title: "Chief Technology Officer",
    company: "Tech Solutions Inc.",
    companyDescription: "Enterprise software development and cloud solutions",
    industry: "Information Technology",
    location: "San Francisco, CA",
    emailSent: true,
    notes: "Met at TechConf 2023. Interested in AI solutions.",
    profileUrl: "https://linkedin.com/in/johnsmith"
  },
  { 
    id: 2, 
    firstName: "Sarah", 
    lastName: "Johnson", 
    email: "sarah.j@globalmarketing.co",
    title: "Marketing Director",
    company: "Global Marketing Partners",
    companyDescription: "Full-service marketing agency specializing in digital transformation",
    industry: "Marketing and Advertising",
    location: "New York, NY",
    emailSent: false,
    notes: "Introduced by Alex. Looking for data analytics solutions.",
    profileUrl: "https://linkedin.com/in/sarahjohnson"
  },
  { 
    id: 3, 
    firstName: "Michael", 
    lastName: "Lee", 
    email: "michael@datainsights.io",
    title: "Data Analyst",
    company: "Data Insights",
    companyDescription: "Business intelligence and data visualization services",
    industry: "Data Analytics",
    location: "Chicago, IL",
    emailSent: true,
    notes: "Very responsive, currently evaluating our proposal.",
    profileUrl: "https://linkedin.com/in/michaellee"
  },
  { 
    id: 4, 
    firstName: "Jennifer", 
    lastName: "Martinez", 
    email: "jennifer.m@healthcare-innovations.org",
    title: "Head of Innovation",
    company: "Healthcare Innovations",
    companyDescription: "Developing cutting-edge solutions for healthcare providers",
    industry: "Healthcare",
    location: "Boston, MA",
    emailSent: false,
    notes: "Interested in ML applications for patient care.",
    profileUrl: "https://linkedin.com/in/jennifermartinez"
  },
  { 
    id: 5, 
    firstName: "David", 
    lastName: "Wilson", 
    email: "dwilson@fintech-capital.com",
    title: "Investment Analyst",
    company: "FinTech Capital",
    companyDescription: "Venture capital firm focusing on financial technology startups",
    industry: "Financial Services",
    location: "Miami, FL",
    emailSent: true,
    notes: "Looking for investment opportunities in AI and blockchain.",
    profileUrl: "https://linkedin.com/in/davidwilson"
  }
];

export default function DemoLinkedInContactsPage() {
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  const [showImportDialog, setShowImportDialog] = useState(false);
  const [selectedContact, setSelectedContact] = useState<number | null>(null);
  
  // Use React Query to fetch demo contacts
  const { data: contacts = [], isLoading } = useQuery({
    queryKey: ['/api/demo/linkedin/contacts'],
    queryFn: async () => {
      try {
        const response = await fetch('/api/demo/linkedin/contacts');
        if (!response.ok) {
          throw new Error('Failed to fetch contacts');
        }
        return await response.json();
      } catch (error) {
        console.error('Error fetching contacts:', error);
        return DEMO_CONTACTS; // Fallback to demo data if API fails
      }
    }
  });
  
  // Filter contacts based on search term
  const filteredContacts = contacts.filter(contact => {
    const searchable = `${contact.firstName} ${contact.lastName} ${contact.company} ${contact.title}`.toLowerCase();
    return searchable.includes(searchTerm.toLowerCase());
  });

  // Handle import button click
  const handleImportClick = () => {
    toast({
      title: "Demo Mode",
      description: "File import functionality is disabled in demo mode.",
    });
  };

  // Handle export button click
  const handleExportClick = () => {
    toast({
      title: "Demo Mode",
      description: "Export functionality is disabled in demo mode.",
    });
  };

  // Handle sending email click
  const handleSendEmailClick = (contactId: number) => {
    toast({
      title: "Demo Mode",
      description: "Email sending is disabled in demo mode.",
    });
  };

  // Get details of a selected contact
  const selectedContactData = selectedContact !== null 
    ? contacts.find((c: any) => c.id === selectedContact) || DEMO_CONTACTS.find(c => c.id === selectedContact)
    : null;

  return (
    <div className="container mx-auto py-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">LinkedIn Contacts</h1>
          <p className="text-muted-foreground">
            Manage and organize your LinkedIn connections
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Button variant="outline" onClick={handleExportClick}>
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
          <Button onClick={handleImportClick}>
            <Upload className="mr-2 h-4 w-4" />
            Import
          </Button>
          <Button variant="default">
            <UserPlus className="mr-2 h-4 w-4" />
            Add Contact
          </Button>
        </div>
      </div>

      <div className="flex items-center mb-4">
        <div className="flex-1">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search contacts..."
              className="pl-8"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
        <Button variant="outline" className="ml-2">
          <Filter className="mr-2 h-4 w-4" />
          Filter
        </Button>
        <Button variant="outline" className="ml-2">
          <RefreshCw className="mr-2 h-4 w-4" />
          Refresh
        </Button>
      </div>

      <div className="bg-white rounded-md border shadow-sm">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead>Company</TableHead>
              <TableHead>Title</TableHead>
              <TableHead>Location</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredContacts.length === 0 ? (
              <TableRow>
                <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                  No contacts found. Try a different search term or import contacts.
                </TableCell>
              </TableRow>
            ) : (
              filteredContacts.map((contact) => (
                <TableRow key={contact.id}>
                  <TableCell className="font-medium">
                    <div className="hover:underline cursor-pointer" onClick={() => setSelectedContact(contact.id)}>
                      {contact.firstName} {contact.lastName}
                    </div>
                  </TableCell>
                  <TableCell>{contact.company}</TableCell>
                  <TableCell>{contact.title}</TableCell>
                  <TableCell>{contact.location}</TableCell>
                  <TableCell>
                    {contact.emailSent ? (
                      <Badge variant="outline" className="bg-green-50 text-green-700 hover:bg-green-50">
                        <Check className="mr-1 h-3 w-3" /> Emailed
                      </Badge>
                    ) : (
                      <Badge variant="outline">Not Contacted</Badge>
                    )}
                  </TableCell>
                  <TableCell className="text-right">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => handleSendEmailClick(contact.id)}
                    >
                      <Mail className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => setSelectedContact(contact.id)}
                    >
                      <MoreVertical className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      {selectedContactData && (
        <Card className="mt-6">
          <CardHeader>
            <div className="flex justify-between items-start">
              <div>
                <CardTitle>{selectedContactData.firstName} {selectedContactData.lastName}</CardTitle>
                <CardDescription>{selectedContactData.title} at {selectedContactData.company}</CardDescription>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" onClick={() => handleSendEmailClick(selectedContactData.id)}>
                  <Mail className="mr-2 h-4 w-4" />
                  Send Email
                </Button>
                <Button variant="outline" size="sm">
                  <ExternalLink className="mr-2 h-4 w-4" />
                  View Profile
                </Button>
                <Button variant="outline" size="sm" onClick={() => setSelectedContact(null)}>
                  Close
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="details">
              <TabsList>
                <TabsTrigger value="details">Contact Details</TabsTrigger>
                <TabsTrigger value="company">Company Info</TabsTrigger>
                <TabsTrigger value="notes">Notes</TabsTrigger>
              </TabsList>
              <TabsContent value="details" className="space-y-4 mt-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label className="text-xs text-muted-foreground">Email</Label>
                    <div>{selectedContactData.email}</div>
                  </div>
                  <div>
                    <Label className="text-xs text-muted-foreground">Location</Label>
                    <div>{selectedContactData.location}</div>
                  </div>
                  <div>
                    <Label className="text-xs text-muted-foreground">Industry</Label>
                    <div>{selectedContactData.industry}</div>
                  </div>
                  <div>
                    <Label className="text-xs text-muted-foreground">LinkedIn Profile</Label>
                    <div className="flex items-center">
                      <a 
                        href={selectedContactData.profileUrl} 
                        target="_blank" 
                        rel="noreferrer"
                        className="text-blue-600 hover:underline flex items-center"
                      >
                        {selectedContactData.profileUrl.split('/').pop()}
                        <ExternalLink className="ml-1 h-3 w-3" />
                      </a>
                    </div>
                  </div>
                </div>
              </TabsContent>
              <TabsContent value="company" className="space-y-4 mt-4">
                <div>
                  <Label className="text-xs text-muted-foreground">Company Name</Label>
                  <div className="font-medium">{selectedContactData.company}</div>
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">Description</Label>
                  <div>{selectedContactData.companyDescription}</div>
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">Industry</Label>
                  <div>{selectedContactData.industry}</div>
                </div>
              </TabsContent>
              <TabsContent value="notes" className="space-y-4 mt-4">
                <div>
                  <Label className="text-xs text-muted-foreground">Contact Notes</Label>
                  <div className="mt-1">{selectedContactData.notes}</div>
                </div>
                <Separator className="my-4" />
                <div>
                  <Label className="mb-2">Add a note</Label>
                  <Textarea placeholder="Enter a new note about this contact..." />
                  <Button className="mt-2">
                    Save Note
                  </Button>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
          <CardFooter className="flex justify-between">
            <div className="text-xs text-muted-foreground">
              {selectedContactData.emailSent 
                ? "Last contacted: 2 days ago" 
                : "Not contacted yet"}
            </div>
            <Button variant="destructive" size="sm">
              Delete Contact
            </Button>
          </CardFooter>
        </Card>
      )}

      {/* Import Dialog */}
      <div className="hidden">
        <Dialog open={showImportDialog} onOpenChange={setShowImportDialog}>
          <DialogContent className="sm:max-w-[525px]">
            <DialogHeader>
              <DialogTitle>Import LinkedIn Contacts</DialogTitle>
              <DialogDescription>
                Upload a spreadsheet with your LinkedIn contacts to import them into the system.
              </DialogDescription>
            </DialogHeader>
            
            <div className="py-4">
              <div className="border-2 border-dashed rounded-md p-6 text-center">
                <FileSpreadsheet className="h-10 w-10 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-medium mb-1">Upload Excel file</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  Drag and drop your Excel file here or click to browse
                </p>
                <Input 
                  type="file" 
                  disabled
                  className="hidden" 
                />
                <Button onClick={() => {
                  toast({
                    title: "Demo Mode",
                    description: "Import functionality is disabled in demo mode.",
                  });
                  setShowImportDialog(false);
                }}>
                  Select File
                </Button>
              </div>
            </div>
            
            <DialogFooter>
              <Button variant="outline" onClick={() => setShowImportDialog(false)}>
                Cancel
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}