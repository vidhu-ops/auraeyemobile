import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useRoute } from "wouter";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { User, HealerProfile } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Star, StarHalf, Calendar, Clock, DollarSign, Award, Mail, Phone, MessageCircle } from "lucide-react";

type HealerData = {
  user: User;
  profile: HealerProfile;
};

export default function HealerProfilePage() {
  const [, params] = useRoute("/healers/:id");
  const healerId = params?.id ? parseInt(params.id) : undefined;
  const { toast } = useToast();

  const { data: healerData, isLoading, error } = useQuery<HealerData>({
    queryKey: [`/api/healers/${healerId}`],
    enabled: !!healerId,
    staleTime: 1000 * 60 * 5, // 5 minutes
  });

  useEffect(() => {
    if (error) {
      toast({
        title: "Error",
        description: "Failed to load healer profile. Please try again later.",
        variant: "destructive",
      });
    }
  }, [error, toast]);

  // Generate initials from name
  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((part) => part[0])
      .join("")
      .toUpperCase();
  };

  // Generate stars for rating
  const renderStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 >= 0.5;
    
    for (let i = 0; i < fullStars; i++) {
      stars.push(<Star key={`full-${i}`} className="fill-amber-400 text-amber-400 w-5 h-5" />);
    }
    
    if (hasHalfStar) {
      stars.push(<StarHalf key="half" className="fill-amber-400 text-amber-400 w-5 h-5" />);
    }
    
    const emptyStars = 5 - stars.length;
    for (let i = 0; i < emptyStars; i++) {
      stars.push(<Star key={`empty-${i}`} className="text-neutral-medium w-5 h-5" />);
    }
    
    return stars;
  };

  if (isLoading || !healerData) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-grow flex items-center justify-center">
          <div className="text-center">
            <Loader2 className="h-12 w-12 animate-spin text-primary mx-auto mb-4" />
            <p className="text-accent">Loading healer profile...</p>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  const { user, profile } = healerData;

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow">
        <div className="container mx-auto px-4 py-8">
          <div className="max-w-4xl mx-auto">
            {/* Hero section */}
            <div className="bg-gradient-to-r from-primary to-secondary rounded-xl mb-8 p-8 text-white relative overflow-hidden">
              <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2"></div>
              <div className="absolute bottom-0 left-0 w-48 h-48 bg-white/10 rounded-full translate-y-1/2 -translate-x-1/2"></div>
              
              <div className="relative flex flex-col md:flex-row gap-6 items-center md:items-start">
                <div className="w-32 h-32">
                  {profile.imageUrl ? (
                    <img 
                      src={profile.imageUrl} 
                      alt={user.fullName} 
                      className="w-full h-full object-cover rounded-full border-4 border-white/30" 
                    />
                  ) : (
                    <Avatar className="w-full h-full border-4 border-white/30">
                      <AvatarFallback className="text-4xl bg-accent text-white">
                        {getInitials(user.fullName)}
                      </AvatarFallback>
                    </Avatar>
                  )}
                </div>
                <div className="text-center md:text-left flex-1">
                  <h1 className="font-heading text-3xl font-bold mb-2">{user.fullName}</h1>
                  <div className="flex flex-wrap items-center justify-center md:justify-start gap-2 mb-4">
                    {profile.specialties && profile.specialties.map((specialty, index) => (
                      <span 
                        key={index}
                        className="bg-white/20 text-white text-sm rounded-full px-3 py-1"
                      >
                        {specialty}
                      </span>
                    ))}
                  </div>
                  <div className="flex items-center justify-center md:justify-start mb-2">
                    <div className="flex">
                      {renderStars(profile.rating || 0)}
                    </div>
                    <span className="ml-2">
                      {profile.rating?.toFixed(1)} ({profile.reviewCount || 0} reviews)
                    </span>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="flex flex-col md:flex-row gap-8">
              {/* Main content */}
              <div className="md:w-2/3">
                <Card className="mb-8">
                  <CardContent className="p-6">
                    <h2 className="font-heading text-2xl text-accent-dark mb-4">About Me</h2>
                    <p className="text-accent mb-6">{profile.bio || "No bio provided yet."}</p>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div className="bg-neutral-lightest p-4 rounded-lg flex items-center">
                        <Calendar className="text-primary h-5 w-5 mr-3" />
                        <div>
                          <div className="text-xs text-muted-foreground">Experience</div>
                          <div className="font-medium">{profile.yearsExperience || 0} years</div>
                        </div>
                      </div>
                      <div className="bg-neutral-lightest p-4 rounded-lg flex items-center">
                        <DollarSign className="text-primary h-5 w-5 mr-3" />
                        <div>
                          <div className="text-xs text-muted-foreground">Price</div>
                          <div className="font-medium">
                            {profile.pricePerHour ? `$${profile.pricePerHour}/hr` : "Contact for pricing"}
                          </div>
                        </div>
                      </div>
                      <div className="bg-neutral-lightest p-4 rounded-lg flex items-center">
                        <Clock className="text-primary h-5 w-5 mr-3" />
                        <div>
                          <div className="text-xs text-muted-foreground">Session Length</div>
                          <div className="font-medium">60-90 minutes</div>
                        </div>
                      </div>
                      <div className="bg-neutral-lightest p-4 rounded-lg flex items-center">
                        <Award className="text-primary h-5 w-5 mr-3" />
                        <div>
                          <div className="text-xs text-muted-foreground">Specialization</div>
                          <div className="font-medium truncate">
                            {profile.specialties && profile.specialties.length > 0 
                              ? profile.specialties[0]
                              : "Energy Healing"}
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                
                <Card className="mb-8">
                  <CardContent className="p-6">
                    <h2 className="font-heading text-2xl text-accent-dark mb-4">My Approach</h2>
                    <p className="text-accent mb-4">
                      I believe that every person's energy field is unique and requires a personalized approach to healing.
                      By combining various techniques and modalities, I create a customized experience that addresses
                      your specific needs and helps restore balance to your energy system.
                    </p>
                    <p className="text-accent">
                      Whether you're experiencing physical discomfort, emotional challenges, or seeking spiritual growth,
                      my healing sessions are designed to support your journey toward wholeness and well-being.
                    </p>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-6">
                    <h2 className="font-heading text-2xl text-accent-dark mb-4">Services Offered</h2>
                    <div className="space-y-4">
                      {profile.specialties && profile.specialties.map((specialty, index) => (
                        <div key={index} className="p-4 border border-neutral-light rounded-lg">
                          <h3 className="font-heading text-lg font-medium text-accent-dark mb-1">{specialty}</h3>
                          <p className="text-sm text-accent">
                            Personalized {specialty.toLowerCase()} sessions tailored to your unique energy signature and spiritual needs.
                          </p>
                          <div className="mt-2 text-sm text-primary font-medium">
                            {profile.pricePerHour ? `$${profile.pricePerHour}/hr` : "Contact for pricing"}
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
              
              {/* Sidebar */}
              <div className="md:w-1/3">
                <Card className="mb-6 sticky top-4">
                  <CardContent className="p-6">
                    <h3 className="font-heading text-xl text-accent-dark mb-4">Get in Touch</h3>
                    <div className="space-y-4 mb-6">
                      <div className="flex items-center">
                        <Mail className="text-primary h-5 w-5 mr-3" />
                        <span className="text-accent">{user.email}</span>
                      </div>
                      <div className="flex items-center">
                        <Phone className="text-primary h-5 w-5 mr-3" />
                        <span className="text-accent">Contact through platform</span>
                      </div>
                    </div>
                    
                    <Separator className="my-4" />
                    
                    <Button className="w-full mb-3">
                      <Calendar className="mr-2 h-4 w-4" /> Book a Session
                    </Button>
                    <Button variant="outline" className="w-full">
                      <MessageCircle className="mr-2 h-4 w-4" /> Send Message
                    </Button>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-6">
                    <h3 className="font-heading text-xl text-accent-dark mb-4">Client Reviews</h3>
                    {profile.reviewCount && profile.reviewCount > 0 ? (
                      <div className="space-y-4">
                        {/* Sample reviews - in a real app these would come from the API */}
                        <div className="border-b border-neutral-light pb-4">
                          <div className="flex items-center mb-2">
                            <div className="flex text-amber-400">
                              <Star className="fill-amber-400 text-amber-400 w-4 h-4" />
                              <Star className="fill-amber-400 text-amber-400 w-4 h-4" />
                              <Star className="fill-amber-400 text-amber-400 w-4 h-4" />
                              <Star className="fill-amber-400 text-amber-400 w-4 h-4" />
                              <Star className="fill-amber-400 text-amber-400 w-4 h-4" />
                            </div>
                            <span className="ml-2 text-sm text-muted-foreground">1 month ago</span>
                          </div>
                          <p className="text-sm text-accent italic">
                            "An amazing experience! I felt completely renewed after our session.
                            The energy work was gentle yet powerful."
                          </p>
                          <div className="mt-2 text-xs font-medium">- Sarah K.</div>
                        </div>
                        <div>
                          <div className="flex items-center mb-2">
                            <div className="flex text-amber-400">
                              <Star className="fill-amber-400 text-amber-400 w-4 h-4" />
                              <Star className="fill-amber-400 text-amber-400 w-4 h-4" />
                              <Star className="fill-amber-400 text-amber-400 w-4 h-4" />
                              <Star className="fill-amber-400 text-amber-400 w-4 h-4" />
                              <Star className="text-neutral-medium w-4 h-4" />
                            </div>
                            <span className="ml-2 text-sm text-muted-foreground">2 months ago</span>
                          </div>
                          <p className="text-sm text-accent italic">
                            "Very insightful session. The healer was attentive and really understood 
                            what I needed. Highly recommended!"
                          </p>
                          <div className="mt-2 text-xs font-medium">- Michael T.</div>
                        </div>
                      </div>
                    ) : (
                      <p className="text-sm text-muted-foreground">No reviews yet.</p>
                    )}
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
