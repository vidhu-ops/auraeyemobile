import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import { HealerCard } from "@/components/ui/healer-card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Slider } from "@/components/ui/slider";
import { Card } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Loader2, Search, Users } from "lucide-react";
import { User, HealerProfile } from "@shared/schema";

// Define a type for the healers data
type HealerWithProfile = User & { profile: HealerProfile };

export default function HealersPage() {
  // State for filter options
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedSpecialties, setSelectedSpecialties] = useState<string[]>([]);
  const [priceRange, setPriceRange] = useState<number[]>([0, 200]);

  // Fetch healers
  const { data: healers, isLoading, error } = useQuery<HealerWithProfile[]>({
    queryKey: ["/api/healers"],
    staleTime: 1000 * 60 * 5, // 5 minutes
  });

  // Get all unique specialties from healers
  const allSpecialties = healers
    ? Array.from(new Set(healers.flatMap(healer => healer.profile.specialties || [])))
    : [];

  // Toggle specialty selection
  const toggleSpecialty = (specialty: string) => {
    setSelectedSpecialties(prev => 
      prev.includes(specialty)
        ? prev.filter(s => s !== specialty)
        : [...prev, specialty]
    );
  };

  // Filter healers based on search query and filters
  const filteredHealers = healers
    ? healers.filter(healer => {
        // Filter by search query
        const matchesSearch = searchQuery === "" || 
          healer.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
          (healer.profile.specialties || []).some(s => 
            s.toLowerCase().includes(searchQuery.toLowerCase())
          );
        
        // Filter by specialties
        const matchesSpecialties = selectedSpecialties.length === 0 || 
          selectedSpecialties.some(s => 
            (healer.profile.specialties || []).includes(s)
          );
        
        // Filter by price
        const matchesPrice = !healer.profile.pricePerHour || 
          (healer.profile.pricePerHour >= priceRange[0] && 
           healer.profile.pricePerHour <= priceRange[1]);
        
        return matchesSearch && matchesSpecialties && matchesPrice;
      })
    : [];

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow">
        <div className="container mx-auto px-4 py-8">
          <div className="text-center mb-10">
            <h2 className="font-heading text-4xl font-bold mb-4 text-accent-dark">
              Find Your <span className="text-primary">Healer</span>
            </h2>
            <p className="text-accent max-w-2xl mx-auto">
              Connect with experienced energy healers who can help balance your aura and guide your
              spiritual journey based on your unique energy profile.
            </p>
          </div>

          <div className="flex flex-col lg:flex-row gap-8">
            {/* Filters */}
            <div className="lg:w-1/4">
              <Card className="p-5 sticky top-4 relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-blue-400/10 to-purple-500/15 -z-10"></div>
                <div className="absolute inset-0 bg-gradient-to-tr from-blue-400/5 via-indigo-400/5 to-purple-500/10 -z-10"></div>
                <h3 className="font-heading text-lg font-medium flex items-center mb-4">
                  <Users className="mr-2 h-5 w-5 text-indigo-600" />
                  Filter Healers
                </h3>
                
                <div className="mb-6">
                  <Label htmlFor="search" className="mb-2 block">Search</Label>
                  <div className="relative">
                    <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="search"
                      placeholder="Name or specialty..."
                      className="pl-10"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                </div>
                
                <Separator className="my-4" />
                
                <div className="mb-6">
                  <Label className="mb-3 block">Price Range ($/hr)</Label>
                  <div className="px-2">
                    <Slider
                      defaultValue={[0, 200]}
                      max={200}
                      step={10}
                      value={priceRange}
                      onValueChange={setPriceRange}
                    />
                    <div className="flex justify-between mt-2 text-sm text-muted-foreground">
                      <span>${priceRange[0]}</span>
                      <span>${priceRange[1]}</span>
                    </div>
                  </div>
                </div>
                
                <Separator className="my-4" />
                
                <div>
                  <Label className="mb-3 block">Specialties</Label>
                  <div className="space-y-2 max-h-60 overflow-y-auto">
                    {allSpecialties.map((specialty) => (
                      <div key={specialty} className="flex items-center space-x-2">
                        <Checkbox
                          id={specialty}
                          checked={selectedSpecialties.includes(specialty)}
                          onCheckedChange={() => toggleSpecialty(specialty)}
                        />
                        <Label
                          htmlFor={specialty}
                          className="text-sm font-normal cursor-pointer"
                        >
                          {specialty}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>
                
                <Separator className="my-4" />
                
                <Button
                  variant="outline"
                  className="w-full"
                  onClick={() => {
                    setSearchQuery("");
                    setSelectedSpecialties([]);
                    setPriceRange([0, 200]);
                  }}
                >
                  Reset Filters
                </Button>
              </Card>
            </div>
            
            {/* Healers Grid */}
            <div className="lg:w-3/4">
              {isLoading ? (
                <div className="flex justify-center items-center h-64">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                  <span className="ml-2 text-accent">Loading healers...</span>
                </div>
              ) : error ? (
                <div className="text-center p-8 bg-red-50 rounded-lg">
                  <p className="text-red-600">Failed to load healers. Please try again later.</p>
                </div>
              ) : filteredHealers.length === 0 ? (
                <div className="text-center p-8 bg-neutral-lightest rounded-lg">
                  <p className="text-accent mb-4">No healers match your current filters.</p>
                  <Button onClick={() => {
                    setSearchQuery("");
                    setSelectedSpecialties([]);
                    setPriceRange([0, 200]);
                  }}>
                    Clear Filters
                  </Button>
                </div>
              ) : (
                <>
                  <p className="mb-4 text-muted-foreground">
                    Showing {filteredHealers.length} healer{filteredHealers.length !== 1 ? 's' : ''}
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    {filteredHealers.map((healer) => (
                      <HealerCard key={healer.id} healer={healer} />
                    ))}
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
