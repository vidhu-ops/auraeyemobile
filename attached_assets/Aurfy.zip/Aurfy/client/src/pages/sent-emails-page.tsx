import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { Link } from "wouter";

import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Inbox, Mail, ChevronLeft, ExternalLink } from "lucide-react";
import { formatDate } from "@/lib/utils";

export default function SentEmailsPage() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [selectedEmail, setSelectedEmail] = useState<any>(null);
  const [viewEmailDialog, setViewEmailDialog] = useState(false);

  // Query to fetch sent emails
  const { data: emails, isLoading } = useQuery({
    queryKey: ["/api/emails"],
    queryFn: () => apiRequest<any[]>("/api/emails"),
    enabled: !!user,
  });

  const handleViewEmail = (email: any) => {
    setSelectedEmail(email);
    setViewEmailDialog(true);
  };

  return (
    <div className="container py-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Sent Emails</h1>
          <p className="text-muted-foreground">
            View all emails sent to your LinkedIn contacts
          </p>
        </div>
        <div>
          <Link href="/email/templates">
            <Button variant="outline">
              <ChevronLeft className="mr-2 h-4 w-4" />
              Back to Templates
            </Button>
          </Link>
        </div>
      </div>

      {isLoading ? (
        <div className="py-8 text-center">
          <p className="text-muted-foreground">Loading sent emails...</p>
        </div>
      ) : emails?.length === 0 ? (
        <Card className="bg-muted/50">
          <CardContent className="py-10 flex flex-col items-center justify-center">
            <Mail className="h-12 w-12 text-muted-foreground mb-4" />
            <h3 className="text-xl font-medium mb-2">No emails sent yet</h3>
            <p className="text-muted-foreground text-center max-w-md mb-6">
              Start sending emails to your LinkedIn contacts to keep track of your outreach.
            </p>
            <Link href="/linkedin/contacts">
              <Button>
                View LinkedIn Contacts
              </Button>
            </Link>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardHeader>
            <CardTitle>Email History</CardTitle>
            <CardDescription>
              All emails are stored locally for demo purposes. In a production app, you would connect to a real email service like SendGrid.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>To</TableHead>
                  <TableHead>From</TableHead>
                  <TableHead>Subject</TableHead>
                  <TableHead>Sent At</TableHead>
                  <TableHead></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {emails?.map((email) => (
                  <TableRow key={email.filename}>
                    <TableCell>{email.to}</TableCell>
                    <TableCell>{email.from}</TableCell>
                    <TableCell className="font-medium">{email.subject}</TableCell>
                    <TableCell>{new Date(email.sentAt).toLocaleString()}</TableCell>
                    <TableCell>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleViewEmail(email)}
                      >
                        View
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      {/* View Email Dialog */}
      <Dialog open={viewEmailDialog} onOpenChange={setViewEmailDialog}>
        <DialogContent className="sm:max-w-3xl">
          <DialogHeader>
            <DialogTitle>{selectedEmail?.subject || "Email Details"}</DialogTitle>
            <DialogDescription>
              Sent on {selectedEmail?.sentAt ? new Date(selectedEmail.sentAt).toLocaleString() : ""}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 mt-2">
            <div className="grid grid-cols-3 gap-4">
              <div>
                <span className="text-sm font-medium block">From:</span>
                <span className="text-sm">{selectedEmail?.from}</span>
              </div>
              <div>
                <span className="text-sm font-medium block">To:</span>
                <span className="text-sm">{selectedEmail?.to}</span>
              </div>
              <div>
                <span className="text-sm font-medium block">Date:</span>
                <span className="text-sm">{selectedEmail?.sentAt ? new Date(selectedEmail.sentAt).toLocaleString() : ""}</span>
              </div>
            </div>

            <div>
              <span className="text-sm font-medium block mb-1">Subject:</span>
              <span className="text-base">{selectedEmail?.subject}</span>
            </div>

            <div className="border-t pt-4">
              <span className="text-sm font-medium block mb-2">Message:</span>
              {selectedEmail?.html ? (
                <div className="border p-4 rounded-md bg-white">
                  <div dangerouslySetInnerHTML={{ __html: selectedEmail.html }} />
                </div>
              ) : (
                <div className="border p-4 rounded-md bg-white whitespace-pre-line">
                  {selectedEmail?.text}
                </div>
              )}
            </div>

            <div className="flex justify-end space-x-2 mt-4">
              <a
                href={`/emails/${selectedEmail?.filename.replace('.json', '.html')}`}
                target="_blank"
                rel="noopener noreferrer"
              >
                <Button variant="outline" size="sm">
                  <ExternalLink className="h-4 w-4 mr-2" />
                  Open HTML Preview
                </Button>
              </a>
              <Button
                variant="outline"
                size="sm" 
                onClick={() => setViewEmailDialog(false)}
              >
                Close
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}