import { useState } from "react";
import { Link } from "wouter";
import MarketingLayout from "@/components/layout/marketing-layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Download, Mail, User, Users, FileSpreadsheet, Send, 
  Linkedin, CheckCircle, ArrowRight, Database, Layers, MessageSquare, Edit, Trash2, Plus, Upload, UserPlus
} from "lucide-react";

export default function PreviewPage() {
  return (
    <MarketingLayout>
      {/* Hero Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-b from-white to-gray-50">
        <div className="container px-4 md:px-6">
          <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
            <div className="flex flex-col justify-center space-y-4">
              <div className="space-y-2">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none">
                  LinkedIn Data Export & Email System
                </h1>
                <p className="max-w-[600px] text-gray-500 md:text-xl dark:text-gray-400">
                  Extract LinkedIn contact data, export to Excel, and send personalized emails with company details.
                </p>
              </div>
              <div className="flex flex-col gap-2 min-[400px]:flex-row">
                <Link href="/auth">
                  <Button size="lg" className="inline-flex h-11">
                    Get Started
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
                <Link href="#demo">
                  <Button variant="outline" size="lg" className="inline-flex h-11">
                    See Demo
                  </Button>
                </Link>
              </div>
            </div>
            <div className="flex flex-col justify-center space-y-4">
              <div className="rounded-xl overflow-hidden border bg-white shadow-lg">
                <div className="bg-primary text-primary-foreground p-4">
                  <div className="flex items-center space-x-2">
                    <FileSpreadsheet className="h-5 w-5" />
                    <span className="text-sm font-medium">LinkedIn Data Export</span>
                  </div>
                </div>
                <div className="p-6">
                  <div className="space-y-4">
                    <div className="flex items-start space-x-3">
                      <CheckCircle className="mt-0.5 h-5 w-5 text-green-500 flex-shrink-0" />
                      <div>
                        <p className="font-medium">Extract contact data automatically</p>
                        <p className="text-sm text-gray-500">Import directly from LinkedIn or upload spreadsheets</p>
                      </div>
                    </div>
                    <div className="flex items-start space-x-3">
                      <CheckCircle className="mt-0.5 h-5 w-5 text-green-500 flex-shrink-0" />
                      <div>
                        <p className="font-medium">Personalized email templates</p>
                        <p className="text-sm text-gray-500">Auto-fill contact details and company information</p>
                      </div>
                    </div>
                    <div className="flex items-start space-x-3">
                      <CheckCircle className="mt-0.5 h-5 w-5 text-green-500 flex-shrink-0" />
                      <div>
                        <p className="font-medium">Track outreach history</p>
                        <p className="text-sm text-gray-500">Monitor which contacts have received emails</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="w-full py-12 md:py-24 bg-white">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <div className="inline-block rounded-lg bg-gray-100 px-3 py-1 text-sm">Key Features</div>
              <h2 className="text-3xl font-bold tracking-tighter sm:text-5xl">Everything You Need</h2>
              <p className="max-w-[900px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Our platform provides all the tools necessary to extract data from LinkedIn, manage contacts, and send personalized outreach emails.
              </p>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mt-12">
            {/* Feature 1 */}
            <Card className="border-2 hover:border-primary/50 transition-all duration-200">
              <CardHeader>
                <div className="p-2 w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-2">
                  <Linkedin className="h-6 w-6 text-primary" />
                </div>
                <CardTitle>LinkedIn Data Extraction</CardTitle>
                <CardDescription>
                  Connect to LinkedIn to extract valuable contact information
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-start">
                    <CheckCircle className="mt-0.5 mr-2 h-4 w-4 text-green-500" />
                    <span>Extract names, emails, and job titles</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="mt-0.5 mr-2 h-4 w-4 text-green-500" />
                    <span>Capture company descriptions automatically</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="mt-0.5 mr-2 h-4 w-4 text-green-500" />
                    <span>Store contact connection information</span>
                  </li>
                </ul>
              </CardContent>
              <CardFooter>
                <a href="/demo/linkedin" target="_self">
                  <Button variant="outline" className="w-full">
                    <Users className="h-4 w-4 mr-2" />
                    View Contacts Demo
                  </Button>
                </a>
              </CardFooter>
            </Card>

            {/* Feature 2 */}
            <Card className="border-2 hover:border-primary/50 transition-all duration-200">
              <CardHeader>
                <div className="p-2 w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-2">
                  <FileSpreadsheet className="h-6 w-6 text-primary" />
                </div>
                <CardTitle>Excel Import & Export</CardTitle>
                <CardDescription>
                  Seamlessly move data between systems
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-start">
                    <CheckCircle className="mt-0.5 mr-2 h-4 w-4 text-green-500" />
                    <span>Import existing contacts from spreadsheets</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="mt-0.5 mr-2 h-4 w-4 text-green-500" />
                    <span>Export all contact data for analysis</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="mt-0.5 mr-2 h-4 w-4 text-green-500" />
                    <span>Track email outreach status</span>
                  </li>
                </ul>
              </CardContent>
              <CardFooter>
                <Link href="/demo/linkedin">
                  <Button variant="outline" className="w-full">
                    <Download className="h-4 w-4 mr-2" />
                    Import/Export Demo
                  </Button>
                </Link>
              </CardFooter>
            </Card>

            {/* Feature 3 */}
            <Card className="border-2 hover:border-primary/50 transition-all duration-200">
              <CardHeader>
                <div className="p-2 w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-2">
                  <Mail className="h-6 w-6 text-primary" />
                </div>
                <CardTitle>Email Personalization</CardTitle>
                <CardDescription>
                  Create and send highly personalized emails
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-start">
                    <CheckCircle className="mt-0.5 mr-2 h-4 w-4 text-green-500" />
                    <span>Create reusable email templates</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="mt-0.5 mr-2 h-4 w-4 text-green-500" />
                    <span>Auto-fill with contact and company details</span>
                  </li>
                  <li className="flex items-start">
                    <CheckCircle className="mt-0.5 mr-2 h-4 w-4 text-green-500" />
                    <span>View and track sent email history</span>
                  </li>
                </ul>
              </CardContent>
              <CardFooter>
                <a href="/demo/templates" target="_self">
                  <Button variant="outline" className="w-full">
                    <MessageSquare className="h-4 w-4 mr-2" />
                    Email Templates Demo
                  </Button>
                </a>
              </CardFooter>
            </Card>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section id="how-it-works" className="w-full py-12 md:py-24 bg-gray-50">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <div className="inline-block rounded-lg bg-primary/10 px-3 py-1 text-sm text-primary">Process</div>
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">How It Works</h2>
              <p className="max-w-[700px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Our streamlined process makes it easy to manage your LinkedIn contacts and outreach
              </p>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-12">
            <div className="relative flex flex-col items-center">
              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary/10 text-primary">
                <Database className="h-8 w-8" />
                <span className="absolute -top-2 -right-2 flex h-6 w-6 items-center justify-center rounded-full bg-primary text-xs text-primary-foreground">1</span>
              </div>
              <div className="mt-4 space-y-2 text-center">
                <h3 className="text-xl font-semibold">Extract Data</h3>
                <p className="text-gray-500">
                  Connect to LinkedIn to extract contact information or import directly from Excel spreadsheets.
                </p>
              </div>
              <div className="absolute top-24 right-0 hidden md:block">
                <ArrowRight className="h-8 w-8 text-gray-300" />
              </div>
            </div>
            <div className="relative flex flex-col items-center">
              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary/10 text-primary">
                <Layers className="h-8 w-8" />
                <span className="absolute -top-2 -right-2 flex h-6 w-6 items-center justify-center rounded-full bg-primary text-xs text-primary-foreground">2</span>
              </div>
              <div className="mt-4 space-y-2 text-center">
                <h3 className="text-xl font-semibold">Organize Contacts</h3>
                <p className="text-gray-500">
                  Manage your contacts and view complete details including company information and job titles.
                </p>
              </div>
              <div className="absolute top-24 right-0 hidden md:block">
                <ArrowRight className="h-8 w-8 text-gray-300" />
              </div>
            </div>
            <div className="relative flex flex-col items-center">
              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary/10 text-primary">
                <MessageSquare className="h-8 w-8" />
                <span className="absolute -top-2 -right-2 flex h-6 w-6 items-center justify-center rounded-full bg-primary text-xs text-primary-foreground">3</span>
              </div>
              <div className="mt-4 space-y-2 text-center">
                <h3 className="text-xl font-semibold">Send Personalized Emails</h3>
                <p className="text-gray-500">
                  Create email templates with personalized placeholders that automatically fill in contact details.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Demo Section */}
      <section id="demo" className="w-full py-12 md:py-24 bg-white">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <div className="inline-block rounded-lg bg-gray-100 px-3 py-1 text-sm">Live Demo</div>
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">See It In Action</h2>
              <p className="max-w-[700px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Experience the LinkedIn Data Export & Email System with our interactive demo
              </p>
            </div>
          </div>
          <div className="mt-12">
            <Tabs defaultValue="contacts" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="contacts">
                  <Users className="h-4 w-4 mr-2" />
                  LinkedIn Contacts
                </TabsTrigger>
                <TabsTrigger value="templates">
                  <Mail className="h-4 w-4 mr-2" />
                  Email Templates
                </TabsTrigger>
                <TabsTrigger value="excel">
                  <FileSpreadsheet className="h-4 w-4 mr-2" />
                  Import/Export
                </TabsTrigger>
              </TabsList>
              <TabsContent value="contacts" className="p-6 border rounded-b-lg mt-0">
                <div className="flex flex-col gap-6">
                  <div>
                    <h3 className="text-xl font-semibold mb-2">LinkedIn Contacts Management</h3>
                    <p className="text-gray-500 mb-4">
                      Easily manage all your LinkedIn contacts in one place. View complete profiles with job titles, 
                      company information, and track outreach status.
                    </p>
                  </div>
                  <div className="bg-gray-50 border p-6 rounded-lg">
                    <div className="flex justify-between items-center mb-6">
                      <div>
                        <h4 className="font-semibold">Contacts (35)</h4>
                        <p className="text-xs text-gray-500">All LinkedIn contacts</p>
                      </div>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm">
                          <Upload className="h-3.5 w-3.5 mr-1" />
                          Import
                        </Button>
                        <Button size="sm">
                          <UserPlus className="h-3.5 w-3.5 mr-1" />
                          Add Contact
                        </Button>
                      </div>
                    </div>
                    <div className="border rounded-md">
                      <div className="grid grid-cols-4 bg-muted p-3 text-sm font-medium">
                        <div>Name</div>
                        <div>Company</div>
                        <div>Title</div>
                        <div>Status</div>
                      </div>
                      <div className="divide-y">
                        {[
                          { name: "John Smith", company: "Tech Solutions", title: "CTO", emailed: true },
                          { name: "Sarah Johnson", company: "Global Marketing", title: "Marketing Director", emailed: false },
                          { name: "Michael Lee", company: "Data Insights", title: "Data Analyst", emailed: true },
                        ].map((contact, i) => (
                          <div key={i} className="grid grid-cols-4 p-3 hover:bg-muted/50">
                            <div className="font-medium">{contact.name}</div>
                            <div>{contact.company}</div>
                            <div>{contact.title}</div>
                            <div>
                              {contact.emailed ? (
                                <Badge variant="outline" className="bg-green-50 text-green-700 hover:bg-green-50">
                                  Emailed
                                </Badge>
                              ) : (
                                <Badge variant="outline">Not Contacted</Badge>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                    <div className="mt-6 flex justify-center">
                      <a href="/demo/linkedin" target="_self">
                        <Button>
                          Try Contact Management
                          <ArrowRight className="ml-2 h-4 w-4" />
                        </Button>
                      </a>
                    </div>
                  </div>
                </div>
              </TabsContent>
              <TabsContent value="templates" className="p-6 border rounded-b-lg mt-0">
                <div className="flex flex-col gap-6">
                  <div>
                    <h3 className="text-xl font-semibold mb-2">Email Templates</h3>
                    <p className="text-gray-500 mb-4">
                      Create reusable email templates with personalization placeholders. When sending an email, 
                      these placeholders will be automatically filled with the contact's information.
                    </p>
                  </div>
                  <div className="bg-gray-50 border p-6 rounded-lg">
                    <div className="flex justify-between items-center mb-6">
                      <div>
                        <h4 className="font-semibold">Email Templates</h4>
                        <p className="text-xs text-gray-500">Create and manage email templates</p>
                      </div>
                      <Button size="sm">
                        <Plus className="h-3.5 w-3.5 mr-1" />
                        New Template
                      </Button>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <Card>
                        <CardHeader>
                          <CardTitle>Initial Outreach</CardTitle>
                          <CardDescription>
                            Last used: 2 days ago
                          </CardDescription>
                        </CardHeader>
                        <CardContent>
                          <div className="mb-2">
                            <span className="font-medium">Subject:</span> Connecting with &#123;firstName&#125; from &#123;company&#125;
                          </div>
                          <div className="mt-2">
                            <span className="font-medium">Body:</span>
                            <div className="mt-1 text-sm text-muted-foreground line-clamp-3 whitespace-pre-line">
                              Hi &#123;firstName&#125;,
                              
                              I noticed your work at &#123;company&#125; and was particularly impressed with your focus on &#123;companyDescription&#125;. I'm reaching out because...
                            </div>
                          </div>
                        </CardContent>
                        <CardFooter className="flex justify-between">
                          <Button variant="outline" size="sm">
                            <Edit className="h-4 w-4 mr-2" /> Edit
                          </Button>
                          <Button variant="outline" size="sm">
                            <Trash2 className="h-4 w-4 mr-2" /> Delete
                          </Button>
                        </CardFooter>
                      </Card>
                      <Card>
                        <CardHeader>
                          <CardTitle>Follow-up Message</CardTitle>
                          <CardDescription>
                            Last used: 1 week ago
                          </CardDescription>
                        </CardHeader>
                        <CardContent>
                          <div className="mb-2">
                            <span className="font-medium">Subject:</span> Following up on our conversation, &#123;firstName&#125;
                          </div>
                          <div className="mt-2">
                            <span className="font-medium">Body:</span>
                            <div className="mt-1 text-sm text-muted-foreground line-clamp-3 whitespace-pre-line">
                              Hi &#123;firstName&#125;,
                              
                              I wanted to follow up on our previous conversation about &#123;company&#125;'s approach to &#123;industry&#125;. I'm curious to learn more about...
                            </div>
                          </div>
                        </CardContent>
                        <CardFooter className="flex justify-between">
                          <Button variant="outline" size="sm">
                            <Edit className="h-4 w-4 mr-2" /> Edit
                          </Button>
                          <Button variant="outline" size="sm">
                            <Trash2 className="h-4 w-4 mr-2" /> Delete
                          </Button>
                        </CardFooter>
                      </Card>
                    </div>
                    <div className="mt-6 flex justify-center">
                      <a href="/demo/templates" target="_self">
                        <Button>
                          Try Email Templates
                          <ArrowRight className="ml-2 h-4 w-4" />
                        </Button>
                      </a>
                    </div>
                  </div>
                </div>
              </TabsContent>
              <TabsContent value="excel" className="p-6 border rounded-b-lg mt-0">
                <div className="flex flex-col gap-6">
                  <div>
                    <h3 className="text-xl font-semibold mb-2">Excel Import & Export</h3>
                    <p className="text-gray-500 mb-4">
                      Easily import contacts from Excel spreadsheets or export your LinkedIn contacts for use in other systems.
                    </p>
                  </div>
                  <div className="bg-gray-50 border p-6 rounded-lg">
                    <div className="flex flex-col gap-6">
                      <div>
                        <h4 className="font-semibold mb-2">Import Contacts</h4>
                        <div className="border rounded-md p-4 bg-white">
                          <div className="mb-4">
                            <p className="text-sm mb-2">Upload an Excel or CSV file with contact information</p>
                            <div className="flex gap-2">
                              <div className="border rounded flex-1 px-3 py-2 text-sm bg-gray-50">
                                Select file...
                              </div>
                              <Button size="sm" disabled>
                                <Upload className="h-3.5 w-3.5 mr-1" />
                                Import
                              </Button>
                            </div>
                          </div>
                          <div className="text-xs text-gray-500">
                            <p className="font-medium mb-1">Supported columns:</p>
                            <p>First Name, Last Name, Email, Title, Company, Company Description, Industry, Location, Profile URL, Notes</p>
                          </div>
                        </div>
                      </div>
                      <div>
                        <h4 className="font-semibold mb-2">Export Contacts</h4>
                        <div className="border rounded-md p-4 bg-white">
                          <p className="text-sm mb-4">Export all your LinkedIn contacts to an Excel spreadsheet</p>
                          <Button>
                            <Download className="h-4 w-4 mr-2" />
                            Export to Excel
                          </Button>
                        </div>
                      </div>
                    </div>
                    <div className="mt-6 flex justify-center">
                      <a href="/demo/linkedin" target="_self">
                        <Button>
                          Try Import & Export Features
                          <ArrowRight className="ml-2 h-4 w-4" />
                        </Button>
                      </a>
                    </div>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="w-full py-12 md:py-24 bg-primary text-primary-foreground">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Ready to Get Started?</h2>
              <p className="mx-auto max-w-[700px] text-primary-foreground/70 md:text-xl">
                Start extracting LinkedIn data, managing contacts, and sending personalized emails today.
              </p>
            </div>
            <div className="space-x-4">
              <a href="/demo/linkedin" target="_self">
                <Button size="lg" variant="secondary" className="inline-flex h-11">
                  Try Demo
                </Button>
              </a>
            </div>
          </div>
        </div>
      </section>
    </MarketingLayout>
  );
}