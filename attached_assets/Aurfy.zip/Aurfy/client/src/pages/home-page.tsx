import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import Header from "@/components/layout/header";
import Footer from "@/components/layout/footer";
import { HealerCard } from "@/components/ui/healer-card";
import { Button } from "@/components/ui/button";
import { Calendar, Camera, WandSparkles, HandHelping, Star, BookOpen, Sparkles } from "lucide-react";
import { User, HealerProfile } from "@shared/schema";
import { useState, useEffect } from "react";

// Define a type for the healers data
type HealerWithProfile = User & { profile: HealerProfile };

export default function HomePage() {
  // Fetch featured healers
  const { data: healers, isLoading } = useQuery<HealerWithProfile[]>({
    queryKey: ["/api/healers"],
    // If the API returns a 404 or any error, it will just return an empty array
    staleTime: 1000 * 60 * 5, // 5 minutes
  });

  // Take the first 4 healers or show placeholders if loading
  const featuredHealers = isLoading ? Array(4).fill(null) : (healers || []).slice(0, 4);
  
  // Daily horoscope data with current date
  const today = new Date();
  const formattedDate = today.toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' });
  const [currentSign, setCurrentSign] = useState<ZodiacSign>('Aries');
  
  // Define zodiac sign type for TypeScript
  type ZodiacSign = 'Aries' | 'Taurus' | 'Gemini' | 'Leo' | 'Virgo' | 'Libra' | 
                    'Scorpio' | 'Sagittarius' | 'Capricorn' | 'Aquarius' | 'Pisces' | 'Cancer';
  
  // Sample horoscope descriptions for each zodiac sign (would be fetched from an API in production)
  const horoscopes: Record<ZodiacSign, string> = {
    'Aries': 'Today is about embracing new beginnings and taking initiative. Your energy levels are high, making it an excellent time to start projects that require courage and leadership.',
    'Taurus': 'Focus on stability and self-care today. Your practical nature will help you resolve financial matters, while your patience allows you to strengthen meaningful relationships.',
    'Gemini': 'Communication flows easily for you today. Express your ideas clearly and listen attentively to others. Networking and social connections bring unexpected opportunities.',
    'Leo': 'Your creative energy is peaking today. Take time to express yourself through art, performance, or heartfelt conversations. Recognition for past efforts may arrive unexpectedly.',
    'Virgo': 'Detail-oriented tasks benefit from your analytical skills today. Organization and planning set you up for future success. Pay attention to your health and daily routines.',
    'Libra': 'Harmony in relationships is highlighted today. Diplomatic approaches to conflict resolution will be particularly effective. Beauty and balance in your surroundings enhance your wellbeing.',
    'Scorpio': 'Transformation is your theme today. Deep emotional insights offer powerful growth opportunities. Trust your intuition when making important decisions about shared resources.',
    'Sagittarius': 'Adventure calls to you today. Expanding your horizons through learning or travel brings joy. Your optimistic outlook inspires those around you to think bigger.',
    'Capricorn': 'Career matters benefit from your disciplined approach today. Long-term planning and careful strategy help you climb toward your goals. Authority figures may offer support.',
    'Aquarius': 'Innovative ideas flow freely today. Your unique perspective helps solve community challenges. Connecting with like-minded individuals strengthens your sense of purpose.',
    'Pisces': 'Intuition guides you toward spiritual insights today. Creative inspiration is heightened, especially when you allow yourself quiet time for reflection and artistic expression.',
    'Cancer': 'Emotional connections deepen today. Your nurturing energy creates safe spaces for vulnerable conversations. Home and family matters bring comfort and security.'
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow bg-white">
        {/* Hero Section */}
        <div className="bg-gray-50 py-16 lg:py-24 overflow-hidden">
          <div className="container mx-auto px-4">
            <div className="flex flex-col md:flex-row gap-12 items-center">
              <div className="md:w-1/2 max-w-xl">
                <h1 className="font-heading font-extrabold text-4xl md:text-5xl lg:text-6xl leading-tight mb-6">
                  Discover Your <span className="minrims-gradient-text">Energetic</span> Signature
                </h1>
                <p className="text-lg md:text-xl text-gray-600 mb-8 leading-relaxed">
                  Upload your photo for an AI-powered aura analysis that reveals your unique energy profile
                  and connects you with healers aligned to your spiritual needs.
                </p>
                <div className="flex flex-wrap gap-4">
                  <Link href="/analysis">
                    <button className="minrims-btn px-8 py-4 text-lg font-semibold shadow-xl">
                      Start Analysis
                    </button>
                  </Link>
                  <Link href="/healers">
                    <button className="minrims-btn-outline px-8 py-4 text-lg font-semibold">
                      Browse Healers
                    </button>
                  </Link>
                </div>
              </div>
              <div className="md:w-1/2 mt-8 md:mt-0">
                <div className="relative">
                  <div className="absolute -z-10 w-72 h-72 bg-blue-100 rounded-full blur-3xl opacity-60 -top-10 -left-10"></div>
                  <div className="absolute -z-10 w-72 h-72 bg-purple-100 rounded-full blur-3xl opacity-60 -bottom-10 -right-10"></div>
                  <div className="relative rounded-3xl w-full max-w-lg mx-auto shadow-xl z-10 overflow-hidden">
                    <div className="absolute inset-0 z-0 bg-gradient-to-br from-blue-400/40 to-purple-500/40 mix-blend-soft-light"></div>
                    <div className="absolute inset-0 z-0 bg-gradient-to-tr from-indigo-300/20 to-transparent mix-blend-overlay"></div>
                    <div className="absolute -inset-1 z-0 animate-pulse">
                      <div className="absolute inset-0 bg-gradient-to-r from-blue-400/10 via-purple-500/10 to-indigo-400/10 rounded-3xl blur-xl"></div>
                    </div>
                    <img 
                      src="https://images.unsplash.com/photo-1519659528534-7fd733a832a0?w=600&h=600&fit=crop" 
                      alt="Aura energy" 
                      className="w-full h-full object-cover" 
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* How It Works Section */}
        <div className="py-20">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center mb-16">
              <h2 className="font-heading font-bold text-3xl md:text-4xl mb-6">
                How It <span className="minrims-gradient-text">Works</span>
              </h2>
              <p className="text-lg text-gray-600">
                Our platform combines AI technology with spiritual insights to create a seamless experience
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {/* Step 1 */}
              <div className="minrims-card p-8 flex flex-col items-center text-center group">
                <div className="w-16 h-16 bg-gray-50 rounded-2xl flex items-center justify-center mb-6 group-hover:minrims-gradient transition-all duration-300">
                  <Camera className="text-gray-400 group-hover:text-white h-7 w-7 transition-all duration-300" />
                </div>
                <h3 className="font-heading font-bold text-xl mb-3">Upload Your Photo</h3>
                <p className="text-gray-500">
                  Take a well-lit photo with space around your head and upload it to our secure platform.
                </p>
              </div>
              
              {/* Step 2 */}
              <div className="minrims-card p-8 flex flex-col items-center text-center group">
                <div className="w-16 h-16 bg-gray-50 rounded-2xl flex items-center justify-center mb-6 group-hover:minrims-gradient transition-all duration-300">
                  <WandSparkles className="text-gray-400 group-hover:text-white h-7 w-7 transition-all duration-300" />
                </div>
                <h3 className="font-heading font-bold text-xl mb-3">Get Your Analysis</h3>
                <p className="text-gray-500">
                  Our AI analyzes your aura's energy patterns and provides a comprehensive reading.
                </p>
              </div>
              
              {/* Step 3 */}
              <div className="minrims-card p-8 flex flex-col items-center text-center group">
                <div className="w-16 h-16 bg-gray-50 rounded-2xl flex items-center justify-center mb-6 group-hover:minrims-gradient transition-all duration-300">
                  <HandHelping className="text-gray-400 group-hover:text-white h-7 w-7 transition-all duration-300" />
                </div>
                <h3 className="font-heading font-bold text-xl mb-3">Connect With Healers</h3>
                <p className="text-gray-500">
                  Find healers who specialize in balancing your specific energy profile and book sessions.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Featured Healers Section */}
        <div className="py-20 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center mb-16">
              <h2 className="font-heading font-bold text-3xl md:text-4xl mb-6">
                Featured <span className="minrims-gradient-text">Healers</span>
              </h2>
              <p className="text-lg text-gray-600">
                Connect with our top-rated spiritual guides and energy healers
              </p>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
              {featuredHealers.map((healer, index) => (
                <HealerCard key={healer?.id || index} healer={healer} featured />
              ))}
            </div>

            <div className="text-center mt-12">
              <Link href="/healers">
                <button className="minrims-btn px-8 py-4">
                  View All Healers
                </button>
              </Link>
            </div>
          </div>
        </div>
        
        {/* Daily Horoscope Section */}
        <div className="py-20 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center mb-12">
              <h2 className="font-heading font-bold text-3xl md:text-4xl mb-6">
                Daily <span className="minrims-gradient-text">Horoscope</span>
              </h2>
              <p className="text-lg text-gray-600">
                Get celestial insights tailored to your zodiac sign, updated daily
              </p>
              <div className="flex items-center justify-center mt-8">
                <div className="bg-blue-50 rounded-lg px-4 py-2 inline-flex items-center">
                  <Calendar className="text-indigo-600 mr-2 h-5 w-5" />
                  <span className="text-gray-700">{formattedDate}</span>
                </div>
              </div>
            </div>
            
            <div className="mb-10">
              <div className="minrims-card p-8 max-w-4xl mx-auto">
                <div className="flex items-center mb-6">
                  <Star className="text-blue-600 h-8 w-8 mr-3" />
                  <h3 className="font-heading font-bold text-2xl">{currentSign} Daily Forecast</h3>
                </div>
                <p className="text-gray-700 text-lg mb-6 leading-relaxed">
                  {horoscopes[currentSign]}
                </p>
                
                <div className="flex flex-wrap gap-2 mt-6 justify-center">
                  {(Object.keys(horoscopes) as ZodiacSign[]).map(sign => (
                    <button 
                      key={sign}
                      onClick={() => setCurrentSign(sign as ZodiacSign)}
                      className={`px-4 py-2 rounded-full text-sm transition-all ${
                        currentSign === sign 
                          ? 'minrims-gradient text-white font-medium shadow-md' 
                          : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                      }`}
                    >
                      {sign}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Aura Guide Section */}
        <div className="py-20">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center mb-16">
              <h2 className="font-heading font-bold text-3xl md:text-4xl mb-6">
                Guide to <span className="minrims-gradient-text">Auras</span>
              </h2>
              <p className="text-lg text-gray-600">
                Understanding the colors and meanings in your energetic field
              </p>
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-16">
              <div>
                <h3 className="font-heading font-bold text-2xl mb-6">What is an Aura?</h3>
                <p className="text-gray-700 mb-6 leading-relaxed">
                  An aura is an electromagnetic energy field that surrounds all living beings. It's composed of multiple layers 
                  reflecting different aspects of our physical, emotional, mental, and spiritual states. The colors, intensity, 
                  and patterns in your aura reveal insights about your personality, energy levels, and current life situation.
                </p>
                <div className="grid grid-cols-2 gap-4 mb-8">
                  <div className="minrims-card p-5">
                    <div className="flex items-center mb-3">
                      <div className="w-8 h-8 rounded-lg minrims-gradient flex items-center justify-center mr-3">
                        <Sparkles className="text-white h-4 w-4" />
                      </div>
                      <h4 className="font-heading font-medium text-gray-900">Dynamic</h4>
                    </div>
                    <p className="text-gray-600 text-sm">Auras change constantly, reflecting your evolving state of being</p>
                  </div>
                  <div className="minrims-card p-5">
                    <div className="flex items-center mb-3">
                      <div className="w-8 h-8 rounded-lg minrims-gradient flex items-center justify-center mr-3">
                        <BookOpen className="text-white h-4 w-4" />
                      </div>
                      <h4 className="font-heading font-medium text-gray-900">Revealing</h4>
                    </div>
                    <p className="text-gray-600 text-sm">Aura colors indicate emotional states and spiritual development</p>
                  </div>
                </div>
                <div className="text-center mt-8">
                  <Link href="/analysis">
                    <button className="minrims-btn px-6 py-3">
                      Analyze Your Aura
                    </button>
                  </Link>
                </div>
              </div>
              
              <div className="space-y-6">
                <div className="minrims-card p-6 border-l-4 border-blue-400">
                  <h4 className="font-heading font-bold text-xl mb-2">Blue Auras</h4>
                  <p className="text-gray-600">Indicates calm, communication, intuition, and truth. Blues reflect peace, self-expression, and spiritual awareness.</p>
                </div>
                <div className="minrims-card p-6 border-l-4 border-purple-400">
                  <h4 className="font-heading font-bold text-xl mb-2">Purple Auras</h4>
                  <p className="text-gray-600">Shows spiritual awakening, vision, and higher consciousness. Purples connect to intuition and psychic abilities.</p>
                </div>
                <div className="minrims-card p-6 border-l-4 border-green-400">
                  <h4 className="font-heading font-bold text-xl mb-2">Green Auras</h4>
                  <p className="text-gray-600">Represents growth, healing, balance, and nature connection. Greens indicate compassion and heart-centered action.</p>
                </div>
                <div className="minrims-card p-6 border-l-4 border-indigo-400">
                  <h4 className="font-heading font-bold text-xl mb-2">Indigo Auras</h4>
                  <p className="text-gray-600">Reflects deep intuition, psychic ability, and spiritual wisdom. Indigos show dedication to spiritual growth.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Testimonials Section */}
        <div className="py-20 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center mb-16">
              <h2 className="font-heading font-bold text-3xl md:text-4xl mb-6">
                What Our <span className="minrims-gradient-text">Users Say</span>
              </h2>
              <p className="text-lg text-gray-600">
                Discover how AuraInsight has transformed spiritual journeys
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="minrims-card p-8">
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 rounded-full bg-gray-200 mr-4"></div>
                  <div>
                    <h4 className="font-medium">Sarah K.</h4>
                    <p className="text-sm text-gray-500">Yoga Instructor</p>
                  </div>
                </div>
                <p className="text-gray-600">
                  "The aura analysis was incredibly accurate. It detected my creative energy and 
                  connected me with a healer who helped me channel it in new ways."
                </p>
                <div className="mt-4 flex text-blue-500">
                  ★★★★★
                </div>
              </div>
              
              <div className="minrims-card p-8">
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 rounded-full bg-gray-200 mr-4"></div>
                  <div>
                    <h4 className="font-medium">Michael T.</h4>
                    <p className="text-sm text-gray-500">Life Coach</p>
                  </div>
                </div>
                <p className="text-gray-600">
                  "I was skeptical at first, but the insights about my energy field were spot on. 
                  The personalized numerology reading added another dimension to my self-understanding."
                </p>
                <div className="mt-4 flex text-blue-500">
                  ★★★★★
                </div>
              </div>
              
              <div className="minrims-card p-8">
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 rounded-full bg-gray-200 mr-4"></div>
                  <div>
                    <h4 className="font-medium">Jamie L.</h4>
                    <p className="text-sm text-gray-500">Spiritual Seeker</p>
                  </div>
                </div>
                <p className="text-gray-600">
                  "Using AuraInsight has been a transformative journey. I can visually see my progress 
                  as my aura has shifted from chaotic to harmonious over several readings."
                </p>
                <div className="mt-4 flex text-blue-500">
                  ★★★★★
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
