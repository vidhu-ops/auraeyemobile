import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/hooks/use-auth";
import { ProtectedRoute } from "./lib/protected-route";

import NotFound from "@/pages/not-found";
import HomePage from "@/pages/home-page";
import AuthPage from "@/pages/auth-page";
import AnalysisPage from "@/pages/analysis-page";
import DemoAnalysisPage from "@/pages/demo-analysis-page-new";
import HealersPage from "@/pages/healers-page";
import ClientProfile from "@/pages/client-profile";
import HealerProfile from "@/pages/healer-profile";
import CreateHealerProfile from "@/pages/create-healer-profile";
import JournalPage from "@/pages/journal-page";
import PreviewPage from "@/pages/preview-page";

function Router() {
  return (
    <Switch>
      {/* Public routes */}
      <Route path="/" component={HomePage} />
      <Route path="/preview" component={PreviewPage} />
      <Route path="/auth" component={AuthPage} />
      <Route path="/demo-analysis" component={DemoAnalysisPage} />
      
      {/* Protected routes */}
      <ProtectedRoute path="/analysis" component={AnalysisPage} />
      <Route path="/healers" component={HealersPage} />
      <Route path="/healers/:id" component={HealerProfile} />
      <ProtectedRoute path="/healer/create-profile" component={CreateHealerProfile} />
      <ProtectedRoute path="/profile" component={ClientProfile} />
      <ProtectedRoute path="/journal" component={JournalPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
