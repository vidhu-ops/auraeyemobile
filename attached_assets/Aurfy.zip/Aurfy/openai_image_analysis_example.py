import base64
from openai import OpenAI
import os

# Initialize the OpenAI client
client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))

# Function to encode the image
def encode_image(image_path):
    with open(image_path, "rb") as image_file:
        return base64.b64encode(image_file.read()).decode("utf-8")

# Path to your image
image_path = "path_to_your_image.jpg"

# Getting the Base64 string
base64_image = encode_image(image_path)

# Call the OpenAI API with the correct parameters
try:
    # Using the free tier model that supports vision
    response = client.chat.completions.create(
        model="gpt-3.5-turbo",  # Free tier model that supports image analysis
        messages=[
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": "What's in this image?"},
                    {
                        "type": "image_url",
                        "image_url": {
                            "url": f"data:image/jpeg;base64,{base64_image}"
                        }
                    }
                ]
            }
        ]
    )
    
    # Print the response
    print(response.choices[0].message.content)
    
except Exception as e:
    # Handle API errors gracefully
    if "exceeded your current quota" in str(e) or "insufficient_quota" in str(e):
        print("Error: OpenAI API quota exceeded. Please check your billing details or update your API key.")
    else:
        print(f"Error: {str(e)}")