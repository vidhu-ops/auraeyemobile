// Example of how to update the OpenAI API key in a Node.js application

/**
 * This is a simple example of how you might update an OpenAI API key
 * in your application. In a real-world scenario, you would likely store
 * this key securely in environment variables or a secure secrets management system.
 */

// Example using dotenv for environment variables
require('dotenv').config();
const fs = require('fs');
const path = require('path');

/**
 * Updates the OpenAI API key in the .env file
 * @param {string} newApiKey - The new OpenAI API key to use
 */
function updateOpenAIApiKey(newApiKey) {
  if (!newApiKey || typeof newApiKey !== 'string' || newApiKey.trim() === '') {
    throw new Error('Invalid API key provided');
  }
  
  // Path to .env file
  const envFilePath = path.resolve(process.cwd(), '.env');
  
  try {
    // Read the current .env file
    let envFileContent = '';
    if (fs.existsSync(envFilePath)) {
      envFileContent = fs.readFileSync(envFilePath, 'utf8');
    }
    
    // Check if OPENAI_API_KEY already exists
    const regex = /OPENAI_API_KEY=.*/;
    if (regex.test(envFileContent)) {
      // Replace existing key
      envFileContent = envFileContent.replace(regex, `OPENAI_API_KEY=${newApiKey}`);
    } else {
      // Add new key
      envFileContent += `\nOPENAI_API_KEY=${newApiKey}`;
    }
    
    // Write updated content back to .env file
    fs.writeFileSync(envFilePath, envFileContent.trim());
    
    console.log('OpenAI API key updated successfully');
    
    // Update process.env with new key for current process
    process.env.OPENAI_API_KEY = newApiKey;
    
    return true;
  } catch (error) {
    console.error('Error updating OpenAI API key:', error);
    throw error;
  }
}

// Example usage
try {
  // This would typically come from a secure form submission or API request
  const newApiKey = 'sk-your-new-api-key';
  
  updateOpenAIApiKey(newApiKey);
  console.log('API key has been updated. You can now restart your server.');
} catch (error) {
  console.error('Failed to update API key:', error.message);
}